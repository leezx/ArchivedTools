#!/usr/bin/env python
# Author: LI ZHIXIN
"""
split file to 100
"""
import sys
import os

if len(sys.argv) -1 != 1:
	sys.exit(__doc__)

in_file = sys.argv[1]
inf = open(in_file, 'r')
os.mkdir('split_1000')

split_len = 1226717 // 100
line_count = 0
file_count = 0
for line in inf:	
	if line_count >= split_len * file_count:
		if line_count != 0:
			tempf.close()
		temp_file = "./split_1000/kmer_" + str(file_count) + ".txt"
		tempf = open(temp_file, 'w')
		file_count += 1
	print(line.strip(), file=tempf)
	line_count += 1


inf.close()
tempf.close()