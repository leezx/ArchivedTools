source /ifs4/BC_RD/USER/shizhuoxing/PacBio/pipeline/example7/RNA_module/Alignment_gmap/bin/smrtanalysis/etc/setup.sh
blasr query.fa ref.fa -bestn 1 -m 5 -out mapped.m5
/ifs4/BC_RD/USER/liuyabin/Sparc-master/Sparc m mapped.m5 b ref.fa k 1 c 1 g 1 t 0.2 o consensus.fa
