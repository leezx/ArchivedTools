def calculate_N50_etc(seq_len_list):
	def Nn0(seq_len_list, Total_len, n):
		tmp_total_len = 0
		for seq_len in seq_len_list:
			tmp_total_len += seq_len
			if tmp_total_len >= Total_len * (n/10):
				return seq_len
	Total_len = 0
	Total_num = 0
	above1k = 0
	above2k = 0
	above10k = 0
	above100k = 0
	seq_len_list.sort(reverse=True)
	for seq_len in seq_len_list:
		Total_len += seq_len
		Total_num += 1
		if seq_len >= 1000:
			above1k += 1
		if seq_len >= 2000:
			above2k += 1
		if seq_len >= 10000:
			above10k += 1
		if seq_len >= 100000:
			above100k += 1
	N90 = Nn0(seq_len_list, Total_len, 9)
	N80 = Nn0(seq_len_list, Total_len, 8)
	N70 = Nn0(seq_len_list, Total_len, 7)
	N60 = Nn0(seq_len_list, Total_len, 6)
	N50 = Nn0(seq_len_list, Total_len, 5)
	N40 = Nn0(seq_len_list, Total_len, 4)
	N30 = Nn0(seq_len_list, Total_len, 3)
	N20 = Nn0(seq_len_list, Total_len, 2)
	N10 = Nn0(seq_len_list, Total_len, 1)
	Max_len = seq_len_list[0]
	Min_len = seq_len_list[-1]
	Ave_len = Total_len / Total_num
	return N90, N80, N70, N60, N50, N40, N30, N20, N10, Max_len, Min_len, Total_len, Total_num, Ave_len, above1k, above2k, above10k, above100k
