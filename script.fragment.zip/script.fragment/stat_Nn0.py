#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
N90, N80, N70, N60, N50, N40, N30, N20, N10
Max_len, Min_len, Total_len, Total_num, Ave_len
above1k, above2k, above10k, above100k
Usage: python <script> <fasta or fastq or txt(num per line)>
"""

import pysam
import sys

if len(sys.argv) - 1 != 1:
    sys.exit(__doc__)

in_file = sys.argv[1]

# in_file = "PB_chr22_20X_random.fastq"
seq_len_list = []
file_tpye = in_file.split(".")[-1]
out_file = in_file.split("/")[-1].split(".")[0] + "_N50.txt"

if file_tpye in ("fasta","fa") or (file_tpye == "gz" and in_file.split("/")[-1].split(".")[-2] in ("fasta","fa")):
	#fasta_file = "./chr22_contig.fasta"
	fasta = pysam.FastaFile(in_file)
	# dir(fasta)
	seq_len_list = fasta.lengths
	# len(seq_len_list)
	seq_len_list = list(seq_len_list)
	fasta.close()

if file_tpye == "fastq" or (file_tpye == "gz" and in_file.split("/")[-1].split(".")[-2] == "fastq"):	
	#fastq_file = "./PB_chr22_20X_random.fastq"
	fastq = pysam.FastxFile(in_file)
	for line in fastq:
		seq_len_list.append(len(line.sequence))
	fastq.close()

if file_tpye == "txt":
	statf = open(in_file, "r")
	for line in statf:
		seq_len_list.append(int(line))
	statf.close()

def calculate_N50_etc(seq_len_list):
	def Nn0(seq_len_list, Total_len, n):
		tmp_total_len = 0
		for seq_len in seq_len_list:
			tmp_total_len += seq_len
			if tmp_total_len >= Total_len * (n/10):
				return seq_len
	Total_len = 0
	Total_num = 0
	above1k = 0
	above2k = 0
	above10k = 0
	above100k = 0
	seq_len_list.sort(reverse=True)
	for seq_len in seq_len_list:
		Total_len += seq_len
		Total_num += 1
		if seq_len >= 1000:
			above1k += 1
		if seq_len >= 2000:
			above2k += 1
		if seq_len >= 10000:
			above10k += 1
		if seq_len >= 100000:
			above100k += 1
	N90 = Nn0(seq_len_list, Total_len, 9)
	N80 = Nn0(seq_len_list, Total_len, 8)
	N70 = Nn0(seq_len_list, Total_len, 7)
	N60 = Nn0(seq_len_list, Total_len, 6)
	N50 = Nn0(seq_len_list, Total_len, 5)
	N40 = Nn0(seq_len_list, Total_len, 4)
	N30 = Nn0(seq_len_list, Total_len, 3)
	N20 = Nn0(seq_len_list, Total_len, 2)
	N10 = Nn0(seq_len_list, Total_len, 1)
	Max_len = seq_len_list[0]
	Min_len = seq_len_list[-1]
	Ave_len = Total_len / Total_num
	return N90, N80, N70, N60, N50, N40, N30, N20, N10, Max_len, Min_len, Total_len, Total_num, Ave_len, above1k, above2k, above10k, above100k

outf = open(out_file, "w")
N90, N80, N70, N60, N50, N40, N30, N20, N10, Max_len, Min_len, Total_len, Total_num, Ave_len, above1k, above2k, above10k, above100k = calculate_N50_etc(seq_len_list)
print("N90 : %s\nN80 : %s\nN70 : %s\nN60 : %s\nN50 : %s\nN40 : %s\nN30 : %s\nN20 : %s\nN10 : %s\nMax_len : %s\nMin_len : %s\nTotal_len : %s\nTotal_num : %s\nAve_len : %s\nabove1k : %s\nabove2k : %s\nabove10k : %s\nabove100k : %s\n" % (N90, N80, N70, N60, N50, N40, N30, N20, N10, Max_len, Min_len, Total_len, Total_num, Ave_len, above1k, above2k, above10k, above100k), file=outf, sep='\n', end='\n')
outf.close()
