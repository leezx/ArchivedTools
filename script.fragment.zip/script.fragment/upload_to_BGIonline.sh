# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo login -u wangxb -p BGIonline_110
#-----BWAMEM_Split_Chr_LZX_test
bo upload_file -p /lizhixin/Annotation wes_test bwa-index.tar.gz
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/result/Fq/CleanFq/R0160301159.l1/160715_X294_FCHYLWCCCXX_L3_R0160301159_2.fq.gz
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/result/Fq/CleanFq/R0160301159.l1/160715_X294_FCHYLWCCCXX_L3_R0160301159_1.fq.gz

#---------SoapCNV_test_LZX
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/SoapCNV wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/Genome/NewChr/Sus_scrofa.chrALL.new.fa
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/SoapCNV wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/result/sortmerge/L2-mus/L2-mus.bam

#---------Annotation_4in1
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /ifs4/BC_RD/PROJECT/RD_BGIonline_WGRS/MOUSE/analysis/result/SNP/L1-mus/L1-mus_0.filter.snp.vcf.gz
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/Genome/NewChr/Sus_scrofa.chrALL.new.fa.merlist
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/Genome/Sus_scrofa.Sscrofa10.2.75.gff
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /opt/lustresz/BC_AS/F16FTSSCKF0323/PIGnauR/20160708/Genome/Sus_scrofa.Sscrofa10.2.75.dna_rm.toplevel.fa
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /ifs4/BC_RD/PROJECT/RD_BGIonline_WGRS/MOUSE/analysis/ori_index/chrorder
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /ifs4/BC_RD/PROJECT/RD_BGIonline_WGRS/MOUSE/analysis/result/Indel/L1-mus/L1-mus_0.filter.indel.vcf.gz
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /ifs4/BC_RD/PROJECT/RD_BGIonline_WGRS/MOUSE/analysis/result/CNV/L1-mus/L1-mus.filter.cnv
# /ifs4/BC_PUB/biosoft/bin/bgionlinecli/bo upload_file -m "Sample=NA12878" -m "Library=WGST2HumanXXXXX" -m "Flowcell=CL100006359" -m "RGID=CL100006359_L01_1" -p /lizhixin/Annotation wes_test /ifs4/BC_RD/PROJECT/RD_BGIonline_WGRS/MOUSE/analysis/result/SV/L2-mus/L2-mus.filt.breakdancer.ctx
