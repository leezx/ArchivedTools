import pysam

in_file = "./kmer.txt"
out_file = "./kmer.fasta"
inf = open(in_file, 'r')
outf = open(out_file, 'w')

line_count = 0
for line in inf:
	line_count += 1
	kmer, kmer_count = line.strip().split()
	name = ">kmer_" + str(line_count) + "_" + str(kmer_count)
	print(name, kmer, file=outf, sep='\n', end='\n')


inf.close()
outf.close()