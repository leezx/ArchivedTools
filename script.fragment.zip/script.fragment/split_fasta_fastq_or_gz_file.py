#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
split_fasta_fastq_or_gz_file to samll pieces for Parallel Computing.
only support fastq, fasta, fastq.gz or fasta.gz file!
Usage: python <script> <fasta or fastq or fastq.gz> <Partition number> <outdir>
eg. python split_txt_or_gz_file.py PB_chr22_20X_random.fastq.gz 10 split_fastq
"""

import pysam
import sys
import os

if len(sys.argv) - 1 != 3:
    sys.exit(__doc__)

in_file, split_num, outdir = sys.argv[1:]
# outdir = "split_fastq"
if not os.path.exists(outdir):
	os.mkdir(outdir)

def count_lines_number_of_file(in_file, file_type):
	"only support fastq, fasta, fastq.gz or fasta.gz file!"
	if file_type == "fasta":
		inf = pysam.FastaFile(in_file)
		return inf.nreferences
	elif file_type == "fastq":
		inf = pysam.FastxFile(in_file)
	else:
		sys.exit(__doc__)
	count = 0
	for line in inf:
		count += 1
	inf.close()
	return count

# in_file = "PB_chr22_20X_random.fastq"
out_file_prefix = outdir + "/" + in_file.split(".")[0]

if in_file.split(".")[-1] == "fasta" or (in_file.split(".")[-1] == "gz" and in_file.split(".")[-2] == "fasta"):
	file_type = "fasta"
if in_file.split(".")[-1] == "fastq" or (in_file.split(".")[-1] == "gz" and in_file.split(".")[-2] == "fastq"):	
	file_type = "fastq"

if file_type == "fasta":
	one_piece = count_lines_number_of_file(in_file, file_type) // int(split_num)
	file_count = 0
	reads_count = 0
	#reads_count = file_count * file_count
	inf = pysam.FastaFile(in_file)
	reads_name = inf.references
	for one in reads_name:
		#reads_count = file_count * one_piece
		seq = inf.fetch(one)
		if reads_count == 0:
			file_count += 1
			outf = open(out_file_prefix+'_'+str(file_count)+".fasta", "w")
		if reads_count > file_count * one_piece:
			outf.close()
			file_count += 1
			outf = open(out_file_prefix+'_'+str(file_count)+".fasta", "w")
		else:
			print(">"+one, seq, file=outf, sep='\n', end='\n')
			reads_count += 1

if file_type == "fastq":
	one_piece = count_lines_number_of_file(in_file, file_type) // int(split_num)
	file_count = 0
	reads_count = 0
	#reads_count = file_count * file_count
	inf = pysam.FastxFile(in_file)
	for line in inf:
		#reads_count = file_count * one_piece
		if reads_count == 0:
			file_count += 1
			outf = open(out_file_prefix+'_'+str(file_count)+".fastq", "w")
		if reads_count > file_count * one_piece:
			outf.close()
			file_count += 1
			outf = open(out_file_prefix+'_'+str(file_count)+".fastq", "w")
		else:
			print("@"+line.name, line.sequence, "+", line.quality, file=outf, sep='\n', end='\n')
			reads_count += 1

inf.close()