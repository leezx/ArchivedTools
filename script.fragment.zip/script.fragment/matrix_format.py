my_matrix = [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]]
with open('PB1.ccs.bam.out.rq.np', 'r') as inf:
	for line in inf:
		line_list = line.strip().split()
		#my_matrix = [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]]
		x = float(line_list[0])
		y = int(line_list[1])
		if 0.95 <= x < 0.96:
			x_index = 1
			print("95_96", end=',')
		elif 0.96 <= x < 0.97:
			x_index = 2
			print("96_97", end=',')
		elif 0.97 <= x < 0.98:
			x_index = 3
			print("97_98", end=',')
		elif 0.98 <= x < 0.99:
			x_index = 4
			print("98_99", end=',')
		elif 0.99 <= x <= 1:
			x_index = 5
			print("99_100", end=',')
		elif x < 0.95:
			x_index = 0
			print("0_95", end=',')

		if 0 <= y < 7:
			y_index = 0
			print("0_7")
		elif 7 <= y < 14:
			y_index = 1
			print("7_14")
		elif 14 <= y < 21:
			y_index = 2
			print("14_21")
		elif 21 <= y < 28:
			y_index = 3
			print("21_28")
		elif 28 <= y <= 35:
			y_index = 4
			print("28_35")
		elif y > 35:
			y_index = 5
			print("35_")

		#print(x, x_index,'\n',y, y_index)
		# my_matrix[y_index][x_index] += 1

# #print('0_95','95_96','96_97','97_98','98_99','99_100',sep='\t')
# for one in my_matrix:
# 	for two in one:
# 		#print(two, end='\t')
# 	#print('')

