#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
trans_fastq_to_fasta with pysam, no RQ left!
please input a fastq file!!!!!
"""
import sys

if len(sys.argv) -1 != 1:
    sys.exit(__doc__)

in_file = sys.argv[1]

if in_file.split(".")[-1] != "fastq":
    sys.exit(__doc__)

fastq = open(in_file, "r")
out_file_fasta = in_file.split(".")[0] + ".fasta"
outf = open(out_file_fasta, "w")

line_count = 0
for line in fastq:
    line_count += 1
    if line_count % 4 == 1:
        print('>'+line.strip().split('@')[1], file = outf)
    if line_count % 4 == 2:
        print(line.strip(), file = outf)
    #if line_count == 8:
    #    break

fastq.close()
outf.close()
