#!/bin/bash

id=$1

while((1))
do
date >> mem_monitor.log
qstat -j $id | grep usage | cut -d, -f4 | cut -d= -f2 >> mem_monitor.log
sleep 600
done
