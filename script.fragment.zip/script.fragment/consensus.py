#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
Consensus the PB reads which align to ref(DBG2OLC.etc scaffold), to generate a new ref, for correction.
Usage: python <script> <in.Pacbio.bam> <in.scaffold> <in.PB fasta>
"""

import sys
import re
import pysam
import os
from subprocess import call

if len(sys.argv) - 1 != 3:
    sys.exit(__doc__)

outdir = "run"
if not os.path.exists(outdir):
    os.mkdir(outdir)

PB_bam_file, ref_file, PB_fasta_file = sys.argv[1:]

# fisrt step: handle PB_bam_file, store the PB reads name and its ref to a dict.
ref_and_PB_dict = {} # DS {ref_name:(PB1, PB2, PB3), ...}
PB_bam = pysam.AlignmentFile(PB_bam_file, "rb")
for line in PB_bam:
    if not line.has_tag('NM'):
        continue
    ref_name = line.reference_name
    PB_name = line.query_name
    if not ref_name in ref_and_PB_dict:
        ref_and_PB_dict[ref_name] = set()
    if ref_name in ref_and_PB_dict:
        ref_and_PB_dict[ref_name].add(PB_name)

PB_bam.close()

# second step: extract the PB reads sequence and it ref to specified file.
reff = pysam.FastaFile(ref_file)
PB_reads = pysam.FastaFile(PB_fasta_file)
os.chdir("./run")
count = 0
for ref_name, PB_name_set in ref_and_PB_dict.items():
    count += 1
    out_query_file = "./query_" + str(count) + ".fasta"
    out_ref_file = "./ref_" + str(count) + ".fasta"
    out_m5_file = "./" + str(count) + ".m5"
    out_query = open(out_query_file, "w")
    out_ref = open(out_ref_file, "w")
    ref_seq = reff.fetch(ref_name)
    print(">"+ref_name, ref_seq, file=out_ref, sep='\n', end='\n')
    for PB_reads_name in PB_name_set:
        PB_seq = PB_reads.fetch(PB_reads_name)
        print(">"+PB_reads_name, PB_seq, file=out_query, sep='\n', end='\n')
    out_query.close()
    out_ref.close()
    
    qsub_cmd = "sh ../sparc.sh %s %s %s" % (out_query_file, out_ref_file, out_m5_file) 
    qsub_cmd_list = qsub_cmd.split()
    call(qsub_cmd_list)
    break

reff.close()
PB_reads.close()

# third step: call consensus by SPARC. 
