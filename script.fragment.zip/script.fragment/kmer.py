import pysam

#in_file = './extract_un_correct_region_23_1000.fastq'
in_file = "extract_un_correct_region_above_1000.fastq"
#out_file = './kmer_23_1000.txt'
out_file = './kmer_above_1000.txt'
out_file_2 = './kmer.txt'
fastq = pysam.FastxFile(in_file)
outf = open(out_file, 'w')
outf2 = open(out_file_2, 'w')
k = 23

def split_seq_to_kmer(seq, k):
	kmer_list = []
	count = 1
	if len(seq) < k:
		raise TypeError("seq < k !!!")
	for base in seq:
		kmer_list.append(seq[(count-1):(count-1+k)])
		if count == (len(seq) - k + 1):
			break
		count += 1
	return kmer_list

kmer_dict = {}
for line in fastq:
	seq = line.sequence
	kmer_list = split_seq_to_kmer(seq, k)
	for kmer in kmer_list:
		if kmer in kmer_dict.keys():
			kmer_dict[kmer] += 1
		else:
			kmer_dict[kmer] = 1
	# break

for one in kmer_dict.keys():
	if kmer_dict[one] == 1:
		continue
	print(one, kmer_dict[one], file=outf2, sep='\t', end='\n')

kmer_count_list = list(kmer_dict.values())
kmer_dict = {}
# print("kmer_count_list: ", kmer_count_list)

count_distribution_dict = {}
for one in kmer_count_list:
	if one in count_distribution_dict.keys():
		count_distribution_dict[one]  += 1
	else:
		count_distribution_dict[one] = 1

count_distribution_list = sorted(count_distribution_dict.items(), key=lambda item:item[0], reverse=False)
print("count_distribution_list: ", count_distribution_list)

for one in count_distribution_list:
	print(one[0], one[1], file=outf, sep='\t', end='\n')

fastq.close()
outf.close()
outf2.close()