#!/usr/bin/env python3
import ctypes 
import numpy as np
import os
lib = ctypes.cdll.LoadLibrary(
        os.path.join(os.path.dirname(os.path.realpath(__file__)),
            'diff-cpp-master','libLLCS.so'))

def calc_LLCS(a, b):
    a = np.asarray(a, dtype=np.int_)
    b = np.asarray(b, dtype=np.int_)
    ptr = ctypes.POINTER(ctypes.c_long)
    a_ptr = a.ctypes.data_as(ptr)
    b_ptr = b.ctypes.data_as(ptr)
    return lib.calc_llcs(a_ptr, a.size,b_ptr, b.size)

if __name__ == '__main__':
    print(calc_LLCS([1,2,3], [1,2,4]))
    print(calc_LLCS([0,1,2,3,4,5], [1,2,3,4,5,6]))
    print(calc_LLCS([1,2,3], [1,2,3]))
    # print(calc_LLCS([None,1,2,3], [1,2,3,4]))
