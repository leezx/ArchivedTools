import gzip
import datetime

infile="/share/fqdata108A/Zebra/F15NGS03003_HUMoah/WHHUMoahAAAASAAZebra-47/170205_I44_CL100013600_L1_WHHUMoahAAAASAAZebra-47/CL100013600_L01_read_1.fq.gz"

print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

file = gzip.open(infile)

total_size = file.seek(0,2)

count = 0
temp_pos = file.seek(0)
unit_len = 0

for line in file:
	count += 1
	print(line)
	unit_len += len(line)
	if count == 4:
		break

print(total_size, unit_len)
print("total line: ", total_size//unit_len)

print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
