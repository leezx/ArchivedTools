#! /usr/bin/perl

open IN,"$ARGV[0]";
%hash1=();
%hash2=();
open OUT,">sim.unmap.sam";
while (<IN>){
	chomp;
	if ($_!~/^@/){
		@a=split(/\t/);
		$hash2{$a[0]}=1 if ($a[2] eq "*");
		print OUT "$_\n" if ($a[2] eq "*");
		$hash2{$a[0]}=1 if (defined $hash1{$a[0]});
		$hash1{$a[0]}++;
	}
}
close IN;
close OUT;

open IN,"$ARGV[0]";
open OUT1,">sim.clean.sam";
open OUT2,">sim.other.sam";
while (<IN>){
	chomp;
	if ($_!~/^@/){
		@a=split(/\t/);
		print OUT1 "$_\n" if ($hash1{$a[0]}==1 and $a[2] ne "*");
		print OUT2 "$_\n" if ($hash1{$a[0]}>1 and $a[2] ne "*");
	}
}
close IN;
close OUT1;
close OUT2;

`sort -k 3,3 -k 4,4n sim.other.sam > sim.mutil.sam && rm sim.other.sam`;
$sam="sim.clean.sam";
$gff="sim.clean.gff";
&sam2gff($sam,$gff);
$sam="sim.mutil.sam";
$gff="sim.mutil.gff";
&sam2gff($sam,$gff);

sub sam2gff{
	my($insam,$outgff)=@_;
	open IN,"$insam";
	open OUT,">$outgff";
	while(<IN>){
		chomp;
		next if($_ =~ /^@/);
		@a = split(/\t/,$_);
		$strand="-" if ($a[1]==16);
		$strand="+" if ($a[1]==0);
		@b = split(/\D/, $a[5]);
		$a[5] =~ s/^(\d+)//;
		@c = split(/\d+/,$a[5]);
		$end = 0;
		$gap = 0;
		for($i=0;$i<=$#c;$i++){
			if($c[$i] =~ /(S|H|I)/){
				next;
			}elsif($c[$i] eq "N"){
				$end = $a[3] + $gap -1;
				print OUT "$a[0]\t$a[2]\t$strand\t$a[3]\t$end\n";
				$a[3] = $end + $b[$i] + 1;
				$gap = 0;
			}else{
				$gap += $b[$i];
			}
		}
		$end = $a[3] + $gap -1;
		print OUT "$a[0]\t$a[2]\t$strand\t$a[3]\t$end\n";
	}
	close IN;
	close OUT;
}

