#!/bin/bash
export LD_LIBRARY_PATH="/ifs4/BC_RD/USER/helijuan/software/Programm/boost_1_57_0_v2/boost_1_57_0/v2/lib/:/ifs4/BC_PUB/biosoft/pipeline/Package/GCC/gcc_4.9.0/lib64:$LD_LIBRARY_PATH"

IP1='/ifs4/BC_RD/USER/lizhixin/my_project/denovo_chr22/hiseq_reads/R1_chr22.fastq /ifs4/BC_RD/USER/lizhixin/my_project/denovo_chr22/hiseq_reads/R2_chr22.fastq';

/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/platanus/platanus assemble -o chr22_platanus -f $IP1 2>ass_log.txt

/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/platanus/platanus scaffold -c chr22_platanus_contig.fa -b chr22_platanus_contigBubble.fa -o chr22_platanus -IP1 $IP1 2>sca_log.txt

/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/platanus/platanus gap_close -c chr22_platanus_scaffold.fa  -IP1 $IP1 -o chr22_platanus  2>gap_log.txt
