#!/usr/bin/python  
#coding:utf8  
  
import os  

#pipeline_name = "RNA_Prokaryotic_RNAref_2016a"
#indir = "/ifs4/BC_PUB/biosoft/pipeline/RNA/RNA_Prokaryotic_RNAref/RNA_Prokaryotic_RNAref_2016a/example/normalLibrary/F16RD11041_PROacoP_test/shell/"

def parse_list(infile):
	two_list = []
	with open(infile, "r") as inf:
		for line in inf:
			line_list = line.strip().split()
			two_list.append([line_list[0], line_list[1]])
	return two_list

def traverse_file_generate_csv(pipeline_name, indir):
	def dirlist(path, allfile):  
		filelist =  os.listdir(path)  
		for filename in filelist:  
			filepath = os.path.join(path, filename)  
			if os.path.isdir(filepath):  
				dirlist(filepath, allfile)  
			else:  
				allfile.append(filepath)  
		return allfile  
	  
	#print(dirlist(indir, []) )
	black_list = ['else','fi','sh','less','echo', '#!/bin/bash', 'grep', 'export', 'cat', 'ln','rm','cd','awk','cp','if',';fi',';else','touch','sed','ulimit','mkdir','mv']
	all_tools = set()
	all_script = set()
	tools_script_dict = {}

	for one_file in dirlist(indir, []):
		with open(one_file, "r") as inf:
			for line in inf:
				line_list = line.strip().split()
				if line_list[0] in ('perl','python'):
					all_script.add(line_list[1])
					tools_script_dict[line_list[1]] = one_file
					continue
				if line_list[0] in black_list or line_list[0].startswith('#') :
					continue
				if len(line_list[0]) <= 8:
					print(line_list[0])
				all_tools.add(line_list[0])
				tools_script_dict[line_list[0]] = one_file
	#print(all_tools)
	#print(all_script)
	unique_tools = ['perl','java','R']

	with open(pipeline_name+'.tools.csv', 'w') as toolsf:
		for one in all_tools:
			if one.split('/')[-1] in unique_tools:
				continue
			print(one.split('/')[-1], pipeline_name, one, tools_script_dict[one], file=toolsf, sep=',', end='\n')
			unique_tools.append(one.split('/')[-1])

	with open(pipeline_name+'.script.csv', 'w') as scriptf:
		for one in all_script:
			print(one.split('/')[-1], pipeline_name, one, tools_script_dict[one], file=scriptf, sep=',', end='\n' )

if __name__=='__main__':
	infile = "pipeline.list"
	two_list = parse_list(infile)
	for one in two_list:
		traverse_file_generate_csv(one[0], one[1])

