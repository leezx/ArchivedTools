/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/SMRTAnalysis/smrtlink/smrtcmds/bin/bax2bam -f test.fofn -o subreads2

/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/SMRTAnalysis/smrtlink/smrtcmds/bin/pbalign subreads.bam ref.fa mapped.bam

source /ifs4/BC_RD/USER/yuanyongxian/PacBio/pipeline/bin/smrtanalysis_2.3.0/etc/setup.sh
samtools faidx ref.fa

/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Denovo/PacBio/SMRTAnalysis/smrtlink/smrtcmds/bin/arrow --algorithm=arrow -v -j8 mapped.bam -r ref.fa -o ref.arrowed.fq
