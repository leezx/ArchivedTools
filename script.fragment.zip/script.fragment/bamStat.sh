#!/bin/bash
set -o pipefail
echo ==========start at : `date` ==========
perl /ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Human_WES/DNA_Human_WES_2016b/processBam/processBam_v1.1/bin/bamstats.pl -i /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/result/NA12878-1/result_alignment/NA12878-1.bam -r /ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_Human_WES/DNA_Human_WES_2016b/Database/hg19/bed/ExonCaptureRegion_hg19_Agilent_V5/bed/ex_region.sort.bed -o ./statistics -plot && \
#cp /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/process/NA12878-1/statistics/cumuPlot.png /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/result/NA12878-1/result_alignment/NA12878-1.Cumulative.png && \
#cp /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/process/NA12878-1/statistics/histPlot.png /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/result/NA12878-1/result_alignment/NA12878-1.Depth.png && \
#cp /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/process/NA12878-1/statistics/information.xls /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/result/NA12878-1/result_alignment/NA12878-1.SummaryTable.xls && \
#cp /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/process/NA12878-1/statistics/insert.png /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/result/NA12878-1/result_alignment/NA12878-1.Insert.png && \
echo ==========end at : `date` ========== && \
echo Still_waters_run_deep 1>&2 && \
echo Still_waters_run_deep > /ifs4/BC_RD/USER/chenjing6/DNA/DNA_demo/WES_16b/outdir/shell/NA12878-1/bamStat.sh.sign
