#! /usr/bin/perl

open IN,"$ARGV[0]";
$sub=0;$ins=0;$del=0;
while (<IN>){
	chomp;
	@a=();
	@a=split(/\t/,$_);
	@b=();
	@b=split(/\D/,$a[5]);
	$a[5]=~s/^(\d+)//;
	@c=();
	@c=split(/\d+/,$a[5]);
	for($i=0;$i<=$#c;$i++){
		if ($c[$i] eq "I"){
			$ins+=$b[$i];
		}elsif($c[$i] eq "D"){
			$del+=$b[$i];
		}
	}
	
	foreach $t(@a){
		if ($t=~/^MD:Z:(\S+)/){
			$md_value=$1;
		}else{next;}
		for ($i=0;$i<length($md_value);$i++){
			if (substr($md_value,$i,1) eq '^'){
				$mark=1;
			}elsif(substr($md_value,$i,1)=~/[A-Z]/ && $mark==0){
				$sub++;
			}elsif (substr($md_value,$i,1)=~/\d/){
				$mark=0;
			}
		}
		last if ($t=~/^MD:Z:(\S+)/);
	}
}
close IN;

# $subrate=sprintf("%.3f",($sub/$totalbase)*100);
# $delrate=sprintf("%.3f",($del/$totalbase)*100);
# $insrate=sprintf("%.3f",($ins/$totalbase)*100);
# print "$subrate\t$delrate\t$insrate\n";
open OUT,">stat1";
print OUT "$sub\t$ins\t$del\n";
close OUT;
