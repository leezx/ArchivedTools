#!/bin/bash

ref=$1
prefix=$2
java=/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqExome/DNA_HiSeqExome_2015a/bin/java/jre1.7.0_55/bin/java
picard=/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqExome/DNA_HiSeqExome_2015a/bin/picard
bwa=/ifs4/BC_RD/USER/lizhixin/app/bwa-0.7.15/bwa
samtools=/ifs4/BC_RD/USER/zhanglihua/HiSeqExome/HiSeqExome_v1.1/bin/samtools-1.3.1/samtools

$bwa index $ref
$samtools faidx $ref
$java -jar $picard/CreateSequenceDictionary.jar R=$ref O=$2.dict
