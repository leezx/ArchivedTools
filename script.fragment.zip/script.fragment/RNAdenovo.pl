#!/usr/bin/perl

#Author: liaoxinhui@genomics.org.cn
#Date: Wed Jun 24 09:49:59 CST 2015


use strict;
use warnings;
use Getopt::Long;
use FindBin '$Bin';
use Cwd 'abs_path';
use File::Basename;
my $Version = basename(dirname($Bin));
my ($Config, $rawList, $Outdir, $Help);
GetOptions(
	"conf|c:s" => \$Config,
	"list|l:s" => \$rawList,
	"outdir|o:s" => \$Outdir,
	"help|?" => \$Help
);
if (!$Config || !$rawList || $Help) {
	die <<USAGE;
==================================================================================
Description: RNAdenovo Pipeline for Animal & Plant & Fungi
Version:     $Version
Usage:       perl $0 [options]
Options: 
	    * -conf    configure file
	    * -list    sample list
	      -outdir  work directory, default [./result]
	      -help    this help information
E.g.:
	    perl $0 -conf config.txt -list rawdata.list -outdir result_2015a
==================================================================================
USAGE
}

$Outdir ||= "./result";
$Outdir = abs_path($Outdir);
Mkdir("$Outdir/list");
Mkdir("$Outdir/Reads/CleanData");
Mkdir("$Outdir/Reads/RawData");

my %conf;
$Config = abs_path($Config);
open CONF,$Config or die "File not exists: $Config\n";
while (<CONF>) {
	next if (/^\s*$/ || /^\s*#/ || !/=/);
	s/^([^#]+)#.*$/$1/;
	my ($key, $value) = split /=/,$_,2;
	$key =~ s/^\s*(.*?)\s*$/$1/;
	$value =~ s/^\s*(.*?)\s*$/$1/;
	next if ($value =~ /^\s*$/);
	if ($key =~ /GeneDiff_Method/i) {
		$conf{$key} .= "$value-";
	}else {
		$conf{$key} = $value;
	}
}
close CONF;

if (!$conf{'AnalystEmail'}) {
	print STDERR "Please set 'AnalystEmail' in configure file,\nso that R&D can collection project information for furder development.\nThanks a lot!\n";
	exit;
}

my %samp;
$rawList = abs_path($rawList);
open LIST,$rawList or die "File not exists: $rawList\n";
while (<LIST>) {
	next if (/^\s*$/ || /^#/);
	s/^\s*(.*?)\s*$/$1/;
	my @t = split /\s+/;
	die "Syntax Error:\nfile $rawList do not have 6 elements at line $.\n
		Format of the file should be:\n
		SampleName  LibraryInfo  Path_of_fq1,Path_of_fq2  ReadLength  InsertSize  RawGnum\n" unless (@t >= 6);
	push @{$samp{$t[0]}{'lib'}},$t[1];
	push @{$samp{$t[0]}{'fqs'}},$t[2];
	push @{$samp{$t[0]}{'len'}},$t[3];
	push @{$samp{$t[0]}{'ins'}},$t[4];
	push @{$samp{$t[0]}{'bas'}},$t[5];
}
close LIST;

my $Report_1 = Mkdir("$Outdir/Transcriptome_Denovo_Report/BGI_result/1.CleanData");
my $Report_2 = Mkdir("$Outdir/Transcriptome_Denovo_Report/BGI_result/2.Assembly");
my $Report_3 = Mkdir("$Outdir/Transcriptome_Denovo_Report/BGI_result/3.Annotation");
my $Report_4 = Mkdir("$Outdir/Transcriptome_Denovo_Report/BGI_result/4.Structure");
my $Report_5 = Mkdir("$Outdir/Transcriptome_Denovo_Report/BGI_result/5.Quantify");

my $shell = "";
my $clean_up = "";

my %filter_info = ();
#-----Filter
die "Please set Filter_Method!\n" unless ($conf{'Filter_Method'});
if ($conf{'Filter_Method'} =~ /(SOAPnuke)/i) {
	my $shellDir = Mkdir("$Outdir/shell/Filter_$1");
	my $processDir = Mkdir("$Outdir/process/Filter_$1");
	open SDP,">$Outdir/list/Filter_$1_dependence.txt" or die $!;
	my @depends = ();
	foreach my $s (keys %samp) {
		Mkdir("$shellDir/$s");
		Mkdir("$processDir/$s");
		my $CutReadsNum = ($conf{'CleanGnum'} && $conf{'CleanGnum'} != 0) ? int($conf{'CleanGnum'}*1000000000/(2*$samp{$s}{'len'}[0]*1024*1024)*1.1 + 0.5) : 0;
		my $raw_fq1 = "";
		my $raw_fq2 = "";
		my $adp_1 = "";
		my $adp_2 = "";
		if (@{$samp{$s}{'fqs'}} == 1) {
			($raw_fq1,$raw_fq2) = split /,/,$samp{$s}{'fqs'}[0];
			die "File not exists: $raw_fq1\n" unless (-f $raw_fq1);
			die "File not exists: $raw_fq2\n" unless (-f $raw_fq2);
			my $fq_path = dirname($raw_fq1);
			die "File not exists: $fq_path/1.fqcheck\n" unless (-f "$fq_path/1.fqcheck");
			die "File not exists: $fq_path/2.fqcheck\n" unless (-f "$fq_path/2.fqcheck");
			if ($conf{'Filter_Adp5'} && $conf{'Filter_Adp3'}) {
				$adp_1 = $conf{'Filter_Adp3'};
				$adp_2 = $conf{'Filter_Adp5'};
			}else {
				$adp_1 = "$fq_path/1.adapter.list.gz"; die "File not exists: $adp_1\n" unless (-f $adp_1);
				$adp_2 = "$fq_path/2.adapter.list.gz"; die "File not exists: $adp_2\n" unless (-f $adp_2);
			}
			if ($samp{$s}{'bas'}[0] < $conf{'CleanGnum'}*1000000000*1.1) {die "TotalBase is not enough: $s\n"}
		}else {
			my @raw_fq1 = ();
			my @raw_fq2 = ();
			foreach my $fq (@{$samp{$s}{'fqs'}}) {
				my ($fq1,$fq2) = split /,/,$fq;
				push @raw_fq1,$fq1;
				push @raw_fq2,$fq2;
				my $fq_path = dirname($fq1);
				if (!$conf{'Filter_Adp5'} || !$conf{'Filter_Adp3'}) {
					die "File not exists: $fq_path/1.adapter.list.gz\n" unless (-f "$fq_path/1.adapter.list.gz");
					die "File not exists: $fq_path/2.adapter.list.gz\n" unless (-f "$fq_path/2.adapter.list.gz");
				}
			}
			my $phred_sys = ($conf{'SOAPnuke_Options'} =~ /(-Q\s+2)|(--qualSys\s+2)/) ? "33" : "64";
			if ($conf{'Filter_Adp5'} && $conf{'Filter_Adp3'}) {
				$adp_1 = $conf{'Filter_Adp3'};
				$adp_2 = $conf{'Filter_Adp5'};
				Mkshell("$shellDir/$s/merge_fq1.sh","perl $Bin/Filter/merge_fq.pl ".join(",",@raw_fq1)." 1 $s $processDir/$s/Merge 0 $phred_sys");
				Mkshell("$shellDir/$s/merge_fq2.sh","perl $Bin/Filter/merge_fq.pl ".join(",",@raw_fq2)." 2 $s $processDir/$s/Merge 0 $phred_sys");
			}else {
				$adp_1 = "$processDir/$s/Merge/1.adapter.list.gz";
				$adp_2 = "$processDir/$s/Merge/2.adapter.list.gz";
				Mkshell("$shellDir/$s/merge_fq1.sh","perl $Bin/Filter/merge_fq.pl ".join(",",@raw_fq1)." 1 $s $processDir/$s/Merge 1 $phred_sys");
				Mkshell("$shellDir/$s/merge_fq2.sh","perl $Bin/Filter/merge_fq.pl ".join(",",@raw_fq2)." 2 $s $processDir/$s/Merge 1 $phred_sys");
			}
			$raw_fq1 = "$processDir/$s/Merge/$s\_1.fq.gz";
			$raw_fq2 = "$processDir/$s/Merge/$s\_2.fq.gz";
			my $totalbase = 0;
			foreach my $base (@{$samp{$s}{'bas'}}) {
				$totalbase += $base;
			}
			if ($totalbase < $conf{'CleanGnum'}*1000000000*1.1) {die "TotalBase is not enough: $s\n"}
			print SDP "$shellDir/$s/merge_fq1.sh:0.5G\t$shellDir/$s/Filter_$s.sh:1G\n";
			print SDP "$shellDir/$s/merge_fq2.sh:0.5G\t$shellDir/$s/Filter_$s.sh:1G\n";
		}
		my $seqType = ($conf{'SOAPnuke_Options'} =~ /(-seqType\s+\d)/) ? $1 : "-seqType 0";
		$shell = "tile=`perl $Bin/Filter/findNtile.pl -fq1 $raw_fq1 -fq2 $raw_fq2 $seqType` && \\\n";
		$shell .= "$Bin/software/SOAPnuke filter $conf{'SOAPnuke_Options'} -c $CutReadsNum -1 $raw_fq1 -2 $raw_fq2 -f $adp_1 -r $adp_2 \$tile -o $processDir/$s -C $s\_1.fq.gz -D $s\_2.fq.gz -R $s\_1.rawdata.fq.gz -W $s\_2.rawdata.fq.gz ";
		Mkshell("$shellDir/$s/Filter_$s.sh",$shell);
		$shell = "$Bin/software/fqcheck -r $processDir/$s/$s\_1.fq.gz -c $processDir/$s/$s\_1.fqcheck && \\\n";
		$shell .= "$Bin/software/fqcheck -r $processDir/$s/$s\_2.fq.gz -c $processDir/$s/$s\_2.fqcheck && \\\n";
		$shell .= "perl $Bin/Filter/fqcheck_distribute.pl $processDir/$s/$s\_1.fqcheck $processDir/$s/$s\_2.fqcheck -o $processDir/$s/$s. && \\\n";
		$shell .= "perl $Bin/Filter/soapnuke_stat.pl $processDir/$s/Basic_Statistics_of_Sequencing_Quality.txt $processDir/$s/Statistics_of_Filtered_Reads.txt >$processDir/$s/$s.filter.stat && \\\n";
		$shell .= "cp $processDir/$s/$s.filter.stat $processDir/$s/$s.base.png $processDir/$s/$s.qual.png $Report_1 && \\\n";
		$shell .= Mv("$processDir/$s/$s\_1.fq.gz $processDir/$s/$s\_2.fq.gz $Outdir/Reads/CleanData") . " && \\\n";
		$shell .= Mv("$processDir/$s/$s\_1.rawdata.fq.gz $processDir/$s/$s\_2.rawdata.fq.gz $Outdir/Reads/RawData") . " && \\\n";
		$shell .= "cd $Outdir/Reads/CleanData && md5sum $s\_1.fq.gz >$s\_1.fq.gz.md5 && \\\n";
		$shell .= "cd $Outdir/Reads/CleanData && md5sum $s\_2.fq.gz >$s\_2.fq.gz.md5 && \\\n";
		$shell .= "cd $Outdir/Reads/RawData && md5sum $s\_1.rawdata.fq.gz >$s\_1.rawdata.fq.gz.md5 && \\\n";
		$shell .= "cd $Outdir/Reads/RawData && md5sum $s\_2.rawdata.fq.gz >$s\_2.rawdata.fq.gz.md5 ";
		Mkshell("$shellDir/$s/FilterStat_$s.sh",$shell);
		print SDP "$shellDir/$s/Filter_$s.sh:1G\t$shellDir/$s/FilterStat_$s.sh:1G\n";
		push @depends, "$shellDir/$s/FilterStat_$s.sh:1G";
		my $insert_size = MaxNum(@{$samp{$s}{'ins'}}) + 30; # InsertSize + SD
		$filter_info{$s}{'fq1'} = "$processDir/$s/$s\_1.fq.gz";
		$filter_info{$s}{'fq2'} = "$processDir/$s/$s\_2.fq.gz";
		$filter_info{$s}{'ins'} = $insert_size;
		$filter_info{$s}{'sdp'} = "$shellDir/$s/Filter_$s.sh:1G";
	}
	$shell = "perl $Bin/Filter/filter_stat.pl -indir $processDir -output $processDir/FilterSummary.xls && \\\n";
	$shell .= "cp $processDir/FilterSummary.xls $Report_1 ";
	Mkshell("$shellDir/filter_stat.sh",$shell);
	for(my $i=0;$i<=$#depends;$i++) {
		print SDP "$depends[$i]\t$shellDir/filter_stat.sh:0.1G\n";
	}
	close SDP;
}else {
	#add new filter method here
	die "This version does not support this parameter: Filter_Method = $conf{'Filter_Method'}\n";
}

my %denovo_info = ();
#-----Denovo
die "Please set Denovo_Method!\n" unless ($conf{'Denovo_Method'});
if ($conf{'Denovo_Method'} =~ /(Trinity)/i) {
	my $shellDir = Mkdir("$Outdir/shell/Denovo_$1");
	my $processDir = Mkdir("$Outdir/process/Denovo_$1");
	my $trinity_for_fungi;
	if ($conf{'Annotation_Method'}) {
		if ($conf{'Annotation_dbClass'} =~ /fg/i) {
			$trinity_for_fungi = "--jaccard_clip";
		}else {
			$trinity_for_fungi = " ";
		}
	}
	if (! defined $trinity_for_fungi) {
		warn "Warn: Can't distinguish whether the sample belong to fungi, which is important for trinity assembly.\nSo if your sample belong to fungi, please add '--jaccard_clip' for Trinity_Options in configure file by yourself, and re-generage shells!\n";
		$trinity_for_fungi = " ";
	}
	open SDP,">$Outdir/list/Denovo_$1_dependence.txt" or die $!;
	my %depends = ();
	foreach my $s (keys %filter_info) {
		Mkdir("$shellDir/$s");
		Mkdir("$processDir/$s");
		my $mvDir = Mkdir("$Report_2/$s");
		$shell = "perl $Bin/Denovo/duplication.gz.pl -fq1 $filter_info{$s}{'fq1'} -fq2 $filter_info{$s}{'fq2'} -out $processDir/$s/rmDup/$s && \\\n";
		$shell .= "export PATH=$Bin/software:$Bin/software/bowtie:\$PATH && \\\n";
		$shell .= "export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
		$shell .= "$Bin/software/Trinity --seqType fq --left $processDir/$s/rmDup/$s\_1.fq --right $processDir/$s/rmDup/$s\_2.fq --max_memory $conf{'Denovo_Vf'} --group_pairs_distance $filter_info{$s}{'ins'} --no_version_check --no_cleanup --verbose $conf{'Trinity_Options'} $trinity_for_fungi --output $processDir/$s/Trinity && \\\n";
		$shell .= "if [ ! -f $processDir/$s/Trinity/Trinity.fasta ];then echo \"$processDir/$s/Trinity/Trinity.fasta not exists! exit...\" && exit;fi && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa $processDir/$s/Trinity/Trinity.fasta -output $processDir/$s/$s.Trinity.fa  -type TR -name $s -size && \\\n";
		$shell .= "perl $Bin/Denovo/fa_quality.pl -len -Head -N -gc $processDir/$s/$s.Trinity.fa && \\\n";
		$shell .= "perl $Bin/Denovo/barplot.pl $processDir/$s/$s.Trinity.fa.quality.xls $s.Trinity && \\\n";
		$shell .= "mkdir -p $processDir/$s/Tgicl && \\\n";
		$shell .= "cd $processDir/$s/Tgicl && \\\n";
		$shell .= "ln -s ../Trinity/Trinity.fasta ./$s.for_cluster.fa && \\\n";
		$shell .= "perl $Bin/software/tgicl/tgicl.nozmsort.pl $s.for_cluster.fa $conf{'Tgicl_Options'} && \\\n";
		$shell .= "cat asm_*/align > align && \\\n";
		$shell .= "perl $Bin/software/tgicl/phrap.id.list.pl align align && \\\n";
		$shell .= "perl $Bin/software/tgicl/get_single.pl align.cluster $s.for_cluster.fa single && \\\n";
		$shell .= "cat asm_*/contigs > asm_cluster.fa && cat single.prefect.fa >> single.fa && \\\n";
		$shell .= "cat asm_*/contigs  single.fa > tgicl_cluster_and_single.fa  && \\\n";
		$shell .= "cat align.cluster single.list > tgicl_cluster_and_single.fa.list && \\\n";
		$shell .= "$Bin/software/formatdb -p F -i tgicl_cluster_and_single.fa && \\\n";
		$shell .= "$Bin/software/blastall -p blastn -m 8 -e 1e-10 -F F -a 10 -d tgicl_cluster_and_single.fa -i tgicl_cluster_and_single.fa -o all_vs_all.blast.m8 && \\\n";
		$shell .= "perl $Bin/Denovo/cluster_for_coverage.pl all_vs_all.blast.m8 $processDir/$s/Tgicl && \\\n";
		$shell .= "perl $Bin/Denovo/clusterOrSingle.pl $processDir/$s/Tgicl $s $conf{'Unigene_MinLen'} && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa $s.all.fa -output $s-Unigene.fa && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa cluster.all.fa -output $s-Cluster.fa && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa singleton.all.fa -output $s-Single.fa  && \\\n";
		$shell .= "cd ../ && cp Tgicl/$s-Unigene.fa ./ && \\\n";
		$shell .= "perl $Bin/Denovo/fa_quality.pl -len -Head -N  -gc $s-Unigene.fa && \\\n";
		$shell .= "perl $Bin/Denovo//barplot.pl $s-Unigene.fa.quality.xls $s-Unigene && \\\n";
		$shell .= "cp *txt *pdf *fa *png $mvDir ";
		Mkshell("$shellDir/$s/Denovo_$s.sh",$shell);
		print SDP "$filter_info{$s}{'sdp'}\t$shellDir/$s/Denovo_$s.sh:$conf{'Denovo_Vf'}\n";
		$depends{$s}{'sdp'} = "$shellDir/$s/Denovo_$s.sh:$conf{'Denovo_Vf'}";
		$depends{$s}{'fa'} = "$processDir/$s/$s-Unigene.fa";
		$clean_up .= "[ -d $processDir/$s/Tgicl ] && rm -rf $processDir/$s/Tgicl\n";
		$clean_up .= "[ -d $processDir/$s/Trinity ] && rm -rf $processDir/$s/Trinity\n";
		$clean_up .= "[ -d $processDir/$s/rmDup ] && rm -rf $processDir/$s/rmDup\n";
	}
	my @keys = keys %depends;
	if (@keys == 1) {
		$denovo_info{'fa'} = $depends{$keys[0]}{'fa'};
		$denovo_info{'basename_fa'} = basename($denovo_info{'fa'});
		$denovo_info{'sdp'} = $depends{$keys[0]}{'sdp'};
	}else {
		Mkdir("$processDir/Merge_for_Tgicl/Tgicl");
		my $mvDir = Mkdir("$Report_2/Merged_Result");
		$shell = "cd $processDir/Merge_for_Tgicl/Tgicl && \\\n";
		$shell .= "cat ";
		foreach my $s (@keys) {$shell .= "$depends{$s}{'fa'} "}
		$shell .= " > all.for_claster.fa && \\\n";
		$shell .= "perl $Bin/software/tgicl/tgicl.nozmsort.pl all.for_claster.fa $conf{'Tgicl_Options'} && \\\n";
		$shell .= "cat asm_*/align > align && \\\n";
		$shell .= "perl $Bin/software/tgicl/phrap.id.list.pl align align && \\\n";
		$shell .= "perl $Bin/software/tgicl/get_single.pl align.cluster all.for_claster.fa single && \\\n";
		$shell .= "cat asm_*/contigs > asm_cluster.fa && cat single.prefect.fa >> single.fa && \\\n";
		$shell .= "cat asm_*/contigs  single.fa > tgicl_cluster_and_single.fa  && \\\n";
		$shell .= "cat align.cluster single.list > tgicl_cluster_and_single.fa.list && \\\n";
		$shell .= "$Bin/software/formatdb -p F -i tgicl_cluster_and_single.fa && \\\n";
		$shell .= "$Bin/software/blastall -p blastn -m 8 -e 1e-10 -F F -a 10 -d tgicl_cluster_and_single.fa -i tgicl_cluster_and_single.fa -o all_vs_all.blast.m8 && \\\n";
		$shell .= "perl $Bin/Denovo/cluster_for_coverage.pl all_vs_all.blast.m8 $processDir/Merge_for_Tgicl/Tgicl && \\\n";
		$shell .= "perl $Bin/Denovo/clusterOrSingle.pl $processDir/Merge_for_Tgicl/Tgicl All $conf{'Unigene_MinLen'} && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa All.all.fa -output All-Unigene.fa && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa cluster.all.fa -output All-Cluster.fa && \\\n";
		$shell .= "perl $Bin/Denovo/get_chosen_fa.pl -fa singleton.all.fa -output All-Single.fa  && \\\n";
		$shell .= "cd ../ && mv  Tgicl/All-*.fa ./ && \\\n";
		$shell .= "perl $Bin/Denovo/fa_quality.pl -len -Head -N  -gc All-Unigene.fa && \\\n";
		$shell .= "perl $Bin/Denovo//barplot.pl All-Unigene.fa.quality.xls All-Unigene && \\\n";
		$shell .= "cp *txt *pdf *fa *png $mvDir ";
		Mkshell("$shellDir/all_tgicl.sh",$shell);
		foreach my $s (@keys) {
			print SDP "$depends{$s}{'sdp'}\t$shellDir/all_tgicl.sh:4G\n";
		}
		$denovo_info{'fa'} = "$processDir/Merge_for_Tgicl/All-Unigene.fa";
		$denovo_info{'basename_fa'} = basename($denovo_info{'fa'});
		$denovo_info{'sdp'} = "$shellDir/all_tgicl.sh:4G";
		$clean_up .= "[ -d $processDir/Merge_for_Tgicl/Tgicl ] && rm -rf $processDir/Merge_for_Tgicl/Tgicl\n";
	}
	$shell = "perl $Bin/Denovo/assembly_stat.pl -indir $processDir -outdir $processDir && \\\n";
	$shell .= "cp $processDir/assembly_*.stat.xls $Report_2 ";
	Mkshell("$shellDir/assembly_stat.sh", $shell);
	print SDP "$denovo_info{'sdp'}\t$shellDir/assembly_stat.sh:0.1G\n";
	$denovo_info{'sdp'} = "$shellDir/assembly_stat.sh:0.1G";
	close SDP;
}else {
	#add new denovo method here
	die "This version does not support this parameter: Denovo_Method = $conf{'Denovo_Method'}\n";
}
#-----Annotation
my %annot_info = ();
die "Please set Annotation_Method!\n" unless ($conf{'Annotation_Method'});
if ($conf{'Annotation_Method'} =~ /(Blast)/i) {
	my $shellDir = Mkdir("$Outdir/shell/Annotation_$1");
	my $processDir = Mkdir("$Outdir/process/Annotation_$1");
	system("perl $Bin/Annotation/Annotation_sh.pl -fa $denovo_info{'fa'} -dbClass $conf{'Annotation_dbClass'} -dbVersion $conf{'Annotation_dbVersion'} $conf{'Annotation_Options'} -depend $denovo_info{'sdp'} -shDir $shellDir -outDir $processDir -cpDir $Report_3");
	system("mv $shellDir/All.dependence.txt $Outdir/list/Annotation_$1_dependence.txt");
	$annot_info{'annotation'} = "$processDir/annotation.xls";
	$annot_info{'nr'} = "$processDir/$denovo_info{'basename_fa'}.blast.nr.xls";
	$annot_info{'cog'} = "$processDir/$denovo_info{'basename_fa'}.blast.cog.xls";
	$annot_info{'kegg'} = "$processDir/$denovo_info{'basename_fa'}.blast.kegg.xls";
	$annot_info{'swissprot'} = "$processDir/$denovo_info{'basename_fa'}.blast.swissprot.xls";
	$annot_info{'sdp'}	= "$shellDir/annotation_stat.sh:1G";
	$annot_info{'rna_data'} = "$processDir/rna_data";
	$annot_info{'prefix'} = "species";
	$clean_up .= "[ -d $processDir/cog ] && rm -rf $processDir/cog\n";
	$clean_up .= "[ -d $processDir/nr ] && rm -rf $processDir/nr\n";
	$clean_up .= "[ -d $processDir/nt ] && rm -rf $processDir/nt\n";
	$clean_up .= "[ -d $processDir/go ] && rm -rf $processDir/go\n";
	$clean_up .= "[ -d $processDir/kegg ] && rm -rf $processDir/kegg\n";
	$clean_up .= "[ -d $processDir/swissprot ] && rm -rf $processDir/swissprot\n";
	$clean_up .= "[ -d $processDir/interpro ] && rm -rf $processDir/interpro\n";
	$clean_up .= "[ -d $processDir/split_fasta ] && rm -rf $processDir/split_fasta\n";
}else {
	#add new annotation method here
	die "This version does not support this parameter: Annotation_Method = $conf{'Annotation_Method'}\n";
}

#-----SSR detection
if ($conf{'SSR_Method'} && $conf{'SSR_Method'} =~ /(MISA)/i) {
	my $shellDir = Mkdir("$Outdir/shell/SSR_$1");
	my $processDir = Mkdir("$Outdir/process/SSR_$1");
	my $mvDir = Mkdir("$Report_4/SSR");
	open SDP,">$Outdir/list/SSR_$1_dependence.txt" or die $!;
	system("perl $Bin/SSR/SSR_sh.pl -fa $denovo_info{'fa'} -opts \"$conf{'MISA_Options'}\" -shdir $shellDir -outdir $processDir -cpdir $mvDir");
	print SDP "$denovo_info{'sdp'}\t$shellDir/ssr.sh:0.5G\n";
	close SDP;
	my $basename_fasta = $denovo_info{'basename_fa'}; $basename_fasta =~ s/\.fa//;
	$clean_up .= "[ -f $processDir/$basename_fasta.blast.out.xls ] && rm $processDir/$basename_fasta.blast.out.xls\n";
}

#-----TF prediction
if ($conf{'TF_Method'} && $conf{'TF_Method'} =~ /(Hmmsearch)/i) {
	my $shellDir = Mkdir("$Outdir/shell/TFpredict_$1");
	my $processDir = Mkdir("$Outdir/process/TFpredict_$1");
	my $mvDir = Mkdir("$Report_4/TFpredict");
	open SDP,">$Outdir/list/TFpredict_$1_dependence.txt" or die $!;
	my $fasta_prefix = $denovo_info{'basename_fa'};
	$fasta_prefix =~ s/\.fa$//;
	$shell = "$Bin/software/interproscan5/bin/nucleotide/getorf -minsize 150 -sequence $denovo_info{'fa'} -outseq $processDir/$fasta_prefix.orf && \\\n";
	$shell .= "perl $Bin/Annotation/select_orf.pl -seq $denovo_info{'fa'} -input $processDir/$fasta_prefix.orf -output $processDir/$fasta_prefix.pep && \\\n";
	$shell .= "perl $Bin/TF/TFCodingGene_Predict.pl $processDir/$fasta_prefix.pep $fasta_prefix $processDir && \\\n";
	$shell .= "cd $processDir && \\\ncp *pdf *png *xls $mvDir && \\\n";
	$shell .= "cp $Bin/TF/TF_familys.txt $mvDir/Plant_TF_domains.txt ";
	Mkshell("$shellDir/TF_predict.sh", $shell);
	print SDP "$denovo_info{'sdp'}\t$shellDir/TF_predict.sh:0.1G\n";
	close SDP;
}

#-----SNP detection
if ($conf{'SNP_Method'} && $conf{'SNP_Method'} =~ /(GATK)/i) {
	my $shellDir = Mkdir("$Outdir/shell/SNP_$1");
	my $processDir = Mkdir("$Outdir/process/SNP_$1");
	my $mvDir = Mkdir("$Report_4/SNP");
	open SDP,">$Outdir/list/SNP_$1_dependence.txt" or die $!;
	my $IndexDir = Mkdir("$processDir/index-build");
	$shell = "export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
	$shell .= "cd $IndexDir && \\\n";
	$shell .= "perl $Bin/SNP/sort_fa.pl $denovo_info{'fa'} refMrna.fa && \\\n";
	$shell .= "# build hisat index && \\\n";
    $shell .= "$Bin/software/hisat/hisat-build refMrna.fa refMrna && \\\n";
	$shell .= "# build gatk index && \\\n";
	$shell .= "$Bin/software/samtools faidx refMrna.fa && \\\n";
	$shell .= "$Bin/software/picard/CreateSequenceDictionary.jar R=refMrna.fa O=refMrna.dict ";
    Mkshell("$shellDir/build_index.sh",$shell);
    print SDP "$denovo_info{'sdp'}\t$shellDir/build_index.sh:1G\n";
	my @depend = ();
	my %snp_info = ();
	my @depend_depth = ();
	foreach my $s (keys %filter_info) {
		Mkdir("$processDir/$s");
		my $JavaTmpDir = Mkdir("$shellDir/$s/java_tmp");
		$shell = "export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
		$shell .= "cd $processDir/$s && \\\n";
		$shell .= "$Bin/software/hisat/hisat $conf{'HISAT_Options'} -x $IndexDir/refMrna -1 $filter_info{$s}{'fq1'} -2 $filter_info{$s}{'fq2'} -S $s.sam ";
		Mkshell("$shellDir/$s/hisat_align.sh",$shell);
		print SDP "$shellDir/build_index.sh:1G\t$shellDir/$s/hisat_align.sh:2G\n";
		$shell = "cd $processDir/$s && \\\n";
		$shell .= "$Bin/software/java -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/picard/AddOrReplaceReadGroups.jar I=$s.sam O=$s.addRG.bam RGID=$s RGLB=$samp{$s}{'lib'}[0] RGPL=illumina RGPU=machine RGSM=$s VALIDATION_STRINGENCY=SILENT && \\\n";
		$shell .= "$Bin/software/java -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/picard/ReorderSam.jar I=$s.addRG.bam O=$s.addRG.Reorder.bam R=$IndexDir/refMrna.fa VALIDATION_STRINGENCY=SILENT && \\\n";
		$shell .= "$Bin/software/java -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/picard/SortSam.jar I=$s.addRG.Reorder.bam O=$s.addRG.Reorder.Sort.bam SO=coordinate VALIDATION_STRINGENCY=SILENT && \\\n";
		$shell .= "$Bin/software/java -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/picard/MarkDuplicates.jar REMOVE_DUPLICATES=false I=$s.addRG.Reorder.Sort.bam O=$s.addRG.Reorder.Sort.markDup.bam METRICS_FILE=$s.addRG.Reorder.Sort.markDup.metrics VALIDATION_STRINGENCY=SILENT && \\\n";
		$shell .= "$Bin/software/samtools index $s.addRG.Reorder.Sort.markDup.bam && \\\n";
		$shell .= "$Bin/software/java1.8 -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/GenomeAnalysisTK.jar -T SplitNCigarReads -R $IndexDir/refMrna.fa -I $s.addRG.Reorder.Sort.markDup.bam -o $s.addRG.Reorder.Sort.markDup.splitN.bam -rf ReassignOneMappingQuality -RMQF 255 -RMQT 60 -U ALLOW_N_CIGAR_READS && \\\n";
		$shell .= "$Bin/software/samtools index $s.addRG.Reorder.Sort.markDup.splitN.bam && \\\n";
		$shell .= "$Bin/software/java1.8 -Xmx20G  -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/GenomeAnalysisTK.jar -T HaplotypeCaller -R $IndexDir/refMrna.fa -I $s.addRG.Reorder.Sort.markDup.splitN.bam $conf{'GATK_CallSnpOptions'} -o $s.gatk.vcf && \\\n";
		$shell .= "$Bin/software/java1.8 -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/GenomeAnalysisTK.jar -T SelectVariants -R $IndexDir/refMrna.fa -selectType SNP -V $s.gatk.vcf -o $s.gatk.select_snp.vcf && \\\n";
		$shell .= "$Bin/software/java1.8 -Djava.io.tmpdir=$JavaTmpDir -jar $Bin/software/GenomeAnalysisTK.jar -T VariantFiltration -R $IndexDir/refMrna.fa -V $s.gatk.select_snp.vcf $conf{'GATK_FilterOptions'} -o $s.raw.snp.vcf && \\\n";
		$shell .= "mkdir -p ${JavaTmpDir}_RM && $Bin/software/rsync --delete-before -a -H -v --progress --stats ${JavaTmpDir}_RM $JavaTmpDir && rm -rf ${JavaTmpDir}_RM && \\\n";
		$shell .= "awk '(/^#/ || \$7 == \"PASS\")' $s.raw.snp.vcf >$s.snp.vcf && \\\n";
		$shell .= "cp $s.snp.vcf $mvDir ";
		Mkshell("$shellDir/$s/gatk_$s.sh",$shell);
		print SDP "$shellDir/$s/hisat_align.sh:2G\t$shellDir/$s/gatk_$s.sh:20G\n";
		push @depend, "$shellDir/$s/gatk_$s.sh:20G";
		$snp_info{$s}{'snp'} = "$processDir/$s/$s.raw.snp.vcf";
		$snp_info{$s}{'filter'} = "$processDir/$s/$s.snp.vcf";
		if (keys %filter_info > 1) {
			$shell = "$Bin/software/samtools depth $processDir/$s/$s.addRG.Reorder.Sort.bam >$processDir/$s/$s.depth ";
			Mkshell("$shellDir/$s/depth_$s.sh",$shell);
			print SDP "$shellDir/$s/gatk_$s.sh:20G\t$shellDir/$s/depth_$s.sh:0.3G\n";
			push @depend_depth, "$shellDir/$s/depth_$s.sh:0.3G";
			$snp_info{$s}{'depth'} = "$processDir/$s/$s.depth";
		}
		$clean_up .= "rm  $processDir/$s/*.sam $processDir/$s/*.bam $processDir/$s/*.depth\n";
	}
	$shell = "perl $Bin/SNP/snp_statistics.pl -snp " . join(",", map{$snp_info{$_}{'filter'}} keys %snp_info) . " -outdir $processDir && \\\n";
	$shell .= "cp $processDir/SnpSummary* $mvDir ";
	Mkshell("$shellDir/snp_basic_stat.sh",$shell);
	for(my $i=0;$i<=$#depend;$i++) {
		print SDP "$depend[$i]\t$shellDir/snp_basic_stat.sh:0.5G\n";
	}
	if (keys %filter_info > 1) {
		my @keys = sort keys %snp_info;
		$shell = "perl $Bin/SNP/snp_population.pl -snp " . join(",", map{$snp_info{$_}{'snp'}} @keys) . " -depth " . join(",", map{$snp_info{$_}{'depth'}} @keys) . " -outdir $processDir && \\\n";
		$shell .= "cp $processDir/snp_population.xls $mvDir ";
		Mkshell("$shellDir/snp_population_stat.sh",$shell);
		for(my $j=0;$j<=$#depend_depth;$j++) {
			print SDP "$depend_depth[$j]\t$shellDir/snp_population_stat.sh:2G\n";
		}
	}
	close SDP;
}

#-----CDS prediction
if ($conf{'CDS_Method'} && $conf{'CDS_Method'} =~ /(ESTscan)/i) {
	my $shellDir = Mkdir("$Outdir/shell/CDSpredict_$1");
	my $processDir = Mkdir("$Outdir/process/CDSpredict_$1");
	Mkdir("$processDir/Blast");
	Mkdir("$processDir/ESTscan/estscan");
	open SDP,">$Outdir/list/CDSpredict_$1_dependence.txt" or die $!;
	my $mvDir = Mkdir("$Report_4/CDSpredict");
	system("perl $Bin/CDSpredict/CDS_sh.pl -fa $denovo_info{'fa'} -annot $annot_info{'nr'},$annot_info{'swissprot'},$annot_info{'kegg'},$annot_info{'cog'} -shdir $shellDir -outdir $processDir -cpdir $mvDir");
	print SDP "$annot_info{'sdp'}\t$shellDir/cds_predict.sh:1G\n";
	close SDP;
	$clean_up .= "[ -d $processDir/ESTscan/estscan ] && rm -rf $processDir/ESTscan/estscan\n";
}

#-----GeneExpression
my %exp_info = ();
if ($conf{'GeneExp_Method'} && $conf{'GeneExp_Method'} =~ /(RSEM)/i) {
	my $shellDir = Mkdir("$Outdir/shell/GeneExp_$1");
	my $processDir = Mkdir("$Outdir/process/GeneExp_$1");
	my $mvDir = Mkdir("$Report_5/GeneExpression");
	open SDP,">$Outdir/list/GeneExp_$1_dependence.txt" or die $!;
	open LIST,">$processDir/all_exp.list" or die $!;
	my $BowtieIndexDir = Mkdir("$processDir/bowtie-buile");
	my $RsemIndexDir = Mkdir("$processDir/rsem-build");
	$shell = "if [ ! -f $BowtieIndexDir/refMrna.fa ];then ln -s $denovo_info{'fa'} $BowtieIndexDir/refMrna.fa;fi && \\\n";
	$shell .= "grep '^>' $denovo_info{'fa'} | sed 's/>//g' | awk '{print \$1\"\\t\"\$1}' >$processDir/rsem-build/gene2tr.txt && \\\n";
	$shell .= "export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
	$shell .= "$Bin/software/bowtie2/bowtie2-build -f $BowtieIndexDir/refMrna.fa $BowtieIndexDir/refMrna.fa && \\\n";
	$shell .= "$Bin/software/rsem/rsem-prepare-reference $denovo_info{'fa'} $RsemIndexDir/refMrna.fa --bowtie2 --bowtie2-path $Bin/software/bowtie2 --transcript-to-gene-map $processDir/rsem-build/gene2tr.txt ";
	Mkshell("$shellDir/build_index.sh",$shell);
	print SDP "$denovo_info{'sdp'}\t$shellDir/build_index.sh:1G\n";
	my @depend = ();
	foreach my $s (keys %filter_info) {
		Mkdir("$processDir/$s");
		$shell = "export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
		$shell .= "$Bin/software/bowtie2/bowtie2 $conf{'Bowtie2_Options'} -x $BowtieIndexDir/refMrna.fa -1 $filter_info{$s}{'fq1'} -2 $filter_info{$s}{'fq2'} | $Bin/software/samtools view -S -b -o $processDir/$s/$s.bam - && \\\n";
		$shell .= "perl $Bin/GeneExp/BowtieMapStat.pl -bam $processDir/$s/$s.bam -key $processDir/$s/$s.Bowtie2Gene -seqType PE -samtools $Bin/software/samtools -gene2tr $processDir/rsem-build/gene2tr.txt && \\\n";
		$shell .= "$Bin/software/rsem/rsem-calculate-expression --paired-end -p 8 --bam $processDir/$s/$s.bam $RsemIndexDir/refMrna.fa $processDir/$s/$s && \\\n";
		$shell .= "awk '{if(\$7!=0.00)print \$1\"\\t\"\$2\"\\t\"\$3\"\\t\"\$5\"\\t\"\$7}' $processDir/$s/$s.genes.results > $processDir/$s/$s.gene.fpkm.xls && \\\n";
		$shell .= "cp $processDir/$s/$s.gene.fpkm.xls $processDir/$s/$s.Bowtie2Gene.MapReadsStat.xls $mvDir ";
		Mkshell("$shellDir/GeneExp_$s.sh",$shell);
		print SDP "$shellDir/build_index.sh:1G\t$shellDir/GeneExp_$s.sh:5G\n";
		push @depend, "$shellDir/GeneExp_$s.sh:5G";
		$exp_info{'xls'}{$s} = "$processDir/$s/$s.gene.fpkm.xls";
		push @{$exp_info{'sdp'}}, "$shellDir/GeneExp_$s.sh:5G";
		print LIST "$s\t$processDir/$s/$s.gene.fpkm.xls\n";
		$clean_up .= "rm -rf $processDir/$s/*.bam\n";
	}
	$shell = "perl $Bin/GeneExp/AllGeneStat.pl $processDir $processDir/All.GeneExpression.FPKM.xls && \\\n";
	$shell .= "cp $processDir/All.GeneExpression.FPKM.xls $mvDir && \\\n";
	$shell .= "perl $Bin/GeneExp/AllMapStat.pl $processDir $processDir/MappingSummary.xls && \\\n";
	$shell .= "cp $processDir/MappingSummary.xls $mvDir && \\\n";
	if (keys %filter_info >= 4) {
#		Mkdir("$processDir/ConSpecGene"); my $mvDir_csg = Mkdir("$Report_5/GeneExpression/ConSpecGene");
		Mkdir("$processDir/PCA"); my $mvDir_pca = Mkdir("$Report_5/GeneExpression/PCA");
#		$shell .= "perl $Bin/GeneExp/ConSpec.pl -list $processDir/all_exp.list -prefix AllSample $conf{'ConSpecGene_Options'} -outdir $processDir/ConSpecGene && \\\n";
#		$shell .= "perl $Bin/GeneExp/draw_csg.pl $processDir/ConSpecGene && \\\n";
		$shell .= "perl $Bin/GeneExp/PCA_deal.pl -list $processDir/all_exp.list -IDcolumn 1 -Exprcolumn 5 -outdir $processDir/PCA && \\\n";
		$shell .= "perl $Bin/GeneExp/princomp_draw.pl -expr $processDir/PCA/PCA.exp.xls -o $processDir/PCA && \\\n";
#		$shell .= "cp $processDir/ConSpecGene/AllSample.SpecGene*xls $processDir/ConSpecGene/csg_stat.* $mvDir_csg && \\\n";
#		$shell .= "cp $processDir/ConSpecGene/AllSample.SpecGene*xls $mvDir_csg && \\\n";
		$shell .= "cd $processDir/PCA && cp *pdf *png *xls $mvDir_pca  && \\\n";
		if ($conf{'Venny_Group'}) {
			my @venn_files = ();
			my @venn_names = ();
			my %check_dup = ();
			my @groups = split /\s+/,$conf{'Venny_Group'};
			my $mvDir_venn = Mkdir("$Report_5/GeneExpression/Venny");
			foreach my $g (@groups) {
				my @plan = sort (split /,+/, $g);
				my $output = join(".", @plan);
				if ($check_dup{$output}) {
					warn("Warn: GeneExpression Venn Plan [$output] be seted repeatedly! Automatically removed...\n");
					next;
				}
				$check_dup{$output} = 1;
				foreach my $e (@plan) {
					push @venn_names, $e;
					die "Error: can't find sample ID [$e] at $rawList [Venny_Group]\n" unless ($exp_info{'xls'}{$e});
					push @venn_files, $exp_info{'xls'}{$e};
				}
				my $process_venn = Mkdir("$processDir/Venny/$output");
				my $number = scalar(@venn_files);
				$shell .= "perl $Bin/Annotation/venny.pl -infile " . join(",", @venn_files) . " -name " . join(",", @venn_names) . " -header -color -outdir $process_venn -imgname $output.venn && \\\n";
				$shell .= "if [ -d $mvDir_venn/$output ];then rm -rf $mvDir_venn/$output;fi && cp -r $process_venn $mvDir_venn && \\\n";
				@venn_files = ();
				@venn_names = ();
			}
		}
	}
	$shell .= "echo Done! ";
	Mkshell("$shellDir/Statistic_R.sh",$shell);
	for(my $i=0;$i<=$#depend;$i++) {
		print SDP "$depend[$i]\t$shellDir/Statistic_R.sh:0.5G\n";
	}
	close SDP;
	close LIST;
}
#-----GeneDiffExp
my %deg_info = ();
if ($conf{'GeneDiff_Method'}) {
	my $mvDir = Mkdir("$Report_5/DifferentExpressedGene");
	my $shellDir = Mkdir("$Outdir/shell/GeneDiff_Allin");
	my @depends = ();
	$deg_info{'dir'} = "$Outdir/process/GeneDiff_Allin";
	open SDP,">$Outdir/list/GeneDiff_Allin_dependence.txt" or die $!;
	if ($conf{'GeneDiff_Method'} =~ /(PossionDis)/i) {
		my $processDir = Mkdir("$Outdir/process/GeneDiff_Allin/$1");
		open COMP,">$processDir/CompareList.txt" or die $!;
		my %check_dup = ();
		foreach my $vs (split /,+/, $conf{'PossionDis_VS'}) {
			my ($control, $treat) = split /&+/, $vs;
			$control =~ s/^\s*(.*?)\s*$/$1/;
			$treat =~ s/^\s*(.*?)\s*$/$1/;
			if ($check_dup{"$control-VS-$treat"}) {warn "Warn: Compare Plan [$control-VS-$treat] be seted repeatedly!\n";next;}
			$check_dup{"$control-VS-$treat"} = 1;
			die "Error: can't find sample ID [$control] at $rawList\n" unless ($exp_info{'xls'}{$control});
			die "Error: can't find sample ID [$treat] at $rawList\n" unless ($exp_info{'xls'}{$treat});
			print COMP "$control\t$exp_info{'xls'}{$control}\n";
			print COMP "$treat\t$exp_info{'xls'}{$treat}\n";
			$deg_info{'xls'}{"possiondis:$control&$treat"} = "$processDir/$control-VS-$treat.PossionDis_Method.GeneDiffExp.xls";
		}
		close COMP;
		$shell = "perl $Bin/GeneDiffExp/PossionDis.pl -list $processDir/CompareList.txt $conf{'PossionDis_Filter'} -outdir $processDir && \\\n";
		$shell .= "perl $Bin/GeneDiffExp/drawMA-plot.pl -indir $processDir -log2col 5 -exp1col 3 -exp2col 4 -udcol 8 -outdir $processDir && \\\n";
		$shell .= "perl $Bin/GeneDiffExp/drawVolcano-plot.pl -indir $processDir -log2col 5 -signcol 7 -udcol 8 -xlab \"log2(fold change)\" -ylab=\"-log10(FDR)\" -outdir $processDir && \\\n";
	        $shell .= "cp $processDir/*GeneDiffExp*xls $processDir/*.MA-plot.* $processDir/*.Volcano-plot.* $mvDir ";
		Mkshell("$shellDir/deg.possionDis.sh",$shell);
		print SDP "$exp_info{'sdp'}->[$_]\t$shellDir/deg.possionDis.sh:0.5G\n" foreach(0..$#{$exp_info{'sdp'}});
		push @depends, "$shellDir/deg.possionDis.sh:0.5G";
	}
	if ($conf{'GeneDiff_Method'} =~ /(DEseq2)/i) {
		my $processDir = Mkdir("$Outdir/process/GeneDiff_Allin/$1");
		open LIST,">$processDir/SampleList.txt" or die $!;
		open COMP,">$processDir/CompareList.txt" or die $!;
		open GROU,">$processDir/GroupList.txt" or die $!;
		my %check_dup = ();
		my %group = ();
		my %samples = ();
		foreach my $gr (split /\s+/, $conf{'DEseq2_Group'}) {
			my ($name, $samp) = split /:+/,$gr;
			$name =~ s/^\s*(.*?)\s*$/$1/;
			$samp =~ s/^\s*(.*?)\s*$/$1/;
			foreach my $f (split /,+/, $samp) {
				die "Error: can't find sample ID [$f] at $rawList\n" unless ($exp_info{'xls'}{$f});
				$samples{$f} = $exp_info{'xls'}{$f};
			}
			$group{$name} = $samp;
		}
		foreach my $vs (split /,+/, $conf{'DEseq2_VS'}) {
			my ($control, $treat) = split /&+/, $vs;
			$control =~ s/^\s*(.*?)\s*$/$1/;
			$treat =~ s/^\s*(.*?)\s*$/$1/;
			if ($check_dup{"$control-VS-$treat"}) {warn "Warn: Compare Plan [$control-VS-$treat] be seted repeatedly!\n";next;}
			$check_dup{"$control-VS-$treat"} = 1;
			die "Error: can't find group ID [$control] at DEseq2_Group options\n" unless ($group{$control});
			die "Error: can't find group ID [$treat] at DEseq2_Group options\n" unless ($group{$treat});
			print COMP "$group{$control}\t$group{$treat}\n";
			$deg_info{'xls'}{"deseq2:$control&$treat"} = "$processDir/$control-VS-$treat.DEseq2_Method.GeneDiffExp.xls";
		}
		foreach my $g (keys %group) {print GROU "$g\t$group{$g}\n";}
		foreach my $s (keys %samples) {print LIST "$s\t$samples{$s}\n";}
		close LIST;close COMP;close GROU;
		$shell = "export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
		$shell .= "perl $Bin/GeneDiffExp/DEseq2.pl -list $processDir/SampleList.txt -diff $processDir/CompareList.txt -group $processDir/GroupList.txt $conf{'DEseq2_Filter'} -outdir $processDir && \\\n";
		$shell .= "perl $Bin/GeneDiffExp/drawMA-plot.pl -indir $processDir -log2col 5 -exp1col 3 -exp2col 4 -udcol 8 -outdir $processDir && \\\n";
		$shell .= "perl $Bin/GeneDiffExp/drawVolcano-plot.pl -indir $processDir -log2col 5 -signcol 7 -udcol 8 -xlab \"log2(fold change)\" -ylab=\"-log10(Padj)\" -outdir $processDir && \\\n";
        $shell .= "cp $processDir/*GeneDiffExp*xls $processDir/*.MA-plot.* $processDir/*.Volcano-plot.* $mvDir ";
		Mkshell("$shellDir/deg.deseq2.sh",$shell);
		print SDP "$exp_info{'sdp'}->[$_]\t$shellDir/deg.deseq2.sh:0.5G\n" foreach(0..$#{$exp_info{'sdp'}});
		push @depends, "$shellDir/deg.deseq2.sh:0.5G";
	}
	if ($conf{'GeneDiff_Method'} =~ /(NOIseq)/i) {
		my $processDir = Mkdir("$Outdir/process/GeneDiff_Allin/$1");
        open LIST,">$processDir/SampleList.txt" or die $!;
        open COMP,">$processDir/CompareList.txt" or die $!;
        open GROU,">$processDir/GroupList.txt" or die $!;
        my %check_dup = ();
        my %group = ();
        my %samples = ();
        foreach my $gr (split /\s+/, $conf{'NOIseq_Group'}) {
            my ($name, $samp) = split /:+/,$gr;
            $name =~ s/^\s*(.*?)\s*$/$1/;
            $samp =~ s/^\s*(.*?)\s*$/$1/;
            foreach my $f (split /,+/, $samp) {
                die "Error: can't find sample ID [$f] at $rawList\n" unless ($exp_info{'xls'}{$f});
                $samples{$f} = $exp_info{'xls'}{$f};
            }
            $group{$name} = $samp;
        }
        foreach my $vs (split /,+/, $conf{'NOIseq_VS'}) {
            my ($control, $treat) = split /&+/, $vs;
			$control =~ s/^\s*(.*?)\s*$/$1/;
            $treat =~ s/^\s*(.*?)\s*$/$1/;
            if ($check_dup{"$control-VS-$treat"}) {warn "Warn: Compare Plan [$control-VS-$treat] be seted repeatedly!\n";next;}
			$check_dup{"$control-VS-$treat"} = 1;
            die "Error: can't find group ID [$control] at NOIseq_Group options\n" unless ($group{$control});
            die "Error: can't find group ID [$treat] at NOIseq_Group options\n" unless ($group{$treat});
            print COMP "$group{$control}\t$group{$treat}\n";
			$deg_info{'xls'}{"noiseq:$control&$treat"} = "$processDir/$control-VS-$treat.NOIseq_Method.GeneDiffExp.xls";
        }
        foreach my $g (keys %group) {print GROU "$g\t$group{$g}\n";}
        foreach my $s (keys %samples) {print LIST "$s\t$samples{$s}\n";}
        close LIST;close COMP;close GROU;
        $shell = "perl $Bin/GeneDiffExp/NOIseq.pl -list $processDir/SampleList.txt -diff $processDir/CompareList.txt -group $processDir/GroupList.txt $conf{'NOIseq_Filter'} -outdir $processDir && \\\n";
        $shell .= "perl $Bin/GeneDiffExp/drawMA-plot.pl -indir $processDir -log2col 5 -exp1col 3 -exp2col 4 -udcol 7 -outdir $processDir && \\\n";
	$shell .= "perl $Bin/GeneDiffExp/drawVolcano-plot.pl -indir $processDir -log2col 5 -signcol 6 -udcol 7 -noiseq -xlab \"log2(fold change)\" -ylab=\"-log10(1-Probability)\" -outdir $processDir && \\\n";
	$shell .= "cp $processDir/*GeneDiffExp*xls $processDir/*.MA-plot.* $processDir/*.Volcano-plot.* $mvDir ";
        Mkshell("$shellDir/deg.noiseq.sh",$shell);
        print SDP "$exp_info{'sdp'}->[$_]\t$shellDir/deg.noiseq.sh:0.5G\n" foreach(0..$#{$exp_info{'sdp'}});
        push @depends, "$shellDir/deg.noiseq.sh:0.5G";
	}
	if ($conf{'GeneDiff_Method'} =~ /(EBseq)/i) {
		 my $processDir = Mkdir("$Outdir/process/GeneDiff_Allin/$1");
        open LIST,">$processDir/SampleList.txt" or die $!;
        open COMP,">$processDir/CompareList.txt" or die $!;
        open GROU,">$processDir/GroupList.txt" or die $!;
        my %check_dup = ();
        my %group = ();
        my %samples = ();
        foreach my $gr (split /\s+/, $conf{'EBseq_Group'}) {
            my ($name, $samp) = split /:+/,$gr;
            $name =~ s/^\s*(.*?)\s*$/$1/;
            $samp =~ s/^\s*(.*?)\s*$/$1/;
            foreach my $f (split /,+/, $samp) {
                die "Error: can't find sample ID [$f] at $rawList\n" unless ($exp_info{'xls'}{$f});
                $samples{$f} = $exp_info{'xls'}{$f};
            }
            $group{$name} = $samp;
        }
        foreach my $vs (split /,+/, $conf{'EBseq_VS'}) {
            my ($control, $treat) = split /&+/, $vs;
			$control =~ s/^\s*(.*?)\s*$/$1/;
            $treat =~ s/^\s*(.*?)\s*$/$1/;
            if ($check_dup{"$control-VS-$treat"}) {warn "Warn: Compare Plan [$control-VS-$treat] be seted repeatedly!\n";next;}
			$check_dup{"$control-VS-$treat"} = 1;
            die "Error: can't find group ID [$control] at EBseq_Group options\n" unless ($group{$control});
            die "Error: can't find group ID [$treat] at EBseq_Group options\n" unless ($group{$treat});
            print COMP "$group{$control}\t$group{$treat}\n";
			$deg_info{'xls'}{"ebseq:$control&$treat"} = "$processDir/$control-VS-$treat.EBseq_Method.GeneDiffExp.xls";
        }
        foreach my $g (keys %group) {print GROU "$g\t$group{$g}\n";}
        foreach my $s (keys %samples) {print LIST "$s\t$samples{$s}\n";}
        close LIST;close COMP;close GROU;
        $shell = "perl $Bin/GeneDiffExp/EBseq.pl -list $processDir/SampleList.txt -diff $processDir/CompareList.txt -group $processDir/GroupList.txt $conf{'EBseq_Filter'} -outdir $processDir && \\\n";
        $shell .= "perl $Bin/GeneDiffExp/drawMA-plot.pl -indir $processDir -log2col 5 -exp1col 3 -exp2col 4 -udcol 7 -outdir $processDir && \\\n";
	$shell .= "perl $Bin/GeneDiffExp/drawVolcano-plot.pl -indir $processDir -log2col 5 -signcol 6 -udcol 7 -xlab \"log2(fold change)\" -ylab=\"-log10(PPEE)\" -outdir $processDir && \\\n";
	$shell .= "cp $processDir/*GeneDiffExp*xls $processDir/*.MA-plot.* $processDir/*.Volcano-plot.* $mvDir ";
        Mkshell("$shellDir/deg.ebseq.sh",$shell);
        print SDP "$exp_info{'sdp'}->[$_]\t$shellDir/deg.ebseq.sh:0.5G\n" foreach(0..$#{$exp_info{'sdp'}});
        push @depends, "$shellDir/deg.ebseq.sh:0.5G";
	}
	$shell = "perl $Bin/GeneDiffExp/draw_barplot.pl -indir $mvDir -outdir $mvDir ";
	Mkshell("$shellDir/barplot.sh",$shell);
	for(my $i=0;$i<=$#depends;$i++) {
		print SDP "$depends[$i]\t$shellDir/barplot.sh:0.1G\n";
	}
	$deg_info{'sdp'} = "$shellDir/barplot.sh:0.1G";
	close SDP;
}
#-----Cluster
my %cluster_info = ();
if ($conf{'Cluster_Method'} && $conf{'Cluster_Method'} =~ /(R)/i) {
	my $shellDir = Mkdir("$Outdir/shell/Cluster_$1");
	my $processDir = Mkdir("$Outdir/process/Cluster_$1");
	my $mvDir = Mkdir("$Report_5/DifferentExpressedGene/Cluster");
	open SDP,">$Outdir/list/Cluster_$1_dependence.txt" or die $!;
	my %check_dup = ();
	my $shell_rank = 1;
	foreach my $plan (split /\s+/, $conf{'Cluster_Plan'}) {
		my @a = split /,+/, $plan;
		foreach my $d (@a) {
			$d =~ s/\s//g;
			my ($method, $vs) = split /:+/,$d;
			$method = lc($method);
			my $key = "$method:$vs";
			die "Error: can't find DiffCompare [$d] all over the compare plan\n!" unless ($deg_info{'xls'}{$key});
			$d = $key;
		}
		my $plan_new = join(",",@a);
		if ($check_dup{$plan_new}) {warn "Warn: Cluster Plan [$plan_new] be seted repeatedly!\n";next;}
		$check_dup{$plan_new} = 1;
		my $output_prefix = join("-", map{$deg_info{'xls'}{$_} =~ /.*\/(.*)_Method\..*$/;$1} @a);
#		$output_prefix = (length($output_prefix) > 100) ? substr($output_prefix,0,100) : $output_prefix; 
		$shell = "perl $Bin/Cluster/Cluster_R.pl -list " . join(",", map{$deg_info{'xls'}{$_}} @a) . " -log2col 5 -outdir $processDir && \\\n";
		$shell .= "cp $processDir/$output_prefix* $mvDir ";
		Mkshell("$shellDir/deg.cluster_$shell_rank.sh",$shell);
		print SDP "$deg_info{'sdp'}\t$shellDir/deg.cluster_$shell_rank.sh:2G\n";
		$shell_rank++;
	}
	close SDP;
}
#-----GO Enrichment
if ($conf{'GO_Method'} && $conf{'GO_Method'} =~ /(Hypergeometric)/i) {
	my $shellDir = Mkdir("$Outdir/shell/GO_$1");
	my $processDir = Mkdir("$Outdir/process/GO_$1/GO");
	my $tmpDir = Mkdir("$Outdir/process/GO_$1/tmp_file");
	my $mvDir = Mkdir("$Report_5/DifferentExpressedGene/Functional_Enrichment/GO");
	open SDP,">$Outdir/list/GO_$1_dependence.txt" or die $!;
	$shell = "#export LD_LIBRARY_PATH=$Bin/software/RNA_lib:\$LD_LIBRARY_PATH && \\\n";
	$shell .= "goclass=`cat $Bin/Annotation/db_version.txt | grep -v '^#' |awk '(\$2 == \"goclass\"){print \$3}'` && \\\n";
	$shell .= "outdir=$processDir && \\\n";
	$shell .= "tmpdir=$tmpDir && \\\n";
	$shell .= "prefix=$annot_info{'rna_data'}/$annot_info{'prefix'} && \\\n";
	$shell .= "refGene=$denovo_info{'fa'} && \\\n";
	$shell .= "for i in `ls $deg_info{'dir'}/*/*_Method.GeneDiffExpFilter.xls`\ndo\n\tkeyname=`echo \$i|sed 's/.*\\/\\(.*\\).GeneDiffExpFilter.xls/\\1/'`\n\tawk '{print \$1\"\\t\"\$5}' \$i >\$tmpdir/\$keyname.glist\n\tperl $Bin/Annotation/drawGO.pl -list \$tmpdir/\$keyname.glist -goclass \$goclass -goprefix \$prefix -outprefix \$outdir/\$keyname\ndone && \\\n";
	$shell .= "perl $Bin/Enrichment/go.pl -gldir \$tmpdir -sdir `dirname \$prefix` -species `basename \$prefix` -outdir \$outdir && \\\n";
	$shell .= "grep '^>' \$refGene | sed 's/>//g' | awk '{print \$1}' >\$tmpdir/total_gene.id && \\\n";
	$shell .= "perl $Bin/Enrichment/topGO.pl -gldir \$tmpdir -godir \$outdir -prefix \$prefix -list \$tmpdir/total_gene.id -outdir \$outdir && \\\n";
	$shell .= "if [ -d $mvDir ];then rm -rf $mvDir;fi && \\\n";
	$shell .= "mkdir -p $mvDir && \\\n";
	$shell .= "mv $processDir/* $mvDir ";
	Mkshell("$shellDir/go_enrichment.sh", $shell);
	print SDP "$deg_info{'sdp'}\t$shellDir/go_enrichment.sh:2G\n";
	print SDP "$annot_info{'sdp'}\t$shellDir/go_enrichment.sh:2G\n";
	close SDP;
}
#-----Pathway Enrichment
if ($conf{'Pathway_Method'} && $conf{'Pathway_Method'} =~ /(Hypergeometric)/i) {
	my $shellDir = Mkdir("$Outdir/shell/Pathway_$1");
	my $processDir = Mkdir("$Outdir/process/Pathway_$1/Pathway");
	my $tmpDir = Mkdir("$Outdir/process/Pathway_$1/tmp_file");
	my $mvDir = Mkdir("$Report_5/DifferentExpressedGene/Functional_Enrichment/Pathway");
	open SDP,">$Outdir/list/Pathway_$1_dependence.txt" or die $!;
	$shell = "keggFa=`cat $Bin/Annotation/db_version.txt | grep -v '^#' |awk '(\$2 == \"$conf{'Annotation_dbClass'}\"){print \$3}'` && \\\n";
	$shell .= "koMap=`cat $Bin/Annotation/db_version.txt | grep -v '^#' |awk '(\$2 == \"$conf{'Annotation_dbClass'}_komap\"){print \$3}'` && \\\n";
	$shell .= "mapTitle=`cat $Bin/Annotation/db_version.txt | grep -v '^#' |awk '(\$2 == \"map_title\"){print \$3}'` && \\\n";
	$shell .= "mapDir=`cat $Bin/Annotation/db_version.txt | grep -v '^#' |awk '(\$2 == \"map_dir\"){print \$3}'` && \\\n";
	$shell .= "outdir=$processDir && \\\n";
	$shell .= "tmpdir=$tmpDir && \\\n";
	$shell .= "bg=$annot_info{'rna_data'}/$annot_info{'prefix'}.ko && \\\n";
	$shell .= "for i in `ls $deg_info{'dir'}/*/*_Method.GeneDiffExpFilter.xls`\ndo\n\tkeyname=`echo \$i|sed 's/.*\\/\\(.*\\).GeneDiffExpFilter.xls/\\1/'`\n\tawk '{print \$1\"\\t\"\$5}' \$i >\$tmpdir/\$keyname.glist\n\tperl $Bin/Enrichment/getKO.pl -glist \$tmpdir/\$keyname.glist -bg \$bg -outdir \$tmpdir\n\tperl $Bin/Annotation/pathfind.pl -kegg \$keggFa -komap \$koMap -maptitle \$mapTitle -fg \$tmpdir/\$keyname.ko -bg \$bg -output \$outdir/\$keyname.path\n\t[ -d \$outdir/\$keyname\\_map ] && rm -rf \$outdir/\$keyname\\_map\n\tmkdir -p \$outdir/\$keyname\\_map\n\tperl $Bin/Enrichment/keggMap.pl -ko \$tmpdir/\$keyname.ko -diff \$tmpdir/\$keyname.glist -komap \$koMap -mapdir \$mapDir -outdir \$outdir/\$keyname\\_map\n\tperl $Bin/Annotation/drawKEGG.pl -path \$outdir/\$keyname.path -outprefix \$outdir/\$keyname -idCol 6 -level1Col 7 -level2Col 8 -geneCol 9\ndone && \\\n";
	$shell .= "perl $Bin/Annotation/genPathHTML.pl -indir \$outdir && \\\n";
	$shell .= "perl $Bin/Enrichment/pathway_enrichFigure.pl \$outdir && \\\n";
	$shell .= "if [ -d $mvDir ];then rm -rf $mvDir;fi && \\\n";
	$shell .= "mkdir -p $mvDir && \\\n";
	$shell .= "mv $processDir/* $mvDir ";
	Mkshell("$shellDir/pathway_enrichment.sh",$shell);
	print SDP "$deg_info{'sdp'}\t$shellDir/pathway_enrichment.sh:1G\n";
	print SDP "$annot_info{'sdp'}\t$shellDir/pathway_enrichment.sh:1G\n";
	close SDP;
}

#-----Monitor
system("cat $Outdir/list/*dependence.txt >$Outdir/list/qsub.conf");
open S1,">$Outdir/step1.qsub.sh" or die $!;
print S1 "$Bin/software/monitor taskmonitor $conf{'Qsub'} -p $conf{'ProjectName'} -i $Outdir/list/qsub.conf\n";
close S1;

#-----QC
my $qcDir = Mkdir("$Outdir/QC");
open S2,">$Outdir/step2.QC.sh" or die $!;
print S2 "perl $Bin/QC/RNAdenovo_IQC.pl -SubProjectname $conf{'ProjectName'} -list $rawList -indir $Outdir/Transcriptome_Denovo_Report -DPD $conf{'Department'} -Gnum $conf{'CleanGnum'} -outdir $qcDir\n";
print S2 "perl $Bin/QC/RNAdenovo_PQC.pl -SubProjectname $conf{'ProjectName'} -indir $Outdir/Transcriptome_Denovo_Report -DPD $conf{'Department'} -Species $conf{'Species'} -outdir $qcDir\n";
print S2 "perl $Bin/QC/CollectInfo.pl -email $conf{'AnalystEmail'} -qcdir $qcDir -processdir $Outdir/process\n";
close S2;

#-----Report
my $reportDir = "$Outdir/Transcriptome_Denovo_Report";
open S3,">$Outdir/step3.report.sh" or die $!;
print S3 "perl $Bin/AddDesc/AddDescription.pl $reportDir $reportDir/BGI_result/3.Annotation/annotation.xls\n"; #######

print S3 "perl $Bin/ArfReport/genArfReport_en.pl -indir $reportDir -conf $Config\n";
print S3 "perl $Bin/ArfReport/genArfReport_cn.pl -indir $reportDir -conf $Config\n" if ($conf{'ChineseReport'} && $conf{'ChineseReport'} =~ /YES/i);
#
#Thu Sep 29 12:23:06 CST 2016
print S3 "#add descript\n";
print S3 "perl $Bin/Annotation/AddDescription1.pl  $Outdir  $Outdir/process/Annotation_Blast/annotation.xls  $Outdir\n";
#
print S3 "\ncd $Outdir\n";
print S3 "tar zcf Transcriptome_Denovo_Report.tar.gz Transcriptome_Denovo_Report\n";
print S3 "md5sum Transcriptome_Denovo_Report.tar.gz >Transcriptome_Denovo_Report.tar.gz.md5\n";
close S3;

#-----Upload
open S4,">$Outdir/step4.upload.sh" or die $!;
my ($Pj, $subPj) = split /_/,$conf{'ProjectName'};
die "Error: ProjectName format should be: ProjectNo_SubProjectCode \n" unless ($Pj && $subPj);
print S4 "$Bin/software/upload.sh.x -usr $conf{'CDTS_usr'} -pwd $conf{'CDTS_pwd'} -area $conf{'CDTS_loc'} -id $subPj -n \"$subPj [Transcriptome Denovo Project]\" -f $Outdir/Transcriptome_Denovo_Report.tar.gz -p /$Pj/$subPj\n";
close S4;

#-----CleanUp
open CU,">$Outdir/CleanUp.sh" or die $!;
print CU $clean_up;
close CU;

#-----BackUp
open BU,">$Outdir/BackUp.sh" or die $!;
print BU <<CODE;
cd $Outdir
if [ -d BackUp ];then rm -rf BackUp;fi
mkdir -p BackUp
cp Transcriptome_Denovo_Report.tar.gz Transcriptome_Denovo_Report.tar.gz.md5 BackUp

cd $annot_info{'rna_data'}/../
tar zcf rna_data.tar.gz rna_data
md5sum rna_data.tar.gz >rna_data.tar.gz.md5
mv rna_data.tar.gz* $Outdir/BackUp

cp $Config $rawList $Outdir/BackUp
cp -rL $Outdir/QC $Outdir/BackUp

CODE
close BU;

exit;

#-----Sub Functions
sub Mkdir {
	my $path = shift;
	`mkdir -p $path` unless (-d $path);
	return $path;
}

sub Mkshell {
	# Copy from AnaMethod.pm
    my ($output_shell, $content, $finish_string) = @_;
	die "Error: content is null!\n" if ($content =~ /^\s*$/);
    unlink glob "$output_shell.*";
    $finish_string ||= "Still_waters_run_deep";
    open OUT,">$output_shell" or die "Cannot open file $output_shell:$!";
    print OUT "#!/bin/bash\n";
    print OUT "echo ==========start at : `date` ==========\n";
    print OUT "$content && \\\n";
    print OUT "echo ==========end at : `date` ========== && \\\n";
    print OUT "echo $finish_string 1>&2 && \\\n";
    print OUT "echo $finish_string > $output_shell.sign\n";
    close OUT;
}

sub Mv {
	my $cmd = shift;
	my @files = split /\s+/,$cmd;
	my $to = pop @files;
	my $shell = "";
	foreach my $f (@files) {
		my $basename = basename($f);
		my $dirname = dirname($f);
		$shell .= "mv $f $to && ln -s $to/$basename $dirname && \\\n";
	}
	$shell =~ s/\&\& \\\n$//;
	return $shell;
}

sub MaxNum {
	my @nums = @_;
	my $max = shift @nums;
	foreach my $i (@nums) {
		$max = ($max > $i) ? $max : $i;
	}
	return $max;
}
