
file1 = "0-phased_variants.vcf"
file2 = "1-phased_variants.vcf"

# file1 = "0-large_svs.vcf"
# file2 = "1-large_svs.vcf"

infile1 = open(file1, "r")
infile2 = open(file2, "r")

set1 = set()
set2 = set()

for line in infile1:
	line_list = line.strip().split()
	set1.add("_".join(line_list))

for line in infile2:
	line_list = line.strip().split()
	set2.add("_".join(line_list))

print("count_1: ", len(set1))
print("count_2: ", len(set2))
print("mutual count: ", len(set1&set2))

infile1.close()
infile2.close()