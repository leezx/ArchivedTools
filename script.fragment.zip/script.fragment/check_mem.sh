#!/bin/bash

id=4666304
a=`qstat -j $id | grep usage | cut -d \, -f 5 | cut -d = -f 2`
#echo $a
#cur_date=`date`
cur_date=`date | cut -d \  -f 2-5`

while true 
do
	echo "$cur_date : $a" >> mem.log
	sleep 3600
done
