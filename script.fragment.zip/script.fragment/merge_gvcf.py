infile_1 = "PB_1.g.vcf"
infile_2 = "PB_2_filter.g.vcf"
infile_3 = "PB_3_filter.g.vcf"
infile_4 = "PB_4_filter.g.vcf"
infile_5 = "PB_5_filter.g.vcf"
out_file = "PB.g.vcf"
outf = open(out_file, "w")

file_list = [infile_1, infile_2, infile_3, infile_4, infile_5]

for one in file_list:
    inf = open(one, "r")
    for line in inf:
        print(line.strip(), file=outf)
    inf.close()
    
outf.close()

