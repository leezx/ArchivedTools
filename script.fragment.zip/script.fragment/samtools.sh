samtools view -h /ifs4/BC_RD/USER/chenjing6/DNA/WGS/WGS_demo/outdir/result/NA12878-WGSPE100-1/result_alignment/NA12878-WGSPE100-1.bam chrM > chrM.sam
