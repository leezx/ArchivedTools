#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
trans_fastq_to_fasta with pysam, no RQ left!
please input a fastq file!!!!!
"""

import pysam
import sys

if len(sys.argv) -1 != 1:
    sys.exit(__doc__)

in_file = sys.argv[1]

if in_file.split(".")[-1] != "fastq":
    sys.exit(__doc__)
# in_file = "./merge_corrected_20X.fastq"
fastq = pysam.FastxFile(in_file)
# out_file = "./trans.fastq"
out_file_fasta = in_file.split(".")[0] + ".fasta"
# out_fastq = open(out_file, "w")
out_fasta = open(out_file_fasta, "w")

for line in fastq:
    print(">"+line.name, line.sequence, file = out_fasta, sep = '\n', end = '\n')
    # print('@'+line.name, line.sequence, '+', len(line.sequence)*']', file = out_fastq, sep = '\n', end = '\n')

fastq.close()
out_fasta.close()
# out_fastq.close()
