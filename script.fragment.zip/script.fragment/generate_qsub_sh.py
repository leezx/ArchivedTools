#!/usr/bin/env python
# Author: LI ZHIXIN
"""
generate the shell script to be qsub, and auto qsub.
Usage: python <script> <in.bam.dir> 
"""
import os
from subprocess import call

if len(sys.argv) -1 != 1:
        sys.exit(__doc__)

split_bam_dir = sys.argv[1]
#split_bam_dir = "../split_bam/"
bam_file_list = os.listdir(split_bam_dir)

sh_count = 0
for one_file in bam_file_list:
	sh_count += 1
	temp_sh_file = "./run_" + str(sh_count) + ".sh"
	temp_bam_file = os.path.join(split_bam_dir, one_file)
	temp_out_file = "./corrected_" +str(sh_count) + ".fastq"
	temp_stat_file =  "./stat_" +str(sh_count) + ".txt"
	outf = open(temp_sh_file, "w")
	head = "#!/bin/bash\necho ==========start at : `date` =========="
	tail = "echo ==========end  at : `date` =========="
	cmd = "python main_for_denovo_all_I.py %s %s %s" % (temp_bam_file, temp_out_file, temp_stat_file)
	print(head, cmd, tail, file=outf, sep='\n', end='\n')
	outf.close()

	qsub_cmd = "qsub -cwd -l vf=1g -P HUMDnab -q bc.q,bc_rd.q %s" % (temp_sh_file)
	qsub_cmd_list = qsub_cmd.split()
	call(qsub_cmd_list)
	
