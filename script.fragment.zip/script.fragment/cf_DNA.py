#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2017-03-09 11:13:11
# @Author  : Your Name (you@example.org)
# @Link    : http://example.org
# @Version : $Id$

def read_file_to_dict(file):
    my_dict = {}
    with open(file, "r") as inf:
        for line in inf:
            chr_num, pos = line.strip().split()
            if not chr_num in my_dict.keys():
                my_dict[chr_num] = []
            else:
                my_dict[chr_num].append(pos)
    return my_dict

def read_file_to_set(file):
    my_set = set()
    with open(file, "r") as inf:
        for line in inf:
            chr_num, pos = line.strip().split()
            my_set.add(str(chr_num)+str(pos))
    return my_set

def compare_two_dict(dict1, dict2):
    dict1_len = 0; dict2_len = 0
    for chr_num in dict1.keys():
        dict1_len += len(dict1[chr_num])
        dict2_len += len(dict2[chr_num])
    dict1_uniq = 0; dict2_uniq = 0
    share = 0
    for chr_num in dict1.keys():
        pos_list = dict1[chr_num]
        for pos in pos_list:
            if pos in dict2[chr_num]:
                share += 1
            else:
                dict1_uniq += 1
    dict2_uniq = dict2_len - share
    return dict1_len, dict2_len, dict1_uniq, dict2_uniq, share

def compare_two_set(set1, set2):
    set1_len = len(set1); set2_len = len(set2)
    set1_uniq = len(set1-set2); set2_uniq = len(set2-set1)
    overlap = len(set1&set2)
    return set1_len, set2_len, set1_uniq, set2_uniq, overlap

# outf = open("result.txt", "w")
with open("list.txt", "r") as list_file:
    for line in list_file:
        file_1, file_2 = line.strip().split()
        # dict1 = read_file_to_dict(file_1)
        # dict2 = read_file_to_dict(file_2)
        set1 = read_file_to_set(file_1)
        set2 = read_file_to_set(file_2)
        set1_len, set2_len, set1_uniq, set2_uniq, overlap = compare_two_set(set1, set2)
        print(file_1, "overlap", file_2, sep='\t')
        print(set1_uniq, overlap, set2_uniq, sep='\t')
        print("total\n", file_1, set1_len, '\n', file_2, set2_len, sep='\t')
# outf.close()
        # break
