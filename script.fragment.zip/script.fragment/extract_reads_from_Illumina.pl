#!/usr/bin/perl
#usage: perl test.pl --fastqlist=pair_list.txt --read_name_list=read_name_list 
use strict;
use warnings;
use Getopt::Long;

my ($fastqlist, $read_name_list);
GetOptions(
	"fastqlist=s" => \$fastqlist,
	"read_name_list=s" => \$read_name_list,
) or die $!;

my %read_name;
open NAME, "<./$read_name_list" or die $!;
while(<NAME>){
	chomp;
	my $name_file = $_;
	open NAMEFILE, "</public/home/zxli/my_Project/wheat/workdir/Illumina_bwa_sam/read_name/$name_file" or die $!;
	while(<NAMEFILE>){
		chomp;
		my $readname = $_;
		$read_name{$readname} = "";
	}
	print "$name_file is done!\n"; #test
	close NAMEFILE;
}
close NAME;

open FASTQ, "<./$fastqlist" or die $!;

while(<FASTQ>){
	chomp;
	my($r1, $r2) = split /\t/;
	open R1, "gzip -dc /public/home/zxli/my_Project/wheat/Illumina_reads/$r1|" or die $!;
    print "use $r1 now...\n"; #test
    open NR1, ">>./Illumina_R1.fastq" or die $!;
    
	while(<R1>){
		chomp;
		my $line1 = $_;
		my $title = $1 if $line1=~/^@(\S+)\s/;
		my $line2 = <R1>;
		my $line3 = <R1>;
		my $line4 = <R1>;

		if (not exists $read_name{$title}){
			print NR1 "${line1}\n${line2}${line3}${line4}";
		}else{
            print "1";
        }
	}
    close R1;
    close NR1;
    
    open R2, "gzip -dc /public/home/zxli/my_Project/wheat/Illumina_reads/$r2|" or die $!;
	print "use $r2 now...\n"; #test
    open NR2, ">>./Illumina_R2.fastq" or die $!;
    
	while(<R2>){
		chomp;
		my $line1 = $_;
		my $title = $1 if $line1=~/^@(\S+)\s/;
		my $line2 = <R2>;
		my $line3 = <R2>;
		my $line4 = <R2>;

		if (not exists $read_name{$title}){
			print NR2 "${line1}\n${line2}${line3}${line4}";
		}else{
            print "2";
        }
	}
    close R2;
    close NR2;
}

close FASTQ;