import pysam

reff = pysam.FastaFile("/ifs4/BC_RD/USER/lizhixin/my_project/chr22_asm_ref_nX/20X_DBG2OLC_chr22/denovo/DBG2OLC_denovo.fasta")
leftf = pysam.FastaFile("./left.fasta")
rightf = pysam.FastaFile("./right.fasta")
outf = open("./merged_DBG2OLC_denovo.fasta", "w")

for seq_name in reff.references:
	ref_seq = reff.fetch(seq_name)
	left_seq = leftf.fetch(seq_name)
	right_seq = rightf.fetch(seq_name)
	merge_seq = left_seq + ref_seq + right_seq
	print(">"+seq_name, merge_seq, file=outf, sep='\n', end='\n')

reff.close()
leftf.close()
rightf.close()
outf.close()