#!/usr/bin/perl

use strict;
use warnings;
use Getopt::Long;
use Cwd qw(abs_path);

=head1 Name
	ASSEMBLE Result statistics

=head1 USAGE
	perl Assemble_stat.pl -cmap <filename.cmap>	-fa <filename.fa> -o <outdir>

		-cmap 	<str>		the cmap file
		-fa 	<str>		the fa file
		-min    <int>      	the min scafford/contig length(kb)
		-prefix	<str>		the prefix of result file
		-o	<str>		the output dir
		-h			the information of help

=cut

my ($cmap, $fa, $outdir, $min, $prefix, $help);
GetOptions(
	"cmap:s" => \$cmap,
	"fa:s" => \$fa,
	"o:s" => \$outdir,
	"min:f" => \$min,
	"prefix:s" => \$prefix,
	"h" => \$help,
);

die `pod2text $0` if ((!$cmap && !$fa) || $help); 

$outdir ||= "./";
$prefix ||="Result";
$min ||= 0;
mkdir $outdir unless(-d $outdir);
$outdir = abs_path($outdir);

if ($cmap){
	if ($cmap =~ /gz/){
		open IN, "gzip -dc $cmap |" or die $!;
	}else{
		open IN, "$cmap" or die $!;
	}
	my $result_file = "$prefix\_assemble_cmap.stat";
	open OUT, ">$outdir/$result_file" or die $!;
	my $id = 0;
	my @contig ;
	my $total_len =0;
	while(<IN>){
		chomp;
		$_ =~ s/^\s+//;
		next if ($_ =~ /^#/);
		my @tmp = split /\s/;
		next if ($id == $tmp[0]);
		push @contig, $tmp[1];
		$total_len += $tmp[1];
		$id = $tmp[0];
	}	
	@contig = sort {$b<=>$a} @contig;
	my $total_n = scalar(@contig);
	my $ave_len = $total_len/$total_n;
	my $max_len = $contig[0];
	my $min_len = $contig[-1];
	my ($N90, $N90_n) = nx(90, \@contig, $total_len);
	my ($N80, $N80_n) = nx(80, \@contig, $total_len);
	my ($N70, $N70_n) = nx(70, \@contig, $total_len);
	my ($N60, $N60_n) = nx(60, \@contig, $total_len);
	my ($N50, $N50_n) = nx(50, \@contig, $total_len);
	my ($N40, $N40_n) = nx(40, \@contig, $total_len);
	my ($N30, $N30_n) = nx(30, \@contig, $total_len);
	my ($N20, $N20_n) = nx(20, \@contig, $total_len);
	my ($N10, $N10_n) = nx(10, \@contig, $total_len);
	my $n1m = mt(1000000, \@contig) || 0;
	my $n2m = mt(2000000, \@contig) || 0;
	my $n5m = mt(5000000, \@contig) || 0;
	print OUT "N90(bp)/number\t$N90 / $N90_n\n";
	print OUT "N80(bp)/number\t$N80 / $N80_n\n";
	print OUT "N70(bp)/number\t$N70 / $N70_n\n";
	print OUT "N60(bp)/number\t$N60 / $N60_n\n";
	print OUT "N50(bp)/number\t$N50 / $N50_n\n";
	print OUT "N40(bp)/number\t$N40 / $N40_n\n";
	print OUT "N30(bp)/number\t$N30 / $N30_n\n";
	print OUT "N20(bp)/number\t$N20 / $N20_n\n";
	print OUT "N10(bp)/number\t$N10 / $N10_n\n";
	print OUT "Max length(bp)\t$max_len\n";
	print OUT "Min length(bp)\t$min_len\n";
	print OUT "Total length(bp)\t$total_len\n";
	print OUT "Total number\t$total_n\n";
	print OUT "Average length(bp)\t$ave_len\n";
	print OUT "Number>1Mbp\t$n1m\n";
	print OUT "Number>2Mbp\t$n2m\n";
	print OUT "Number>5Mbp\t$n5m\n";

	close IN;
	close OUT;
}
if ($fa){
	if ($fa =~ /\.gz/){
		open IN, "gzip -dc $fa |" or die $!;
	}else{
		open IN, "$fa" or die $!;
	}
	my $result_file = "$prefix\_assemble_fa.stat";
	$result_file = "$prefix\_mt$min(kb)_assemble_fa.stat" if ($min > 0);
	open OUT, ">$outdir/$result_file" or die $!;
	$/ = "\n>";
	my (@scarf,@contig);
	my ($s_total_len, $gap_len, $c_total_len)= (0,0,0); 
	my ($s_gc_len,$c_gc_len) = (0,0);
	while(<IN>){
		my @tmp = split /\n/;
		my $id = shift @tmp;
		my $seq;
		for my $i (@tmp){
			$i =~ s/\s+//g;
			$i =~ s/>//g;
			$seq .= $i;
		}
		if (length($seq) > ($min * 1000)){
			my $len_s = length($seq);
			push @scarf, $len_s;
			$s_total_len += $len_s;
			$s_gc_len += $seq =~ s/[gc]/g/ig;
			$gap_len += $seq =~ s/n/n/ig;

			my @cont = split(/[Nn]+/, $seq);
			foreach my $con(@cont){
				my $len_c = length($con);
				push @contig, $len_c if ($len_c > 0);
				$c_total_len += $len_c;
				$c_gc_len += $con =~ s/[gc]/g/ig;
			}	
		}
	}	
	close IN;
	$/ = "\n";
	@scarf = sort {$b<=>$a} @scarf;
	my $s_total_n = scalar(@scarf);
	my $s_ave_len = $s_total_len/$s_total_n;
	my $s_max_len = $scarf[0];
	my $s_min_len = $scarf[-1];
	my $s_gc = $s_gc_len / ($s_total_len - $gap_len) * 100;
	my ($s_N90, $s_N90_n) = nx(90, \@scarf, $s_total_len);
	my ($s_N80, $s_N80_n) = nx(80, \@scarf, $s_total_len);
	my ($s_N70, $s_N70_n) = nx(70, \@scarf, $s_total_len);
	my ($s_N60, $s_N60_n) = nx(60, \@scarf, $s_total_len);
	my ($s_N50, $s_N50_n) = nx(50, \@scarf, $s_total_len);
	my ($s_N40, $s_N40_n) = nx(40, \@scarf, $s_total_len);
	my ($s_N30, $s_N30_n) = nx(30, \@scarf, $s_total_len);
	my ($s_N20, $s_N20_n) = nx(20, \@scarf, $s_total_len);
	my ($s_N10, $s_N10_n) = nx(10, \@scarf, $s_total_len);
	my $s_n1000 = mt(1000, \@scarf) || 0;
	my $s_n2000 = mt(2000, \@scarf) || 0;
	my $s_n10k = mt(10000, \@scarf) || 0;
	my $s_n100k = mt(100000, \@scarf) || 0;
	my $s_n1m = mt(1000000, \@scarf) || 0;
	my $s_n10m = mt(10000000, \@scarf) || 0;

	@contig = sort {$b<=>$a} @contig;
	my $c_total_n = scalar(@contig);
	my $c_ave_len = $c_total_len/$c_total_n;
	my $c_max_len = $contig[0];
	my $c_min_len = $contig[-1];
	my $c_gc = $c_gc_len / $c_total_len * 100;
	my ($c_N90, $c_N90_n) = nx(90, \@contig, $c_total_len);
	my ($c_N80, $c_N80_n) = nx(80, \@contig, $c_total_len);
	my ($c_N70, $c_N70_n) = nx(70, \@contig, $c_total_len);
	my ($c_N60, $c_N60_n) = nx(60, \@contig, $c_total_len);
	my ($c_N50, $c_N50_n) = nx(50, \@contig, $c_total_len);
	my ($c_N40, $c_N40_n) = nx(40, \@contig, $c_total_len);
	my ($c_N30, $c_N30_n) = nx(30, \@contig, $c_total_len);
	my ($c_N20, $c_N20_n) = nx(20, \@contig, $c_total_len);
	my ($c_N10, $c_N10_n) = nx(10, \@contig, $c_total_len);
	my $c_n1000 = mt(1000, \@contig) || 0;
	my $c_n2000 = mt(2000, \@contig) || 0;
	my $c_n10k = mt(10000, \@contig) || 0;
	my $c_n100k = mt(100000, \@contig) || 0;
	my $c_n1m = mt(1000000, \@contig) || 0;
	my $c_n10m = mt(10000000, \@contig) || 0;

	print OUT "\tScarfford\tContig\n";
	print OUT "N90(bp)/number\t$s_N90 / $s_N90_n\t$c_N90 / $c_N90_n\n";
	print OUT "N80(bp)/number\t$s_N80 / $s_N80_n\t$c_N80 / $c_N80_n\n";
	print OUT "N70(bp)/number\t$s_N70 / $s_N70_n\t$c_N70 / $c_N70_n\n";
	print OUT "N60(bp)/number\t$s_N60 / $s_N60_n\t$c_N60 / $c_N60_n\n";
	print OUT "N50(bp)/number\t$s_N50 / $s_N50_n\t$c_N50 / $c_N50_n\n";
	print OUT "N40(bp)/number\t$s_N40 / $s_N40_n\t$c_N40 / $c_N40_n\n";
	print OUT "N30(bp)/number\t$s_N30 / $s_N30_n\t$c_N30 / $c_N30_n\n";
	print OUT "N20(bp)/number\t$s_N20 / $s_N20_n\t$c_N20 / $c_N20_n\n";
	print OUT "N10(bp)/number\t$s_N10 / $s_N10_n\t$c_N10 / $c_N10_n\n";
	print OUT "Max length(bp)\t$s_max_len\t$c_max_len\n";
	print OUT "Min length(bp)\t$s_min_len\t$c_min_len\n";
	print OUT "Total length(bp)\t$s_total_len\t$c_total_len\n";
	print OUT "Gap length(bp)\t$gap_len\t0\n";
	print OUT "Total number\t$s_total_n\t$c_total_n\n";
	print OUT "Average length(bp)\t$s_ave_len\t$c_ave_len\n";
	print OUT "GC percent(%)\t$s_gc\t$c_gc\n";
	print OUT "Number>1000bp\t$s_n1000\t$c_n1000\n";
	print OUT "Number>2000bp\t$s_n2000\t$c_n2000\n";
	print OUT "Number>10kbp\t$s_n10k\t$c_n10k\n";
	print OUT "Number>100kbp\t$s_n100k\t$c_n100k\n";
	print OUT "Number>1mbp\t$s_n1m\t$c_n1m\n";
	print OUT "Number>10mbp\t$s_n10m\t$c_n10m\n";

	close OUT;
}

sub nx{
	my ($n, $contig, $total) = @_;
	my $len = 0;
	for (my $i=0;$i<scalar(@$contig);$i++){
		$len += $contig->[$i];
		if ($len*100 >= $total*$n){
			return $contig->[$i], $i+1;
			last;
		}
	}
}

sub mt{
	my ($len, $contig) = @_;
	if ($contig->[-1] > $len){
		return scalar(@$contig);
		last;
	}else{
		for (my $i=0;$i<@$contig;$i++){
			if ($len > $contig->[$i]){
				return $i;
				last;
			}
		}
	}
}
