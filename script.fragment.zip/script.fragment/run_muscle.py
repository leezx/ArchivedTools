#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
Run muscle
Usage: python <script> <in.file.list>
"""
import sys

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

infile = sys.argv[1]
file_list = open(infile, "r")
runf = open("run.sh", "a")
head = "#!/bin/bash\necho ==========start at : `date` =========="
tail = "echo ==========end  at : `date` =========="
print(head, file=runf)

for line in file_list:
	left_file, right_file = line.split()
	left_out_file = left_file.split('.')[0] + "_c.fasta"
	right_out_file = right_file.split('.')[0] + "_c.fasta"
	left_cmd = "muscle -in %s -out %s" % (left_file, left_out_file)
	right_cmd = "muscle -in %s -out %s" % (right_file, right_out_file)
	print(left_cmd, right_cmd, file=runf, sep='\n', end='\n')



#qsub_cmd = "qsub -cwd -l vf=5g -P HUMDnab -q bc.q,bc_rd.q run.sh"
#qsub_cmd_list = qsub_cmd.split()
#call(qsub_cmd_list)

print(tail, file=runf)
file_list.close()
runf.close()