import pysam
from collections import OrderedDict

out_fasta = open("out.fasta",'w')
out_taxo = open("out_taxo.txt",'w')

total_dict = OrderedDict()
total_dict['Root'] = 0
taxid_count = 0
tax_dict = ['rootrank','domain','phylum','class','order','family','genus','specie']
print("0*Root*-1*0*rootrank",file=out_taxo)

with open("gg_13_8_99.gg.tax",'r') as inf:
	with pysam.FastaFile('gg_13_8_99.fasta') as fasta:
		for line in inf:
			line_list = line.strip().split()
			taxid = line_list[0]
			# line_list[0] = line_list[0].split()[1]
			tax_list = line_list[1].strip(';').split(';')
			# tax_list = line_list
			final_tax = ['Root']
			parent = ''
			for i,tax in enumerate(tax_list):
				if i >=1 :
					parent = tax_list[i-1]
					parent = '_'.join(parent.split())
				else:
					parent = 'Root'
				# tax = tax.strip(';')
				if tax.endswith("__"):
					continue
				# new_tax = tax.split('__')[1]
				new_tax = '_'.join(tax.split())
				final_tax.append(new_tax)
				if new_tax in total_dict:
					continue
				else:
					taxid_count += 1
					total_dict[new_tax] = taxid_count
					parent_taxid = total_dict[parent]
					depth = i+1
					rank = tax_dict[depth]
					# final_list = [taxid_count,new_tax,parent_taxid,depth,rank]
					print('%s*%s*%s*%s*%s'%(taxid_count,new_tax,parent_taxid,depth,rank),file=out_taxo)

			# print(taxid, ';'.join(final_tax))
			seq = fasta.fetch(taxid)
			name = ">" + taxid + "    " + ';'.join(final_tax)
			print(name, seq, sep='\n', file=out_fasta)

	
out_fasta.close()
out_taxo.close()

			
