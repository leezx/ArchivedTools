import pysam
PB_fasta_file = "mergefastq.fasta.gz"
outf = open("out.fastq", "w")
PB_fasta = pysam.FastaFile(PB_fasta_file)
for ref in PB_fasta.references:
    merged_fasta = PB_fasta.fetch(ref)
    len_merged_fasta = len(merged_fasta)
    #PB_reads = merged_fasta[:(len_merged_fasta//2)]
    #PB_qual = merged_fasta[(len_merged_fasta//2):]
    PB_reads = merged_fasta
    PB_qual = len_merged_fasta*"]"
    print("@"+ref, PB_reads, "+", PB_qual, file=outf, sep='\n', end='\n')


