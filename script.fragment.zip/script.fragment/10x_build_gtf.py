import sys

inf = open("Megalobrama_amblycephala-filtered.Chrplus.gtf", "r")
outf = open("out.gtf", "w")

for line in inf:
	line = line.strip().split()
	seqid =  line[0]
	source = "LZX"
	feature = line[2]
	start =  line[3]
	end = line[4]
	score = "."
	strand = line[6]
	frame = "."
	gene_id = line[9]
	if int(start) >= int(end):
		print("start >= end")
		print(line)
		#sys.exit(1)
		continue
	
	if feature == "gene":
		gene_attribute = 'gene_id "%s"; gene_version "1"; gene_name "%s"; gene_source "LZX"; gene_biotype "protein_coding";' % (gene_id, gene_id)
		print(seqid,source,"gene",start,end,score,strand,frame,gene_attribute,file=outf,sep='\t')
	elif feature == "transcript":
		transcript_id = line[13].strip(';').strip('"')
		transcript_attribute = 'gene_id "%s"; gene_version "1"; transcript_id "%s"; transcript_version "1"; gene_name "%s"; gene_source "LZX"; gene_biotype "protein_coding"; transcript_name "%s"; transcript_source "LZX"; transcript_biotype "protein_coding";' % (gene_id, transcript_id, gene_id, transcript_id)
		print(seqid,source,"transcript",start,end,score,strand,frame,transcript_attribute,file=outf,sep='\t')
	elif feature == "exon":
		exon_id = line[31].strip(';').strip('"')
		exon_number = line[17].strip(';').strip('"')
		exon_attribute = 'gene_id "%s"; gene_version "1"; transcript_id "%s"; transcript_version "1"; exon_number "%s"; gene_name "%s"; gene_source "LZX"; gene_biotype "protein_coding"; transcript_name "%s"; transcript_source "LZX"; transcript_biotype "protein_coding"; exon_id "%s"; exon_version "1";'% (gene_id, transcript_id, exon_number, gene_id, transcript_id, exon_id)
		print(seqid,source,"exon",start,end,score,strand,frame,exon_attribute,file=outf,sep='\t')
	else:
		print("ERROR")
		sys.exit(1)
		
inf.close()
outf.close()