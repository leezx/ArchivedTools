#!/bin/bash

# note: quality value format not set explicitly; using PHRED+64
# The qv-offset might be set incorrectly! Currenty qvs are interpreted as PHRED+64 and a qv of -20 was observed. To disable this error, etiher set the offset correctly or disable this check (see README).
gmapper-ls hiseq.fasta PB_chr22_20X_random.fasta -E -N 20 -o 30 -m 5 -i -11 -g -2 -q -1 -e -4 -f -3  > map.out 
