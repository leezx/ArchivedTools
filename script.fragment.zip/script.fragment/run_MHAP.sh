#!/bin/bash

java -Xmx32g -server -jar /ifs4/BC_RD/USER/lizhixin/app/MHAP/target/mhap-2.1.2.jar -p PB_chr22_20X_random.fasta -q ./

java -Xmx32g -server -jar /ifs4/BC_RD/USER/lizhixin/app/MHAP/target/mhap-2.1.2.jar -s PB_chr22_20X_random.dat -q hiseq.fasta 
