import pysam
import re

def split_fastq_by_I(seq_name, seq, qual, outf):
	pos = 0
	flag = 0
	head_pos = 0
	tail_pos = 0
	for one_qual in qual:
		if one_qual == 'I':
			seq = seq[:pos] + "I" + seq[(pos+1):]
		pos += 1
	seq_list = re.split('I+', seq)
	qual_list = re.split('I+', qual)
	if not seq_list[0]:
		del seq_list[0]
	if not seq_list[-1]:
		del seq_list[-1]
	if not qual_list[0]:
		del qual_list[0]
	if not qual_list[-1]:
		del qual_list[-1]
	count = 0
	for one_seq in seq_list:
		temp_seq_name = '@' + seq_name + '_' + str(count)
		print(temp_seq_name, one_seq, '+', qual_list[count], file=outf, sep='\n', end='\n')
		count += 1

in_file = './merger_new.fastq'
out_file = './extract_un_correct_region.fastq'
fastq = pysam.FastxFile(in_file)
outf = open(out_file, 'w')

for line in fastq:
	seq_name = line.name
	seq = line.sequence
	qual = line.quality
	split_fastq_by_I(seq_name, seq, qual, outf)
	# break

fastq.close()
outf.close()