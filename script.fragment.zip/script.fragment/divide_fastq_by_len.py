import pysam

in_file = './extract_un_correct_region.fastq'
out_file_1 = './extract_un_correct_region_23_1000.fastq'
out_file_2 = './extract_un_correct_region_above_1000.fastq'
fastq = pysam.FastxFile(in_file)
outf_1 = open(out_file_1, 'w')
outf_2 = open(out_file_2, 'w')

for line in fastq:
	seq_name = line.name
	seq = line.sequence
	qual = line.quality
	if len(seq) < 23:
		continue
	elif 23 <= len(seq) <= 1000:
		print('@'+seq_name, seq, '+', qual, file=outf_1, sep='\n', end='\n')
	elif len(seq) > 1000:
		print('@'+seq_name, seq, '+', qual, file=outf_2, sep='\n', end='\n')

fastq.close()
outf_1.close()
outf_2.close()