import pysam
import os
from subprocess import call

in_file = "/ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/ref/kmer.fasta"
out_file = "./group_result_sort.txt"
temp_file = "./temp_file.fasta"
ref = in_file

inf = pysam.FastaFile(in_file)
outf = open(out_file, 'w')

def call_cmd(cmd):
	cmd_list = cmd.split()
    call(cmd_list)

map_dict = {}

for one in inf.references:
	kmer = inf.fetch(one)
	tempf = open(temp_file, 'w')
	print('>'+one, kmer, file=tempf, sep='\n', end='\n')
	tempf.close()
	bwa_cmd = "bwa mem -t 4 /ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/ref/kmer.fasta temp_file.fasta | samtools view -F 4 -b -  > temp_file.bam"
	call_cmd(bwa_cmd)

	samtools_index_cmd = "samtools index temp_file.bam"
	call_cmd(samtools_index_cmd)

	temp_bam = pysam.AlignmentFile("temp_file.bam")
	
	# print('>'+one, kmer, file=outf, sep='\n', end='\n')
	for line in temp_bam:
		group_list = []
		if line.get_tag('NM') <= 4:
			group_list.append(line.reference_name)
			#for map_line in group_list:
				#print(len(group_list), map_line, file=outf, sep='\t', end='\t')
		#print(' ', file=outf)
		map_dict[one] = [len(group_list), group_list]

	temp_bam.close()
	break

map_kmer_list = sorted(map_dict.items(), key=lambda item:item[1][0], reverse=True)
for line in map_kmer_list:
	#line[0] # kmer name
	#line[1][0] # map count
	#line[1][1] # map kmer name
	print('>'+line[0], inf.fetch(line[0]), file=outf, sep='\n', end='\n')
	print(line[1][0], line[1][1], file=outf, sep='\t', end='\n')


inf.close()
outf.close()
