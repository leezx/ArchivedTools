#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
The basic Statistics information of bam file:
	bam_total_line, total_reads_count, alignment_len_distribution, 
	total_base, total_mismatch, total_insertion, total_deletion,
Usage: python <script> <in.bam>
"""

import pysam
import sys
import os
import re

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

infile = sys.argv[1]
outdir = "stat"
if not os.path.exists(outdir):
	os.mkdir(outdir)
alignment_len_distribution_file = "./" + outdir + "/alignment_len_distribution.txt"
stat_file = "./" + outdir + "/stat.txt"

bam_file = pysam.AlignmentFile(infile, "rb")
len_distribution = open(alignment_len_distribution_file, "w")
statf = open(stat_file, "w")

bam_total_line = 0
total_reads = set()
total_base = 0
total_mismatch = 0
total_insertion = 0
total_deletion = 0
total_mismatch_MD = 0
total_I = 0
total_cigar_S = 0

for line in bam_file:
	#if not line.query_name == 'm54040_161112_053836/12255676/ccs':
	#	continue
	if not line.has_tag('NM'):
		continue
	if line.mapping_quality <= 30:
		continue
	#if not line.has_tag('MD'):
	#	continue
	bam_total_line += 1
	#total_I += line.cigarstring.count('I')
	total_reads.add(line.query_name)
	print(line.query_alignment_length, file=len_distribution)
	total_base += line.query_alignment_length
	indel_count = 0
	for pair in line.cigar:
		if pair[0] == 3 or pair[0] == 4 or pair[0] == 5 or pair[0] == 6:
			continue
		elif pair[0] == 1:
			total_insertion += pair[1]
			indel_count += pair[1]
		elif pair[0] == 2:
			total_deletion += pair[1]
			indel_count += pair[1]
	total_mismatch += (line.get_tag('NM') - indel_count) # if not line.has_tag('NM'):
	if (line.get_tag('NM') - indel_count) < 0:
		#raise TypeError("(line.get_tag('NM') - indel_count) < 0 !!!")
		print("WARN: (line.get_tag('NM') - indel_count) < 0 !!!")
		print("the query_name is: ",line.query_name)
	#MD = line.get_tag('MD')
	#pat = "[0-9]+[ATGC]+"
	#MD_list = re.findall(pat,MD)
	#for i in MD_list:
	#	for j in i:
	#		if j == 'A' or j == 'T' or j == 'G' or j == 'C':
	#			total_mismatch_MD += 1

	seq = line.qual
	if line.cigar[0][0] == 4:
		seq = seq[line.cigar[0][1]:]
	if line.cigar[-1][0] == 4:
		seq = seq[:(len(seq)-line.cigar[-1][1])]
	total_I += seq.count('I')

	# print(line.qual, seq, total_I, sep='\n')
	# break
	#if bam_total_line == 2:
	#	break

total_reads_count = len(total_reads)

total_not_I = total_base - total_I
extra_mismatch = int(total_not_I * 2.62 /100)
extra_insertion = int(total_not_I * 9.09 /100)
extra_deletion = int(total_not_I * 4.74 /100)

print("bam_total_line: %s\ntotal_reads_count: %s\ntotal_base: %s\ntotal_mismatch_by_NM: %s %.2f\ntotal_insertion: %s %.2f\ntotal_deletion: %s %.2f\n" % \
	(bam_total_line, total_reads_count, total_base,total_mismatch, total_mismatch/total_base*100, total_insertion,total_insertion/total_base*100, total_deletion,total_deletion/total_base*100), \
	file=statf)
#print("extra_info\ntotal_mismatch_by_MD: ", total_mismatch_MD, file=statf)

print("\nfinal total base: %s\nfinal mismatch: %s %.2f\nfinal insertion: %s %.2f\nfinal deletion: %s %.2f\n" % \
	(total_I ,(total_mismatch - extra_mismatch),(total_mismatch - extra_mismatch)/total_I*100,  (total_insertion - extra_insertion),(total_insertion - extra_insertion)/total_I*100, (total_deletion - extra_deletion),(total_deletion - extra_deletion)/total_I*100),\
	file=statf) 

bam_file.close()
len_distribution.close()
statf.close()

# M	BAM_CMATCH	0
# I	BAM_CINS	1
# D	BAM_CDEL	2
# N	BAM_CREF_SKIP	3
# S	BAM_CSOFT_CLIP	4
# H	BAM_CHARD_CLIP	5
# P	BAM_CPAD	6
# =	BAM_CEQUAL	7
# X	BAM_CDIFF	8
