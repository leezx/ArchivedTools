#!/usr/bin/env python
# Author: LI ZHIXIN
"""
split fastq.gz to several part
usage: python <script> <infile> <N_part>
"""
import gzip
import sys

if len(sys.argv) -1 != 2:
    sys.exit(__doc__)

in_file, outfile_part = sys.argv[1:]
outfile_part = int(outfile_part)
#in_file = "/share/fqdata108A/Zebra/F15NGS03003_HUMoah/WHHUMoahAAAASAAZebra-47/170205_I44_CL100013600_L1_WHHUMoahAAAASAAZebra-47/CL100013600_L01_read_1.fq.gz"
inf = gzip.open(in_file)

#outfile_part = 6
outfile_list = []
outf = []
prefix = in_file.split('/')[-1].split('.')[0]
for i in range(outfile_part):
    i += 1
    file_name = str(i) + '_' + prefix + '.fastq'
    outfile_list.append(file_name)
    outf.append(1)

for i in range(outfile_part):
    #outf[i] = gzip.open(outfile_list[i], "wb")
    outf[i] = open(outfile_list[i], "w")

count = 0
for line in inf:
#for line in inf.readline:
    read_count = count // 4 + 1
    out_file_index = read_count % outfile_part - 1
    line = line.decode()
    #line = line.strip()
    #print(line, file=outf[out_file_index], end='')
    outf[out_file_index].write(line)
    count += 1

inf.close()
for i in range(outfile_part):
    outf[i].close()
