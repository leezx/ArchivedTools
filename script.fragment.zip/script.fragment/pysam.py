import pysam
import datetime

print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

file = "/share/fqdata108A/Zebra/F15NGS03003_HUMoah/WHHUMoahAAAASAAZebra-47/170205_I44_CL100013600_L1_WHHUMoahAAAASAAZebra-47/CL100013600_L01_read_1.fq.gz"
fastq = open(file)

count = 0
for line in fastq:
	count += 1

print(count)

print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
