#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
remove redundance kmer
Usage: python <script> <query_kmer> <out.result>
"""
import pysam
import ctypes 
import numpy as np
import os
import sys

if len(sys.argv) - 1 != 2:
    sys.exit(__doc__)

in_file, out_file = sys.argv[1:]

#lib = ctypes.cdll.LoadLibrary("/ifs4/BC_RD/USER/lizhixin/script/libLLCS.so")
lib = ctypes.cdll.LoadLibrary(
        os.path.join(os.path.dirname(os.path.realpath(__file__)),
            'diff-cpp-master','libLLCS.so'))

#in_file = "/ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/kmer.txt"
ref_file = "/ifs4/BC_RD/USER/lizhixin/my_project/chr22_asm_ref_nX/20X_DBG2OLC_chr22/bays_correct/kmer/LLCS_kmer_out.sort.txt"
#out_file = "./group_result_sort.txt"

inf = open(in_file, 'r')
outf = open(out_file, 'w')

def calc_LLCS(a, b):
    a = np.asarray(a, dtype=np.int_)
    b = np.asarray(b, dtype=np.int_)
    ptr = ctypes.POINTER(ctypes.c_long)
    a_ptr = a.ctypes.data_as(ptr)
    b_ptr = b.ctypes.data_as(ptr)
    return lib.calc_llcs(a_ptr, a.size,b_ptr, b.size)

kmer_dict = {}
reff = open(ref_file, 'r')
for ref in reff:
    ref_kmer, ref_kmer_count, temp = ref.strip().split()
    kmer_dict[ref_kmer] = 0
reff.close()


for query in inf:
    query_kmer, query_kmer_count, temp = query.strip().split()
    if kmer_dict[query_kmer] == 1:
        continue

    print(query.strip(), file=outf, sep='\t', end='\n')

    for one_kmer in kmer_dict:
        if kmer_dict[one_kmer] == 0:
            NM = 23 - calc_LLCS(list(map(ord, one_kmer)), list(map(ord, query_kmer)))
            if NM <= 3:
                kmer_dict[one_kmer] = 1

inf.close()
outf.close()
