#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
Mutiple aligment of head and tail of scffold
Usage: python <script> <in.file.list>
"""

import pysam
import sys
from collections import Counter
import re
import os

def mutiple_consensus(seq_list):
	consensus_seq = ""
	base_count = 0
	seq_len = len(seq_list[0])
	while base_count < seq_len:
		base_list = ""
		for seq in seq_list:
			base_list += seq[base_count]
		base_count += 1
		#print(base_list)
		top = Counter(base_list).most_common(2)
		#print(top)
		if len(top) == 2:
			#top_list = [top[0][0], top[1][0]]
			if top[0][0] == '-':
				best_base = top[1][0]
			else:
				best_base = top[0][0]
		else:
			best_base = top[0][0]
		consensus_seq += best_base
	return consensus_seq

def trans_file_to_seqList(filename):
	seq_list = []
	fastaf = pysam.FastaFile(filename)
	for seq_name in fastaf.references:
		seq = fastaf.fetch(seq_name)
		seq_list.append(seq)
	fastaf.close()
	return seq_list

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

outdir = "consensus_head_tail"
if not os.path.exists(outdir):
	os.mkdir(outdir)

infile = sys.argv[1]
inf = open(infile, "r")
left_out_file = "./left.fasta"
right_out_file = "./right.fasta"
leftf = open(left_out_file, "w")
rightf = open(right_out_file, "w")
pat = re.compile("^>")

for line in inf:
	left_file, right_file = line.split()
	# headf = open(left_file, 'r')
	# head_list = []
	# tail_list = []
	# for head in headf:
	# 	if pat.match(head):
	# 		continue
	# 	head_list.append(head.strip())
	# headf.close()
	# tailf = open(right_file, 'r')
	# for tail in tailf:
	# 	if pat.match(tail):
	# 		continue
	# 	tail_list.append(tail.strip())
	# tailf.close()
	head_list = trans_file_to_seqList(left_file)
	tail_list = trans_file_to_seqList(right_file)
	#print(head_list)
	#print(tail_list)
	consensus_head = mutiple_consensus(head_list)
	consensus_tail = mutiple_consensus(tail_list)
	head_name = left_file[:-10]
	tail_name = right_file[:-10]
	print(">"+head_name, consensus_head, file=leftf, sep='\n', end='\n')
	print(">"+tail_name, consensus_tail, file=rightf, sep='\n', end='\n')

inf.close()
leftf.close()
rightf.close()

