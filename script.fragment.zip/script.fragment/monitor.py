#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Date    : 2017-01-13 16:19:30
# @Author  : LiZhiXin (lizhixin@genomics.cn)
# @Link    : http://www.genomics.cn
# @Version : $1.0$
"""
A simple Monitor, Which can qsub the scipts according to allDependent.txt.
Usage: python <script> <allDependent.txt>
       copy <script> and <allDependent.txt> to your own path
       change the sge below to yours
       run the <script> backgroud by nohup <script> &
"""
import sys
import os
from collections import OrderedDict
from subprocess import call
import time

if len(sys.argv) - 1 != 1:
    sys.exit(__doc__)

sge = "-P F16ZQSB3SY2425 -q st.q"

infile = sys.argv[1]
outdir = "monitor"
# if not os.path.exists(outdir):
#     os.mkdir(outdir)
#stat_file = "./" + outdir + "/stat.txt"
script_file = "./" + "monitor.stat"

def update_jobs(infile):
    inf = open(infile, "r")
    #statf = open(stat_file, "w")
    scriptf = open(script_file, "w")
    all_jobs = OrderedDict()
    done_jobs = []
    undone_jobs = OrderedDict()
    logic_jobs = {}
    for line in inf:
        line = line.strip()
        try:
            raw_former, raw_later = line.split()
        except:
            print(line)
        else:
            pass
        logic_jobs[raw_later.split(":")[0]] = raw_former.split(":")[0]
        if not raw_former in all_jobs.keys():
            all_jobs[raw_former] = 0
        if not raw_later in all_jobs.keys():
            all_jobs[raw_later] = 0
    for raw_job in all_jobs.keys():
        # sign
        job, mem = raw_job.split(":")
        if os.path.exists(job+".sign"):
            done_jobs.append(job)
        else:
            undone_jobs[job] = mem
    print("######## Overview  ########\n", file=scriptf)
    print("all_jobs: %s"%len(set(all_jobs)), "done_jobs: %s"%len(done_jobs), "undone_jobs: %s"%len(undone_jobs), file=scriptf, sep='\n', end='\n')
    print("\n######## done_jobs ########\n", file=scriptf)
    for one in done_jobs:
        print(one, file=scriptf)
    print("\n######## undone_jobs ########\n", file=scriptf)
    for one in undone_jobs.keys():
        print(one, file=scriptf)
    #statf.close()
    scriptf.close()
    inf.close()
    return all_jobs, done_jobs, undone_jobs, logic_jobs

def update_running_jobs(running_jobs):
    for job in running_jobs:
        if os.path.exists(job+".sign"):
            running_jobs.remove(job)
    return running_jobs

def qsub_undone_jobs(undone_jobs, logic_jobs, running_jobs):
    #running_jobs = []
    for job, mem in undone_jobs.items():
        if (not job in logic_jobs.keys()) or os.path.exists(logic_jobs[job]+".sign"):
            job_dir_name = os.path.dirname(job)
            qsb = "qsub -wd %s -l vf=%sg %s %s" % (job_dir_name, mem[:-1], sge, job)
            if not job in running_jobs:
                # print(qsb)
                running_jobs.append(job)
                qsub_cmd_list = qsb.split()
                call(qsub_cmd_list)
    #running_jobs = update_running_jobs(running_jobs)
    return running_jobs

def sleeptime(my_hour,my_min,my_sec):
    return my_hour*3600 + my_min*60 + my_sec

second = sleeptime(0,5,0)
running_jobs = []
while True:
    # print("1")
    all_jobs, done_jobs, undone_jobs, logic_jobs = update_jobs(infile)
    running_jobs = qsub_undone_jobs(undone_jobs, logic_jobs, running_jobs)
    if not undone_jobs:
        break
    time.sleep(second)


# 1. check the alldependent.txt format

