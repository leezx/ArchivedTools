#!/usr/bin/env python
# Author: LI ZHIXIN

import sys
import pysam
from collections import OrderedDict

def classify_DP(depth):
    if depth > 101:
        return 21
    return ((depth-1)//5+1)

def parse_rec(rec):
    sample = list(rec.samples)[0]
    # filter the Invalid line
    if not ('GQ' or 'GT' or 'DP') in rec.samples[sample].keys() or len(rec.alleles) <= 1:
        # continue
        return 1, "LowQual", rec.pos
    # filter the LowQual
    if rec.samples[sample]['GQ'] < 30:
        return rec.samples[sample]['DP'], "LowQual", rec.pos
    # filter the indel
    flag = 0
    for one in rec.alleles:
        if len(one) != len(rec.ref):
            flag = 1
    if flag == 1:
        return rec.samples[sample]['DP'], "LowQual", rec.pos
    if rec.samples[sample]['GT'] != (0, 0): # rec.qual > 30
        # variation_dict[rec.pos] = ["snp", rec.alleles]
        return rec.samples[sample]['DP'], "snp", rec.pos  
    elif rec.samples[sample]['GT'] == (0, 0):
        # variation_dict[rec.pos] = ["ref", rec.alleles]
        return rec.samples[sample]['DP'], "ref", rec.pos

def read_gvcf(gvcf_file_path):
    variation_dict = OrderedDict()
    for i in range(1,22):
        variation_dict[i] = {}
        for j in ('LowQual', 'snp', 'ref'):
            variation_dict[i][j] = []
    # pos_list = []
    gvcf_file = pysam.VariantFile(gvcf_file_path)
    for rec in gvcf_file.fetch('chr6',28477796,33448354):
        DP, pos_type, pos = parse_rec(rec)
        if DP < 1 or DP > 20:
            continue
        # DP = classify_DP(DP)
        variation_dict[DP][pos_type].append(pos)
        # print(pos, DP, pos_type)
    gvcf_file.close()
    # return variation_dict, pos_list
    return variation_dict

def read_hiseq_gvcf(gvcf_file_path):
    variation_dict = OrderedDict()
    # for i in range(1,22):
    # variation_dict[i] = {}
    for j in ('LowQual', 'snp', 'ref'):
        variation_dict[j] = []
    # pos_list = []
    gvcf_file = pysam.VariantFile(gvcf_file_path)
    for rec in gvcf_file.fetch('chr6',28477796,33448354):
        DP, pos_type, pos = parse_rec(rec)
        DP = classify_DP(DP)
        variation_dict[pos_type].append(pos)
        # print(pos, DP, pos_type)
    gvcf_file.close()
    # return variation_dict, pos_list
    return variation_dict

def show_dict_diff_DP(Hiseq_unified_variation_dict, PB_non_CCS_variation_dict, outf, outf2):
    for DP in range(1,21):
        Hiseq_snp = set(Hiseq_unified_variation_dict['snp'])
        Hiseq_ref = set(Hiseq_unified_variation_dict['ref'])
        Hiseq_lowqual = set(Hiseq_unified_variation_dict['LowQual'])
        PB_snp = PB_non_CCS_variation_dict[DP]['snp']
        PB_ref = PB_non_CCS_variation_dict[DP]['ref']
        PB_lowqual = PB_non_CCS_variation_dict[DP]['LowQual']
        total = set(PB_snp + PB_ref + PB_lowqual)
        Hiseq_snp = total & Hiseq_snp
        Hiseq_ref = total & Hiseq_ref
        Hiseq_lowqual = total & Hiseq_lowqual
        PB_snp = set(PB_snp)
        PB_ref = set(PB_ref)
        PB_lowqual = set(PB_lowqual)
        a = len(Hiseq_snp & PB_snp)
        b = len(Hiseq_ref & PB_snp)
        c = len(Hiseq_lowqual & PB_snp)
        d = len(Hiseq_snp & PB_ref)
        e = len(Hiseq_ref & PB_ref)
        f = len(Hiseq_lowqual & PB_ref)
        g = len(Hiseq_snp & PB_lowqual)
        h = len(Hiseq_ref & PB_lowqual)
        i = len(Hiseq_lowqual & PB_lowqual)
        Low_total = (g+h+i)/(a+b+c+d+e+f+g+h+i)
        if (a+b) == 0:
            PPV = "NA"
        else:
            PPV = a/(a+b)
            PPV = "%.4f"%(PPV)
        if (a+d) == 0:
            TPR = "NA"
        else:
            TPR = a/(a+d)
            TPR = "%.4f"%(TPR)
        print(str(DP)+" :\n", a,b,c,"\n",d,e,f,"\n",g,h,i,"\n", file=outf2, sep='\t', end='\n')
        print(DP, TPR, PPV, "%.4f"%Low_total, file=outf, sep='\t', end='\n')

with open("./depth_stat.txt", "w") as outf:
    print("Depth", "TPR", "PPV", "Low_total", file=outf, sep='\t', end='\n')
    outf2 = open("raw.txt", "w")
    Hiseq_unified_variation_dict = read_hiseq_gvcf("./hiseq_call_gvcf/MHC_Hiseq.unified.gvcf.gz")
    PB_non_CCS_variation_dict = read_gvcf("./non_CCS_PB_call_gvcf/MHC_non_CCS.unified.gvcf.gz")
    show_dict_diff_DP(Hiseq_unified_variation_dict, PB_non_CCS_variation_dict, outf, outf2)
    outf2

