import re
import fileinput

hg19 = "./hg19.fasta"
dic_chr = {}
temp_chr = ''

for line in fileinput.input(hg19):
    line = line.strip()
    pat = re.compile(r'^>')
    match = pat.match(line)
    if match:
        temp_chr = line
        dic_chr[temp_chr] = 0
    else:
        dic_chr[temp_chr] += len(line)

for item in dic_chr.items():
    print(item)