def extract_I_qual(qual):
	pointer = 0
	I_list = []
	I_len = 0
	for one in qual:
		pointer += 1
		if one == 'I':
			I_len += 1
		if one != 'I':
			if pointer != 1 and I_len != 0:
				I_list.append(I_len)
			I_len = 0
	if one == 'I':
		I_list.append(I_len)
	return I_list