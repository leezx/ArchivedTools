import pysam
infile = "../DBG2OLC_chr22.bam"
bam_file = pysam.AlignmentFile(infile, "rb")
PB_fasta = "../PB_chr22_20X_random.fasta"
PB_reads = pysam.FastaFile(PB_fasta)

ref_dict = dict(zip(bam_file.references, bam_file.lengths))

def cacul_num_of_iter(seq_iter):
    count = 0
    for seq in seq_iter:
        if len(seq.seq) < 100:
            continue
        count += 1
    return count

def seq_pos_reverse_compliment(seq):
    """
    qend is fushu!!!
    """
    newseq = ''
    for base in seq:
        if base == 'A':
            newseq += 'T'
        elif base == 'T':
            newseq += 'A'
        elif base == 'G':
            newseq += 'C'
        elif base == 'C':
            newseq += 'G'
        else:
            newseq += 'C'
            print("WARN: newseq += 'C'!!!")
            #print('fuck '+ base)
    #qstart, qend = (( - 1 - qend), ( - 1 - qstart))
    return newseq[::-1]

for scaffold in ref_dict.keys():
    n = 1
    #scaffold = 'Backbone_23'
    left_iter = bam_file.fetch(scaffold, 0, n)
    # num = cacul_num_of_iter(left_iter)
    # while num < 15 or num > 25:
    #     if n == 1 or n >= 20:
    #         break
    #     if num < 15:
    #         n += 1
    #     if num > 25:
    #         n -= 1
    #     left_iter = bam_file.fetch(scaffold, 0, n)
    #     num = cacul_num_of_iter(left_iter)
    # left_iter = bam_file.fetch(scaffold, 0, n)

    n = 1
    #scaffold = 'Backbone_23'
    right_iter = bam_file.fetch(scaffold, ref_dict[scaffold] - n, ref_dict[scaffold])
    # num = cacul_num_of_iter(right_iter)
    # while num < 15 or num > 25:
    #     if num < 15:
    #         n += 1
    #     if num > 25:
    #         n -= 1
    #     if n <= 1 or n >= 50:
    #         break
    #     right_iter = bam_file.fetch(scaffold, ref_dict[scaffold] - n, ref_dict[scaffold])
    #     num = cacul_num_of_iter(right_iter)
    # right_iter = bam_file.fetch(scaffold, ref_dict[scaffold] - n, ref_dict[scaffold])

    out_file_L = scaffold + "_L.fasta"
    outf_L = open(out_file_L, "w")
    left_count = 1
    for left in left_iter:
        if len(left.seq) < 100:
            continue
        if left.cigar[0][0] == 4 or left.cigar[0][0] == 5:
            head_len = left.cigar[0][1]
            head_sequence = PB_reads.fetch(left.query_name)
            if left.is_reverse:
                head_sequence = seq_pos_reverse_compliment(head_sequence)
            print(">"+scaffold+"/"+str(left_count), head_sequence[:head_len], file=outf_L, sep='\n', end='\n')
            left_count += 1
    outf_L.close()
    
    out_file_R = scaffold + "_R.fasta"
    outf_R = open(out_file_R, "w")
    right_count = 1
    for right in right_iter:
        if len(right.seq) < 100:
            continue
        if right.cigar[-1][0] == 4 or right.cigar[-1][0] == 5:
            tail_len = right.cigar[-1][1]
            tail_sequence = PB_reads.fetch(right.query_name)
            if right.is_reverse:
                tail_sequence = seq_pos_reverse_compliment(tail_sequence)
            print(">"+scaffold+"/"+str(right_count), tail_sequence[(len(tail_sequence)-tail_len):], file=outf_R, sep='\n', end='\n')
            right_count += 1
    outf_R.close()
    #break

# here just use S, don't use H, is this right?
bam_file.close()
PB_reads.close()