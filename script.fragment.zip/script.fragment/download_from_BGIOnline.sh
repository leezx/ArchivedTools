bo download -p  /lizhixin/Annotation/ wes_test ./


