#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
fastq stat script
Usage: python <script> <in.fastq>
"""

import pysam
import sys

if len(sys.argv) - 1 != 1:
    sys.exit(__doc__)

in_fastq_file = sys.argv[1]
in_fastq = pysam.FastxFile(in_fastq_file)

out_file = in_fastq_file.split(".fastq")[0] + "_stat.txt"
outf = open(out_file, "w")

total_base = 0
corrected_base = 0
reads_count = 0

for line in in_fastq:
    reads_count += 1
    total_base += len(line.quality)
    corrected_base += line.quality.count("I")
    #corrected_base +=  line.quality.rindex("I") - line.quality.index("I") + 1

print("corrected_base(I): ", corrected_base, "total_base: ", total_base, file=outf)
print("reads_count: ", reads_count, file=outf)

in_fastq.close()
outf.close()