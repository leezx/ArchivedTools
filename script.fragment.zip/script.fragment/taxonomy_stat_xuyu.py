import sys
import os
from collections import OrderedDict

if len(sys.argv) - 1 != 2:
	sys.exit(__doc__)

infile1,infile2 = sys.argv[1:]

def parse_taxonomy(infile):
	inf = open(infile,'r')

	taxonomy_dict = OrderedDict({1:set(),2:set(),3:set(),4:set(),5:set(),6:set(),7:set()})
	taxonomy_count = OrderedDict({1:0,2:0,3:0,4:0,5:0,6:0,7:0})
	for line in inf:
		if line.startswith('#'):
			continue
		line_list = line.strip().split()
		taxonomy_list = line_list[1].strip(";").split(';')
		for i,one in enumerate(taxonomy_list):
			temp_taxo = one.split('(')[0]
			if temp_taxo.endswith('unclassified'):
				continue
			taxonomy_dict[i+1].add(one.split('(')[0])
			#print(line_list,taxonomy_list,i+1,one)
		taxonomy_count[len(taxonomy_list)] += 1
	inf.close()
	return taxonomy_dict, taxonomy_count


if __name__ == "__main__":
	taxonomy_dict1, taxonomy_count1 = parse_taxonomy(infile1)
	taxonomy_dict2, taxonomy_count2 = parse_taxonomy(infile2)
	
	for key,value in taxonomy_dict1.items():
		# print(key,len(value),value)
		# print(key,len(taxonomy_dict2[key]),taxonomy_dict2[key])
		a = value
		b = taxonomy_dict2[key]
		# print(key, a&b, len(a&b), a|b, len(a|b), len(a&b)/len(a|b), sep='\n')
		print(key, len(a), len(b), len(a&b), len(a|b), len(a&b)/len(a|b), sep='\t')

	# for key,value in taxonomy_count1.items():
	# 	print(key,value)
	# 	print(key,taxonomy_count2[key])