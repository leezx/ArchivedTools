
use FindBin qw($Bin);
use Data::Dumper;
#use Time::Local; 

my $usage=<<END;

 perl $0 <in.lst> <out_prefix>
  <in.lst>      list of directories to be scanned.
  <out_prefix>  prefix of output files.

END

die $usage if (@ARGV != 2);

my ($inlst, $outprefix) = @ARGV;
my $DIR_SIZE = 15000;
my $FILE_SIZE = 1000000000;
my $FILE_Creat_Time = "2015-01-01";




sub format_time{   #���ڸ�ʽ��������ڣ�
  #input:($second_str1)  
  #output:($date_by_"YYYY-MM-DD")  
  $_cnt = @_;  
  unless ( $_cnt == 1 ){print "Worng input, please use input like: format_time(1368692601) \n"; exit;}  
    
    my ($sec,$min,$hour,$day,$mon,$year,$wday,$yday,$isdst) = localtime($_[0]);  
    $year = $year + 1900;

	if($mon<10)
	{
		$mon="0$mon";
	}
 	if($day<10)
	{
		$day="0$day";
	}
 
 return  "$year-$mon-$day";  
}  



sub two_day_minus{   #��ǰ�����������ڵ�ǰ��
  #input:($date1_by_"YYYY-MM-DD",$date2_by_"YYYY-MM-DD")  
  #output:($day_minus)  
  $_cnt = @_;  
  unless ( $_cnt == 2 ){print "Worng input, please use input like: format_time(20130515,20130516) \n"; exit;}  
   
  
 my @AFile= split("-",$_[0]);
 my @BFile= split("-",$_[1]);

if ($AFile[0]<$BFile[0])
{
	return -1;
}
elsif ($AFile[0]==$BFile[0])
{
	
		if ($AFile[1]<$BFile[1])
		{
			return -1;
		}
		elsif ($AFile[1]==$BFile[1])
		{
			
				if ($AFile[2]<$BFile[2])
				{
					return -1;
				}
		}
}

return 1; 

}  




system ("rm  -rf  $out.largedir  $out.largefile  $outprefix.stat   $outprefix.oldfile ");


open IN, "$Bin/etc_passwd" or die $!;
my %uid2name;
while (<IN>) {
	chomp;
	my @a1 =split /\:/, $_;
	$uid2name{$a1[2]} = $a1[0];
}

close IN;

open IN, "$inlst" or die $!;
open OUTSTAT, ">$outprefix.stat" or die $!;
print OUTSTAT " Total(MB)       BigDir  Num BigFile(MB) Num     BLCAccount Path\n";
print OUTSTAT "---------- ------------ ---- ---------- ---- -------------- ----\n";
while (<IN>) {
	chomp;
	my $size = 0;
	my ($largedir_size, $largedir_num, $largefile_size, $largefile_num) = (0, 0, 0, 0);
	recur($_, $outprefix, \$size, \$largedir_size, \$largedir_num, \$largefile_size, \$largefile_num) if (-e $_);
	$largefile_size = int($largefile_size/1000000);
	$size = int($size/1000000);
	my @c=stat($_);
	printf OUTSTAT "%10s %12s %4s %10s %4s %14s %-40s\n", $size, $largedir_size, 
		$largedir_num, $largefile_size, $largefile_num, $uid2name{$c[4]}, $_;
}
close IN;

sub recur {
	my $indir = shift;
	my $out = shift;
	my $size = shift;
	my $largedir_size = shift;
	my $largedir_num = shift;
	my $largefile_size = shift;
	my $largefile_num = shift;

	return if(!-e $indir);
	if (-l $indir) {
		${$size}+=108;
	}
	elsif (-f $indir)
	{
		return if(!-r $indir);
		my @a=stat($indir);
		${$size}+=$a[7];
		if ($a[7] >= $FILE_SIZE )
		#if ($a[7] >= $FILE_SIZE && $indir !~ /(.gz|.bz2|.bam|bit|.zip)$/)
		{
			${$largefile_size} += $a[7];
			${$largefile_num} ++;
			open OUT, ">>$out.largefile" or die $!;
			printf OUT "%16s %15s %s\n", $a[7], $uid2name{$a[4]}, $indir;
			close OUT;
		}
		my $b=format_time($a[9]);
		my $min=two_day_minus($b,$FILE_Creat_Time);
		if ($min<0)
		{
			open OUTA, ">>$out.oldfile" or die $!;
			printf OUTA "%16s %15s %s\n", $b, $uid2name{$a[4]}, $indir;
			close OUTA;
		}
		return;
	}
	elsif (-d $indir) {
		my @a=stat($indir);
		${$size}+=$a[7];
		return if (!-x $indir || !-r $indir);
		if ($a[7] < $DIR_SIZE)
		{
			opendir DIR, "$indir" or die $!;
			my @b=readdir(DIR);
			closedir DIR;

			for my $eachb (@b) {
				next if ($eachb eq "." || $eachb eq "..");
				recur("$indir/$eachb", $out, $size, $largedir_size, $largedir_num, $largefile_size, $largefile_num);
			}
		}
		else {
			${$largedir_size} += $a[7];
			${$largedir_num} ++;
			open OUT, ">>$out.largedir" or die $!;
			printf OUT "%16s %15s %s\n", $a[7], $uid2name{$a[4]}, $indir;
			close OUT;
		}
	}
}


