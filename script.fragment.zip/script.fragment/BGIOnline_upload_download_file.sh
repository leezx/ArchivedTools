bo login -u wangxb -p BGIonline_110
bo upload_file -p /lizhixin/file wes_test bam2depth
bo download -p  /lizhixin/file/bam2depth wes_test ./
