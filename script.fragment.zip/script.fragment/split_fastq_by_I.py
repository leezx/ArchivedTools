#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
split and extraxt corrected and uncorrected seq, by qual 'I'
Usage: python <script> <in.fastq>
"""

import pysam
import re
import os
import sys

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

in_file = sys.argv[1]

#in_file = './merger_new.fastq'
out_file_1 = './extract_correct_region_for_stat.txt'
out_file_2 = './extract_un_correct_region_for_stat.txt'
fastq = pysam.FastxFile(in_file)
outf_1 = open(out_file_1, 'w')
outf_2 = open(out_file_2, 'w')

def split_fastq_by_I(seq_name, seq, qual, outf):
	pos = 0
	flag = 0
	head_pos = 0
	tail_pos = 0
	for one_qual in qual:
		if one_qual == 'I':
			seq = seq[:pos] + "I" + seq[(pos+1):]
		pos += 1
	seq_list = re.split('I+', seq)
	qual_list = re.split('I+', qual)
	if not seq_list[0]:
		del seq_list[0]
	if not seq_list[-1]:
		del seq_list[-1]
	if not qual_list[0]:
		del qual_list[0]
	if not qual_list[-1]:
		del qual_list[-1]
	count = 0
	for one_seq in seq_list:
		temp_seq_name = '@' + seq_name + '_' + str(count)
		#print(temp_seq_name, one_seq, '+', qual_list[count], file=outf, sep='\n', end='\n')
		print(len(one_seq), file=outf)
		count += 1

def extract_I_qual(qual):
	pointer = 0
	I_list = []
	I_len = 0
	for one in qual:
		pointer += 1
		if one == 'I':
			I_len += 1
		if one != 'I':
			if pointer != 1 and I_len != 0:
				I_list.append(I_len)
			I_len = 0
	if one == 'I':
		I_list.append(I_len)
	return I_list

def extract_not_I_qual(qual):
	pointer = 0
	not_I_list = []
	not_I_len = 0
	for one in qual:
		pointer += 1
		if one != 'I':
			not_I_len += 1
		if one == 'I':
			if pointer != 1 and not_I_len != 0:
				not_I_list.append(not_I_len)
			not_I_len = 0
	if one != 'I':
		not_I_list.append(not_I_len)
	return not_I_list

I_len_list = []
not_I_list = []

for line in fastq:
	seq_name = line.name
	seq = line.sequence
	qual = line.quality
	#split_fastq_by_I(seq_name, seq, qual, outf_2)
	I_len_list += extract_I_qual(qual)
	not_I_list += extract_not_I_qual(qual)
	#break

for one in I_len_list:
	print(one, file=outf_1)

for one in not_I_list:
	print(one, file=outf_2)

fastq.close()
outf_1.close()
outf_2.close()