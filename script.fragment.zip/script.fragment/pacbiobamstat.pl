#!/usr/bin/perl

use warnings;
use strict;
use Getopt::Long;
use Data::Dumper;
use File::Basename;
use FindBin qw($Bin);
use Cwd;

my ($bamfile,$outprefix,$help);

GetOptions(
        "input:s"=>\$bamfile,
        "outprefix:s"=>\$outprefix,
        "h"=>\$help,
);

my $usage=<<USAGE;
Discription: Stat Mismatch,Insertion,Deletion of Bam;
Author: Helijuan
usage:perl $0
          -input <bamfile>
          -outprefix <outfileprefix>
          -h help
USAGE

die $usage if (!$bamfile || $help || !$outprefix);

my $clean_reads=0;
my $total_bases=0;
my $mapped_reads=0;
my $mapped_bases=0;
my $mapping_rate=0;
my $Mismatch_bases=0;
my $Insertion_bases=0;
my $Deletion_bases=0;
my $Mismatch_rate=0;
my $Insertion_rate=0;
my $Deletion_rate=0;
my $error_rate=0;

open BAM,"/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/processBam/processBam_v1.0/bin/samtools view $bamfile | " or die $!;
open OUT1, ">$outprefix.mapdetail.xls" ||die $!;
print OUT1 "readsID\tflag\trefID\tbases_num\tmapped(Y|N)\tInsertion_bases\tDeletion_bases\tMismatched_bases\n";
my %hash;
while(<BAM>)
{
        chomp;
        my @line = split /\t/,$_;
        my $fflag= $line[1];
        my $dup_lines="N";
        my $line_bases=0;
        my $line_mismatch_bases=0;
        my $line_mapped="N";
        my $line_insertion=0;
        my $line_deletion=0;
#        $clean_reads++;
        next if($fflag eq 0x810 ||$fflag eq 0x800); ###0x810 and 0x800 represent supplementary alianment
        $clean_reads++ unless(exists $hash{$line[0]}{'clean_reads'});
        $hash{$line[0]}{'clean_reads'}=1;
        $total_bases+=length($line[9]);

        $line_bases=length($line[9]);

        unless ($fflag & 0x4) {   ### 0x4 presents unmap
                $mapped_reads++ unless(exists $hash{$line[0]}{'mapped_reads'});
                $hash{$line[0]}{'mapped_reads'}=1;
                $line_mapped="Y";
                if($_=~/XC:i:(\d+)/) {$mapped_bases+=$1;}
                else {$mapped_bases+=length($line[9]);}
                ($line_insertion, $line_deletion)=IndelNo($line[5]);
                $Insertion_bases+=$line_insertion;
                $Deletion_bases+=$line_deletion;
                if($_=~/XM:i:(\d+)/)
                {
                    $Mismatch_bases +=$1;
                    $line_mismatch_bases = $1;
                }elsif ($_ =~ /MD:Z:(\S+)/) {
                    $Mismatch_bases += CoutMismathNo($_);
                    $line_mismatch_bases = CoutMismathNo($_);
                }
        }
        print  OUT1 "$line[0]\t$line[1]\t$line[2]\t$line_bases\t$line_mapped\t$line_insertion\t$line_deletion\t$line_mismatch_bases\n";
        
#        die if ($mapped_reads>=1);
}
close BAM;
close OUT1;


$mapping_rate=sprintf("%.3f",($mapped_reads/$clean_reads)*100);
$Insertion_rate=sprintf("%.3f",($Insertion_bases/$total_bases)*100);
$Deletion_rate=sprintf("%.3f",($Deletion_bases/$total_bases)*100);
$Mismatch_rate=sprintf("%.3f",($Mismatch_bases/$total_bases)*100);
$error_rate=sprintf("%.3f",($Insertion_rate+$Deletion_rate+$Mismatch_rate));

open OUT2,">$outprefix.statistics.xls" or die $!;
print OUT2 "Total reads: $clean_reads\n";
print OUT2 "Total bases: $total_bases\n";
print OUT2 "Mapped reads: $mapped_reads\n";
print OUT2 "Mapped Bases(contain Insertion and Mismatch): $mapped_bases\n";
print OUT2 "Insertion(rate): $Insertion_bases($Insertion_rate%)\n";
print OUT2 "Deletion(rate): $Deletion_bases($Deletion_rate%)\n";
print OUT2 "Mismatch(rate): $Mismatch_bases($Mismatch_rate%)\n";
print OUT2 "Reads mapped rate: $mapping_rate%\n";
print OUT2 "Error rate: $error_rate%\n";



my $md_value;
sub CoutMismathNo
{
        my ($align_result) = @_;
        if ($align_result =~ /MD:Z:(\S+)/){ #MD:Z:7C22C5^ACCCT46
                $md_value = $1;
        }
        else {
                print STDERR "$align_result\n";
        }

        my $mark = 0;
        my $mismatch_no = 0;
        for (my $i = 0; $i < length($md_value); $i++) {
                if (substr($md_value, $i, 1) eq '^') {
                        $mark = 1;
                }
                elsif (substr($md_value, $i, 1) =~ /[A-Z]/ && $mark == 0) {
                        $mismatch_no++;
                }
                elsif (substr($md_value, $i, 1) =~ /\d/) {
                        $mark = 0;
                }
        }
        return $mismatch_no;
}

sub IndelNo
{
    my ($align_result)=@_;
    my $insertion=0;
    my $deletion=0;

    my $indel_mark="[^0-9]?([0-9]+I)";
    while($align_result=~/$indel_mark/ig){
        my $insert=$1;
        if($insert=~/(\d+)I/){
            $insertion+=$1;
        }
    }
#   print "I:$insertion\n";


    my $delete_mark="[^0-9]?([0-9]+D)";
    while($align_result=~/$delete_mark/ig){
        my $delete=$1;
        if($delete=~/(\d+)D/){
            $deletion+=$1;
        }
    }
#    print "D:$deletion\n";
    return ($insertion,$deletion);
}
