#!/bin/bash

blasr input.fofn PB_chr22_20X_random.fasta -sam -out alignments.sam -nproc 16 -minMatch 30
