import os
from subprocess import call

ref="/ifs4/BC_RD/USER/lizhixin/my_project/consensus_extend/denovo_ref/merged_DBG2OLC_denovo.fasta"

split_file_dir = "../split_fastq"
file_list = os.listdir(split_file_dir)
merge_bam_list = []

sh_count = 0
for one_file in file_list:
	sh_count += 1
	temp_sh_file = "./bwa_mem_" + str(sh_count) + ".sh"
	temp_fastq_file = os.path.join(split_file_dir, one_file)
	out_bam = str(sh_count) + ".bam" 
	merge_bam_list.append(out_bam)
	#temp_out_file = "./out_" +str(sh_count) + ".txt"
	#temp_stat_file =  "./stat_" +str(sh_count) + ".txt"
	outf = open(temp_sh_file, "w")
	head = "#!/bin/bash"
	# tail = "echo ==========end  at : `date` =========="
	cmd = "bwa mem -t 9 -x pacbio -B2 -w200 -D200 %s %s | samtools view -bS - > %s" % (ref, one_file, out_bam)
	print(head, cmd, file=outf, sep='\n', end='\n')
	outf.close()

	# qsub_cmd = "qsub -cwd -l vf=1g -P HUMDnab -q bc.q,bc_rd.q %s" % (temp_sh_file)
	# qsub_cmd_list = qsub_cmd.split()
	# call(qsub_cmd_list)

merge_sh = "merge_bam.sh"
mergef = open(merge_sh, "w")
head = "#!/bin/bash"
merge_bam_cmd = ""
for one in merge_bam_list:
	merge_bam_cmd += ("I=" + one + " ")
cmd="java -jar /ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/picard/MergeSamFiles.jar %s  O=merge.bam" % (merge_bam_cmd)
print(head, cmd, file=mergef, sep='\n', end='\n')
mergef.close()