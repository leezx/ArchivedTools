#!/bin/bash
echo ==========start at : `date` ==========

#ref=/ifs4/BC_RD/USER/lizhixin/database/arabidopsis_TAIR9/TAIR9_chr_all.fasta
#fasta=/opt/lustresz/BC_PMO_P0/BC_RD/dengtq/01.Pacbio/00.data/arabidopsis/ECtools_corrected.fa.gz
ref=$1
fasta=$2

bwa mem -t 30 -x pacbio -B2 -w200 -D200 $ref $fasta | samtools view -bS -F 4 - > corrected_fastq_for_stat.bam &&\
python bam_info_stat_for_I.py corrected_fastq_for_stat.bam &&\

echo ==========end  at : `date` ==========

