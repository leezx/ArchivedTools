import pysam
import ctypes 
import numpy as np
import os
lib = ctypes.cdll.LoadLibrary(
        os.path.join(os.path.dirname(os.path.realpath(__file__)),
            'diff-cpp-master','libLLCS.so'))

in_file = "/ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/ref/kmer.fasta"
out_file = "./group_result_sort.txt"
#temp_file = "./temp_file.txt"

inf = pysam.FastaFile(in_file)
outf = open(out_file, 'w')
#tempf = open(temp_file, 'w')

def calc_LLCS(a, b):
    a = np.asarray(a, dtype=np.int_)
    b = np.asarray(b, dtype=np.int_)
    ptr = ctypes.POINTER(ctypes.c_long)
    a_ptr = a.ctypes.data_as(ptr)
    b_ptr = b.ctypes.data_as(ptr)
    return lib.calc_llcs(a_ptr, a.size,b_ptr, b.size)

map_kmer_dict = {}
for query in inf.references:
    query_kmer = inf.fetch(query)
    map_count = 0
    for ref in inf.references:
        if query == ref:
            continue
        ref_kmer = inf.fetch(ref)
        #new_ref, new_query = Global_Alignment_NW(ref_kmer, query_kmer)
        NM = 23 - calc_LLCS(list(map(ord, ref_kmer)), list(map(ord, query_kmer)))
        if NM <= 2:
            map_count += 1
            print(query, query_kmer, ref, ref_kmer, NM)
    if map_count < 5:
        continue
    map_kmer_dict[query] = map_count
    #break

map_kmer_list = sorted(map_kmer_dict.items(), key=lambda item:item[1], reverse=True)
for pair in map_kmer_list:
    print(pair[0], pair[1], file=outf, sep='\t', end='\n')

inf.close()
outf.close()
#tempf.close()
