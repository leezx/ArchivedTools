#!/usr/bin/env python
# Author: LI ZHIXIN(modified from SHI ZHUOXING)

ref='ATTCGATAGTATTACAACA'
query='ATTGATATAATACACA'

def Local_Alignment_SW(ref, query):
	# Scoring rules from BWA
	MATCH = 1
	MISMATCH = -4
	GAP = -6
	GAP_EXT = -1

	# Dynamic programming matrix initialization(0 cols and 0 rows): (ref X query)
	cols = len(ref) + 1 
	rows = len(query) + 1
	DP_matrix = [[{} for col in range(cols)] for row in range(rows)]
	DP_matrix[0][0]['score'] = 0
	DP_matrix[0][0]['pointer'] = 'none'

	i = 1
	while i < cols:
		DP_matrix[0][i]['score'] = GAP + GAP_EXT*(i-1)
		DP_matrix[0][i]['pointer'] = 'left'
		i += 1
	j = 1
	while j < rows:
		DP_matrix[j][0]['score'] = GAP + GAP_EXT*(j-1)
		DP_matrix[j][0]['pointer'] = 'up'
		j += 1

	# for one in DP_matrix:
	# 	print(one)

	# Cacul and Fill the Dynamic programming matrix from (0,0) to (m,n)
	# i, j may make some mistake!!!

	# add
	i_of_max = 0
	j_of_max = 0
	max_score_flag = 0

	i = 1
	while i <= len(query):
		j = 1  # i = 1 hahaha!!!
		while j <= len(ref):
			# calculate match score
			ref_base = ref[j-1]
			query_base = query[i-1]
			#diagonal_score = 0; up_score = 0; left_score = 0
			if ref_base == query_base:
				diagonal_score = DP_matrix[i-1][j-1]['score'] + MATCH
			else:
				diagonal_score = DP_matrix[i-1][j-1]['score'] + MISMATCH
			# calculate gap scores
			if DP_matrix[i-1][j]['pointer'] == 'up':
				up_score = DP_matrix[i-1][j]['score'] + GAP_EXT
			else:
				up_score = DP_matrix[i-1][j]['score'] + GAP
			if DP_matrix[i][j-1]['pointer'] == 'left':
				left_score = DP_matrix[i][j-1]['score'] + GAP_EXT
			else:
				left_score = DP_matrix[i][j-1]['score'] + GAP
			# choose best score
			max_score = max(diagonal_score, up_score, left_score)
			# add, RESET
			if max_score <= 0:
				DP_matrix[i][j]['score'] = 0
				DP_matrix[i][j]['pointer'] = 'none'
				j += 1 # hehehe!!!
				continue

			#print(max_score)
			if max_score == diagonal_score:  # priority
				DP_matrix[i][j]['score'] = diagonal_score
				DP_matrix[i][j]['pointer'] = 'diagonal'
			elif max_score == up_score:
				DP_matrix[i][j]['score'] = up_score
				DP_matrix[i][j]['pointer'] = 'up'
			elif max_score == left_score:
				DP_matrix[i][j]['score'] = left_score
				DP_matrix[i][j]['pointer'] = 'left'
			# add, set flag for next step
			if DP_matrix[i][j]['score'] > max_score_flag:
				i_of_max = i
				j_of_max = j
				max_score_flag = DP_matrix[i][j]['score']
			j += 1
		i += 1

	# for one in DP_matrix:
	# 	print(one)

	# Trace back to find the aligment sequence
	# i = len(query); j = len(ref)
	# change
	i = i_of_max; j = j_of_max

	new_ref = ''
	new_query = ''
	while True:
		if DP_matrix[i][j]['pointer'] == 'none':
			break
		if DP_matrix[i][j]['pointer'] == 'diagonal':
			new_ref += ref[j-1]
			new_query += query[i-1]
			i -= 1
			j -= 1
		elif DP_matrix[i][j]['pointer'] == 'left':
			new_ref += ref[j-1]
			new_query += '-'
			j -= 1
		elif DP_matrix[i][j]['pointer'] == 'up':
			new_ref += '-'
			new_query += query[i-1]
			i -= 1

	# reverse
	new_ref = new_ref[::-1]
	new_query = new_query[::-1]

	# summary
	# local and global variable
	# 2 X for, i, j
	# two-dimensional array of python, coordinates
	# A variety of results, Temporarily ignore
	return new_ref, new_query

if __name__ == "__main__":
	new_ref, new_query = Local_Alignment_SW(ref, query)
	print(new_ref)
	print(new_query)