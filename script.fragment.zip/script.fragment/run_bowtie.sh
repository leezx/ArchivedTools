#!/bin/bash

bowtie2 -p 15 -x index --fast-local -N 1 -L 10 --ma 5 --mp 11 --rdg 1,3  --rfg 2,4  -1 /ifs4/BC_RD/USER/lizhixin/data/chr22/hiseq_reads/R1_chr22.fastq.gz -2 /ifs4/BC_RD/USER/lizhixin/data/chr22/hiseq_reads/R2_chr22.fastq.gz -S fast-local.sam


