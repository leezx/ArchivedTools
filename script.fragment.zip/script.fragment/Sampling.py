import pysam

in_file = './merger_new.fastq'
out_file = './stat_list.txt'
fastq = pysam.FastxFile(in_file)
outf = open(out_file, 'w')



def Sampling_of_Qual_I(qual, stat_list):
    corrd = [i for i in range(11)]
    i = 1
    while i <= 9: 
        corrd[i] = int(i/10*len(qual))
        i += 1
    corrd[0] = 1
    corrd[-1] = 0
    for one in corrd:
        if qual[one-1] != "I":
            stat_list[corrd.index(one)] += 1
    return stat_list

stat_list = [0 for i in range(11)]

for line in fastq:
    #seq_name = line.name
    #seq = line.sequence
    qual = line.quality
    stat_list = Sampling_of_Qual_I(qual, stat_list)
    # break

print(stat_list, file=outf)

fastq.close()
outf.close()
