#!/usr/bin/perl

use strict;
use File::Basename;
use Bio::SeqIO;

my $file = shift(@ARGV) || die "Usage: ".basename($0)." <file>\n";

my $seqin  = Bio::SeqIO->new(-file => "$file" , '-format' => 'Fasta');
my %seqlen;
my %letter_num;
my $seqnum = 0;
my $totallen = 0;
my %count;
my @letters = ('A','T','G','C', 'a', 't', 'g', 'c', 'N', 'n');
while (my $seq = $seqin->next_seq()) {
    $seqlen{$seq->length()} ++;
    $seqnum++;
    $totallen += $seq->length();
    my $s = $seq->seq;
    print $seq->id, ' ', $seq->length, "\n" if $seq->length > 5000000;
    foreach my $l (@letters) {
	my $n = () = $s =~ /$l/g;	
	if ($n > 0) {$letter_num{$l} += $n;}
    }
}

my @lens = sort {$a <=> $b} keys %seqlen;
print STDOUT "The number of sequences: $seqnum\n";
print STDOUT "The total length: $totallen\n";
foreach my $c (sort keys %letter_num) {
    print STDOUT "$c: ", $letter_num{$c}, ' (', sprintf("%.1f", 100*$letter_num{$c}/$totallen), '%)', "\n";
}
print STDOUT "\n";
print STDOUT "Minimum sequence length: ", $lens[0], "\n";
print STDOUT "Maximum sequence length: ", $lens[$#lens], "\n";
print STDOUT "Average sequence length: ", int($totallen/$seqnum), "\n";
my $median = 0;
my $half = 0;
foreach my $len (@lens) {
    if ($half >= $seqnum * 0.5) { $median = $len; last;}
    else { $half += $seqlen{$len}; }
}
print STDOUT "Median sequence length: ", $median, "\n";

$file = basename($file);
print_length("$file.len.stat", \%seqlen);
exit;

sub print_length {
    my ($out, $hash) = @_;
    print STDERR "Write length stats to file $out \n";
    open (OUT, ">$out");
    foreach my $length (sort{$a<=>$b} keys %$hash) {
	print OUT $length, "\t", $hash->{$length}, "\n";
    }
    close OUT;
}

