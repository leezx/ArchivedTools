import os
import glob
from subprocess import call

target_dir = "/ifs1/pub/database/ftp.ncbi.nih.gov/giab/ftp/data/AshkenazimTrio/HG002_NA24385_son/PacBio_MtSinai_NIST/hdf5"
dir_list = os.listdir(target_dir)
#head = "#!/bin/bash\n\necho ==========start at : `date` ==========\n"
#tail = "\necho ==========end  at : `date` ==========\n"

temp_file = "./tar_zxvf.sh"
outf = open(temp_file, "w")

count = 1
for one_dir in dir_list:
    temp_dir = os.path.join(target_dir, one_dir)
    if os.path.isfile(temp_dir):
        continue
    # if one_dir == "HG002_BP_P5_061114_MB_150pM":
    #     continue
    
    file_list = os.listdir(temp_dir)
    for one_file in file_list:
        file_dir = os.path.join(temp_dir, one_file)
        temp_target_dir = "/ifs4/BC_RD/USER/lizhixin/pacbio/" + str(count)
        os.mkdir(temp_target_dir)

        cmd1 = "tar zxvf %s -C %s" % (file_dir, temp_target_dir)
        cmd2 = "mv "+ temp_target_dir + "/sc/orga/projects/pacbio/userdata_permanent/raw/*/*/Analysis_Results/*.fastq /ifs4/BC_RD/USER/lizhixin/my_project/denovo_chr22/PacBio_reads/subreads_fastq"
        cmd3 = "rm -r " + temp_target_dir
        print(cmd1, cmd2, cmd3, file=outf, sep=';', end='\n')

        # check_dir = "/ifs4/BC_RD/USER/lizhixin/pacbio/sc/orga/projects/pacbio/userdata_permanent/raw"
        # dir_list = os.listdir(check_dir)
        # if len(dir_list) >= 5:
        #     print(one_dir, one_file)
        #     break
        #qsub_cmd = "qsub -cwd -l vf=1g -P HUMDnab -q bc.q %s" % (temp_file)
        #qsub_cmd_list = qsub_cmd.split()
        #call(qsub_cmd_list)

        count += 1
        #break
    #break

outf.close()