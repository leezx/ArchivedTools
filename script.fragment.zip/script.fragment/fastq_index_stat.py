#!/usr/bin/env python
# Author: LI ZHIXIN

import gzip

inf = gzip.open("/nas/fqdata043A/HiSeq2500_rapid/F16FTSNCKF3089_CERriaE/CWHPEI17010054-A/170207_I191_FCHCGKFBCXY_L1_CWHPEI17010054-A/170207_I191_FCHCGKFBCXY_L1_CWHPEI17010054-A_1.fq.gz", "rb")

index_dict = {}
index_dict_8 = {}
for line in inf:
    line = line.decode()
    if not line.startswith("@"):
        continue
    line = line.split('#')[-1][:-3]
    if line in index_dict.keys():
        index_dict[line] += 1
    else:
        index_dict[line] = 0

    if line[:8] in index_dict_8.keys():
        index_dict_8[line[:8]] += 1
    else:
        index_dict_8[line[:8]] = 0

inf.close()

index_sorted = sorted(index_dict.items(), key=lambda item:item[1], reverse=True)
index_sorted_8 = sorted(index_dict_8.items(), key=lambda item:item[1], reverse=True)

with open("index_stat_1.txt", "w") as outf:
    for one in index_sorted:
        print(one[0], one[1], file=outf)

with open("index_stat_2.txt", "w") as outf2:
    for one in index_sorted_8:
        print(one[0], one[1], file=outf2)
