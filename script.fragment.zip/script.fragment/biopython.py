from Bio import SeqIO
import datetime

print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

file="/share/fqdata108A/Zebra/F15NGS03003_HUMoah/WHHUMoahAAAASAAZebra-47/170205_I44_CL100013600_L1_WHHUMoahAAAASAAZebra-47/CL100013600_L01_read_1.fq.gz"
handle =  open(file, "rbU")

count = 0
for record in SeqIO.parse(handle, "fasta"):
	count += 1

print(count)

print(datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S'))

