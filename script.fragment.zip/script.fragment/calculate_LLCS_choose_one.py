#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
calculate the LLCS between two kmers
Usage: python <script> <query_kmer> <out.result>
"""
import pysam
import ctypes 
import numpy as np
import os
import sys

# if len(sys.argv) - 1 != 2:
#     sys.exit(__doc__)

# Backbone_dir, out_dir = sys.argv[1:]

Backbone_dir = "./Backbone"
list_file    = "./Backbone/Backbone.list"
out_dir      = "./Backbone_out"
if not os.path.exists(out_dir):
    os.mkdir(out_dir)

lib = ctypes.cdll.LoadLibrary("/ifs4/BC_RD/USER/lizhixin/script/libLLCS.so")
# lib = ctypes.cdll.LoadLibrary(
#         os.path.join(os.path.dirname(os.path.realpath(__file__)),
#             'diff-cpp-master','libLLCS.so'))

#in_file = "/ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/kmer.txt"
#ref_file = "/ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/kmer.txt"
#out_file = "./group_result_sort.txt"

#Backbone_list = os.listdir(Backbone_dir)
Backbone_list = []
listf = open(list_file, "r")
for line in listf:
    Backbone_list.append(line.strip())
listf.close()

# define before use!!!
def calc_LLCS(a, b):
    a = np.asarray(a, dtype=np.int_)
    b = np.asarray(b, dtype=np.int_)
    ptr = ctypes.POINTER(ctypes.c_long)
    a_ptr = a.ctypes.data_as(ptr)
    b_ptr = b.ctypes.data_as(ptr)
    return lib.calc_llcs(a_ptr, a.size,b_ptr, b.size)

for one_file in Backbone_list:
    in_file = os.path.join(Backbone_dir, one_file)
    out_file = os.path.join(out_dir, one_file)
    inf = pysam.FastaFile(in_file) # no 'r'!!!
    outf = open(out_file, 'w')
    reads_dict = {}
    for reads_name in inf.references:
        reads_dict[reads_name] = inf.fetch(reads_name)
    inf.close()
    reads_LLCS_len = {}
    for query_name in reads_dict.keys():
        reads_LLCS_len[query_name] = 0
        for ref_name in reads_dict.keys():
            if query_name == ref_name:
                continue
            similar_len = calc_LLCS(list(map(ord, reads_dict[query_name])), list(map(ord, reads_dict[ref_name])))
            reads_LLCS_len[query_name] += similar_len
    sorted_dict = sorted(reads_LLCS_len.items(), key=lambda item:item[1], reverse=True)
    best_one = sorted_dict[0][0]
    print(">"+best_one, reads_dict[best_one], file=outf, sep='\n', end='\n')
    outf.close()
    #break

# for query in inf:
#     query_kmer, query_kmer_count = query.strip().split()
#     map_count = 0
#     total_appear_count = int(query_kmer_count)
#     reff = open(ref_file, 'r')
#     for ref in reff: #hahaha!!!
#         ref_kmer, ref_kmer_count = ref.strip().split()
#         NM = 23 - calc_LLCS(list(map(ord, ref_kmer)), list(map(ord, query_kmer)))
#         if NM <= 3:
#             map_count += 1
#             total_appear_count += int(ref_kmer_count)
#     if map_count > 10:
#         print(query_kmer, map_count, total_appear_count, file=outf, sep='\t', end='\n')
#     reff.close()

# inf.close()
# outf.close()