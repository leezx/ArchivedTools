python /ifs4/BC_RD/PROJECT/RD_LZX_correction/app/RSeQC-2.3.6/scripts/read_distribution.py -i sort.bam -r hg19.bed > Hiseq_4000.distribute.txt
