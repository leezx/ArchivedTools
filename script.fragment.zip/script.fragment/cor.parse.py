import sys
import os
from collections import OrderedDict
from numpy import array, cov, corrcoef

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

# infile1,infile2 = sys.argv[1:]
infile_list = sys.argv[1]

def parse_taxonomy(infile):
	inf = open(infile,'r')

	taxonomy_dict = OrderedDict()
	for line in inf:
		line_list = line.strip().split()
		if len(line_list) == 1:
			continue
		taxonomy_dict[line_list[0]] = line_list[1]
	print(taxonomy_dict)
	inf.close()
	return taxonomy_dict

def cov_num(infile1,infile2):
	taxonomy_dict1 = parse_taxonomy(infile1)
	taxonomy_dict2 = parse_taxonomy(infile2)
	total_key = set(taxonomy_dict1.keys()) | set(taxonomy_dict2.keys())
	print(total_key)
	data1 = []
	data2 = []
	for one in total_key:
		if one in taxonomy_dict1.keys():
			# print(taxonomy_dict1[one], end=',')
			data1.append(float(taxonomy_dict1[one]))
		else:
			# print(0, end=',')
			data1.append(0)
	# print('\n')
	for one in total_key:
		if one in taxonomy_dict2.keys():
			# print(taxonomy_dict2[one], end=',')
			data2.append(float(taxonomy_dict2[one]))
		else:
			# print(0, end=',')
			data2.append(0)
	# print('\n')
	print(data1, data2)
	data = array([data1, data2])
	print(corrcoef(data))
	# print(corrcoef(data1,data2))

if __name__ == "__main__":
	with open(infile_list, 'r') as inf:
		for line in inf:
			line_list = line.strip().split()
			if not line_list:
				continue
			infile1, infile2 = line_list[0], line_list[1]
			cov_num(infile1,infile2)
			print('\n')
