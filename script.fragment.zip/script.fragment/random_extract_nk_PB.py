#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
Random Extract nX data from fasta or fastq for test!
only support fastq, fasta, fastq.gz or fasta.gz file!
Usage: python <script> <fasta or fastq or fastq.gz> <a fraction of the origin>
eg. python split_txt_or_gz_file.py PB_chr22_20X_random.fastq.gz 13
"""

import pysam
# import gzip
import random
import sys

if len(sys.argv) - 1 != 2:
    sys.exit(__doc__)

#in_file, percent = sys.argv[1:]
in_file, nk = sys.argv[1:]

# PB_chr22_file = "/ifs4/BC_RD/USER/lizhixin/my_project/denovo_chr22/pacbio_call_variation/PB_chr22.fastq.gz"
# PB_chr22_file_10X = "./PB_chr22_10X_random.fastq.gz"

def count_lines_number_of_file(in_file, file_type):
    "only support fastq, fasta, fastq.gz or fasta.gz file!"
    if file_type == "fasta":
        inf = pysam.FastaFile(in_file)
        return inf.nreferences
    elif file_type == "fastq":
        inf = pysam.FastxFile(in_file)
    else:
        sys.exit(__doc__)
    count = 0
    for line in inf:
        count += 1
    inf.close()
    return count

if in_file.split(".")[-1] == "fasta" or (in_file.split(".")[-1] == "gz" and in_file.split(".")[-2] == "fasta"):
    file_type = "fasta"
if in_file.split(".")[-1] == "fastq" or (in_file.split(".")[-1] == "gz" and in_file.split(".")[-2] == "fastq"): 
    file_type = "fastq"

if file_type == "fasta":
    outf = open("out.fasta", "w")
    total_reads = count_lines_number_of_file(in_file, file_type)
    random_num = set()
    #while len(random_num) < int(total_reads * int(percent)/100):
    while len(random_num) < int(nk)*1000:
        random_num.add(random.randint(1,total_reads))
    reads_count = 0
    inf = pysam.FastaFile(in_file)
    reads_name = inf.references
    for one in reads_name:
        seq = inf.fetch(one)
        if reads_count in random_num:
            print(">"+one, seq, file=outf, sep='\n', end='\n')
        reads_count += 1

if file_type == "fastq":
    outf = open("out.fastq", "w")
    total_reads = count_lines_number_of_file(in_file, file_type)
    random_num = set()
    #while len(random_num) < int(total_reads * int(percent)/100):
    while len(random_num) < int(nk)*1000:
        random_num.add(random.randint(1,total_reads))
    reads_count = 0
    inf = pysam.FastxFile(in_file)
    for line in inf:
        if reads_count in random_num:
            print("@"+line.name, line.sequence, "+", line.quality, file=outf, sep='\n', end='\n')
        reads_count += 1

outf.close()
inf.close()

# PB_fastq = gzip.open(PB_chr22_file, "rb")
# PB_fastq_10X = gzip.open(PB_chr22_file_10X, "wb")

# total_reads = 353418
# random_num = set()
# while len(random_num) < int(total_reads * (10 / 60)):
#     random_num.add(random.randint(1,total_reads))

# PB_count = 0
# line_count = 0
# for line in PB_fastq:
#     PB_count = line_count // 4 + 1
#     if PB_count in random_num:
#         PB_fastq_10X.write(line)
#     line_count += 1
#     # if PB_count == 99:
#     #     break

# PB_fastq.close()
# PB_fastq_10X.close()


