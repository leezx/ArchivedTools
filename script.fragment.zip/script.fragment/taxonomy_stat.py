import sys
import os
from collections import OrderedDict

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

infile = sys.argv[1]
inf = open(infile,'r')

taxonomy_dict = OrderedDict({1:set(),2:set(),3:set(),4:set(),5:set(),6:set(),7:set()})
taxonomy_count = OrderedDict({1:0,2:0,3:0,4:0,5:0,6:0,7:0})
for line in inf:
	if line.startswith('#'):
		continue
	line_list = line.strip().split()
	taxonomy_list = line_list[2].split(';')
	for i,one in enumerate(taxonomy_list):
		taxonomy_dict[i+1].add(one)
		#print(line_list,taxonomy_list,i+1,one)
	taxonomy_count[len(taxonomy_list)] += 1

for key,value in taxonomy_dict.items():
	print(key,len(value),value)

for key,value in taxonomy_count.items():
        print(key,value)
