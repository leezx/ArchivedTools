#!/usr/bin/perl

use strict;
use warnings;

my $file = shift or die $!;
($file =~ /gz$/) ? (open IN, "gzip -dc $file |" or die $!) : (open IN, "$file" or die $!);
my $num = 0;
while(<IN>){
	chomp;
	my $line1 = $_;
	my $line2 = <IN>;
	$num += 2;
	chomp($line2);
	die "$num - 1: $line1" if ($line1 !~ /^>/);
	$line1 =~ s/^>//;
	print "\@$line1\n$line2\n+\n" . "]" x length($line2) . "\n";
}
