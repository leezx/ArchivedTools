my_matrix = [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]]
with open('PB2.ccs.bam.out.rq.np', 'r') as inf:
	for line in inf:
		line_list = line.strip().split()
		#my_matrix = [[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0],[0,0,0,0,0,0]]
		x = float(line_list[0])
		y = int(line_list[1])
		if x < 0.98:
			print(x, '0_980', end='\t', sep='\t')
		elif 0.98 <= x < 0.981:
			print(x, '980_981', end='\t', sep='\t')
		elif 0.981 <= x < 0.982:
			print(x, '981_982', end='\t', sep='\t')
		elif 0.982 <= x < 0.983:
			print(x, '982_983', end='\t', sep='\t')
		elif 0.983 <= x < 0.984:
			print(x, '983_984', end='\t', sep='\t')
		elif 0.984 <= x < 0.985:
			print(x, '984_985', end='\t', sep='\t')
		elif 0.985 <= x < 0.986:
			print(x, '985_986', end='\t', sep='\t')
		elif 0.986 <= x < 0.987:
			print(x, '986_987', end='\t', sep='\t')
		elif 0.987 <= x < 0.988:
			print(x, '987_988', end='\t', sep='\t')
		elif 0.988 <= x < 0.989:
			print(x, '988_989', end='\t', sep='\t')
		elif 0.989 <= x < 0.99:
			print(x, '989_990', end='\t', sep='\t')
		elif 0.99 <= x < 0.991:
			print(x, '990_991', end='\t', sep='\t')
		elif 0.991 <= x < 0.992:
			print(x, '991_992', end='\t', sep='\t')
		elif 0.992 <= x < 0.993:
			print(x, '992_993', end='\t', sep='\t')
		elif 0.993 <= x < 0.994:
			print(x, '993_994', end='\t', sep='\t')
		elif 0.994 <= x < 0.995:
			print(x, '994_995', end='\t', sep='\t')
		elif 0.995 <= x < 0.996:
			print(x, '995_996', end='\t', sep='\t')
		elif 0.996 <= x < 0.997:
			print(x, '996_997', end='\t', sep='\t')
		elif 0.997 <= x < 0.998:
			print(x, '997_998', end='\t', sep='\t')
		elif 0.998 <= x < 0.999:
			print(x, '998_999', end='\t', sep='\t')
		elif 0.999 <= x <= 1.0:
			print(x, '999_1000', end='\t', sep='\t')

		# range_list = []
		# for i in range(20):
		# 	num = (i + 1)
		# 	range_list.append(980+i)

		# for range_num in range_list:
		# 	print("elif %s <= x < %s:" %(range_num/1000, (range_num+1)/1000))
		# 	print("print(x, '%s')"%(str(range_num)+'_'+str(range_num+1)))

		if 0 <= y < 2:
			print(y, '0_2', sep='\t')
		elif 2 <= y < 4:
			print(y, '2_4', sep='\t')
		elif 4 <= y < 6:
			print(y, '4_6', sep='\t')
		elif 6 <= y < 8:
			print(y, '6_8', sep='\t')
		elif 8 <= y < 10:
			print(y, '8_10', sep='\t')
		elif 10 <= y < 12:
			print(y, '10_12', sep='\t')
		elif 12 <= y < 14:
			print(y, '12_14', sep='\t')
		elif 14 <= y < 16:
			print(y, '14_16', sep='\t')
		elif 16 <= y < 18:
			print(y, '16_18', sep='\t')
		elif 18 <= y < 20:
			print(y, '18_20', sep='\t')
		elif 20 <= y < 22:
			print(y, '20_22', sep='\t')
		elif y >= 22:
			print(y, '22_', sep='\t')

		# for range_num in range_list:
		# 	print("elif %s <= y < %s:" %(range_num, (range_num+2)))
		# 	print("print(y, '%s')"%(str(range_num)+'_'+str(range_num+2)))

		#print(x, x_index,'\n',y, y_index)
		# my_matrix[y_index][x_index] += 1

# #print('0_95','95_96','96_97','97_98','98_99','99_100',sep='\t')
# for one in my_matrix:
# 	for two in one:
# 		#print(two, end='\t', sep='\t')
# 	#print('')

