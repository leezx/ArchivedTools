#!/bin/bash

prefix=hg19_chr22_60X
fq1=R1_chr22.fastq.gz
fq2=R2_chr22.fastq.gz
ref=/ifs4/BC_RD/USER/lizhixin/database/hg19_nohap_ref/split_chr/chr22.fasta
t=20
hiseq_RG="@RG\tID:chr22\tPL:illumina\tPU:110115_I270_FC81CBVABXX_L5_HUMiqvDBTDBCAPE\tLB:chr22\tSM:chr22\tCN:BGI"
java_path="/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/java/jre1.7.0_55/bin/java"
java_mem="-Xmx15g"
GATK="/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/GenomeAnalysisTK-3.3-0/GenomeAnalysisTK.jar"
picard="/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/picard"

echo ==========start at : `date` ========== && \
#----------bwa------------------------------
# GATK only support reads group bam
bwa mem -t $t -M -Y -R $hiseq_RG $ref $fq1 $fq2 | samtools sort - ${prefix}.sort && \
samtools index ${prefix}.sort.bam && \
samtools view -F 4 -b ${prefix}.sort.bam > ${prefix}.sort.filter_for_stat.bam && \

#---------------------add read group------------------------
# bwa mem -t 8 -M -Y $ref $fq1 $fq2 | samtools sort - ${prefix} && \
# $java_path $java_mem -jar $picard/AddOrReplaceReadGroups.jar VALIDATION_STRINGENCY=LENIENT I=${prefix}.bam O=$prefix.sort.bam LB=BGI PL=illumina PU=NA SM=$prefix && \
# samtools index $prefix.sort.bam && \

#----------MarkDuplicates.jar---------------
$java_path $java_mem -jar $picard/MarkDuplicates.jar I=./${prefix}.sort.bam O=./${prefix}.markdup.bam METRICS_FILE=./${prefix}.markdup.bam.mat && \
$java_path $java_mem -jar $picard/BuildBamIndex.jar I=./${prefix}.markdup.bam O=./${prefix}.markdup.bam.bai && \

#----------RealignerTargetCreator----------
#-----doubi: this is denovo ref, there is no database!!!!------------
$java_path $java_mem -jar $GATK -T RealignerTargetCreator -R $ref -I ${prefix}.markdup.bam -o ./${prefix}.intervals && \
$java_path $java_mem -jar $GATK -T IndelRealigner -R $ref -I ${prefix}.markdup.bam -targetIntervals ./${prefix}.intervals -o ./${prefix}.realign.bam && \

#----------HaplotypeCaller----no_-nct_5---------------
# $java_path $java_mem -jar $GATK -T HaplotypeCaller -R $ref -I ./${prefix}.realign.bam --emitRefConfidence BP_RESOLUTION --variant_index_type LINEAR --variant_index_parameter 128000 -o ./${prefix}.g.vcf && \
##### ERROR MESSAGE: Invalid command line: Argument nt has a bad value: The analysis HaplotypeCaller currently does not support parallel execution with nt.  Please run your analysis without the nt option.
$java_path $java_mem -jar $GATK -T HaplotypeCaller -nct $t -R $ref -I ./${prefix}.realign.bam --emitRefConfidence BP_RESOLUTION --heterozygosity 0.01 --indel_heterozygosity 0.01 --variant_index_type LINEAR --variant_index_parameter 128000 -o ./${prefix}.g.vcf && \

bgzip ${prefix}.g.vcf && \
tabix ${prefix}.g.vcf.gz && \
bcftools index ${prefix}.g.vcf.gz && \

#----------unified----------------------------
# $java_path $java_mem -jar $GATK -nct $t -T UnifiedGenotyper --genotype_likelihoods_model BOTH --min_base_quality_score 0 --allSitePLs --output_mode EMIT_ALL_SITES -ploidy 2 -R $ref -I ${prefix}.realign.bam -o $prefix.unified.g.vcf

echo ==========end at : `date` ==========
