import os
from subprocess import call

split_file_dir = "/ifs4/BC_RD/USER/lizhixin/my_project/20X_pacbio_chr22/DBG2OLC/bays_correct/kmer/split_1000/"
file_list = os.listdir(split_file_dir)



sh_count = 0
for one_file in file_list:
	sh_count += 1
	temp_sh_file = "./run_" + str(sh_count) + ".sh"
	temp_kmer_file = os.path.join(split_file_dir, one_file)
	temp_out_file = "./out_" +str(sh_count) + ".txt"
	#temp_stat_file =  "./stat_" +str(sh_count) + ".txt"
	outf = open(temp_sh_file, "w")
	head = "#!/bin/bash\necho ==========start at : `date` =========="
	source = "source ./env.sh\nsource ~/.bashrc"
	tail = "echo ==========end  at : `date` =========="
	cmd = "python group_kmer_LLCS_effecient.py %s %s" % (temp_kmer_file, temp_out_file)
	print(head, source, cmd, tail, file=outf, sep='\n', end='\n')
	outf.close()

	qsub_cmd = "qsub -cwd -l vf=1g -P HUMDnab -q bc.q,bc_rd.q %s" % (temp_sh_file)
	qsub_cmd_list = qsub_cmd.split()
	call(qsub_cmd_list)
	