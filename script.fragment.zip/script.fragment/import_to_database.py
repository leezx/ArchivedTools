from blog.models import Journal
# content = "1,0001-0782,COMMUN ACM,COMMUNICATIONS OF THE ACM,工程技术,计算机：理论 方法,UNITED STATES,18535,4.027,3.301,3.621,2.863,2.511,1.919,2.353,2.346,2.646,1.593,6.469,0.911,112,0.01475,2.099,JCR cited journal,计算机：理论方法,1,up,SCI cited journal,"
with open("journal_import.csv", 'r') as inf:
	for content in inf:
		content = content.strip()
		if not content:
			continue
		content.decode('utf-8')
		content_list = content.strip().split(',')
		journal = Journal.objects.create(rank=content_list[0],issn=content_list[1],abbreviation=content_list[2],full_title=content_list[3],category=content_list[4],Subcategory=content_list[5],Country=content_list[6],total_Cites=content_list[7],IF2017=content_list[8],IF2016=content_list[9],IF2015=content_list[10],IF2014=content_list[11],IF2013=content_list[12],IF2012=content_list[13],IF2011=content_list[14],IF2010=content_list[15],IF2009=content_list[16],IF2008=content_list[17],five_years_IF=content_list[18],Immediacy_Index=content_list[19],Articles=content_list[20],Eigenfactor_Score=content_list[21],Article_Influence_Score=content_list[22],JCR=content_list[23],CAS_JCR_subject=content_list[24],CAS_JCR_level=content_list[25],IF_dynamic=content_list[26],SCI=content_list[27],area=content_list[28])


