#!/bin/bash

fq1=/ifs4/BC_RD/USER/lizhixin/data/chr22/hiseq_reads/R1_chr22.fastq.gz
fq2=/ifs4/BC_RD/USER/lizhixin/data/chr22/hiseq_reads/R2_chr22.fastq.gz
#ref=/ifs4/BC_RD/USER/lizhixin/database/PB/PB_chr22_20X/PB_chr22_20X_random.fasta
ref=./PB_chr22_20X_random.fasta.index
#prefix=hiseq_bwa_PB

# bwa mem -t 1 $ref $fq1 $fq2 > hiseq_bwa_PB.sam 
# samtools view -b -F 4 hiseq_bwa_PB.sam -o hiseq_bwa_PB.bam 
# samtools sort -@ 8 hiseq_bwa_PB.bam -O  hiseq_bwa_PB.sort.bam 
# && \
# bwa mem -t 15 $ref $fq1 $fq2 > hiseq_bwa_PB.sam
# bwa bwasw -a5 -b10 -q2 -r4 -z30 -t 20 $ref $fq1 $fq2 > hiseq_bwa_PB.sam
# samtools sort hiseq_bwa_PB.sam  hiseq_bwa_PB.sort

soap -a $fq1 -b $fq2 -D $ref -o PE_output -2 SE_output -u unmapped -p 20 

#bam=${prefix}.sort.bam
#out=${prefix}_depth.txt

# samtools depth hiseq_bwa_PB.sort.bam > hiseq_bwa_PB_depth.txt 
# cat $out | awk 'BEGIN{i=0;j=0}{j++;if($3>=4)i++}END{print i,j, i/j}'
