#!/bin/bash

prefix=hg19_chr22_10X
fasta=/ifs4/BC_RD/USER/lizhixin/my_project/10X_pb_chr22/PB_chr22_10X_random.fastq
ref=/ifs4/BC_RD/USER/lizhixin/database/hg19_nohap_ref/split_chr/chr22.fasta
t=32
java_path="/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/java/jre1.7.0_55/bin/java"
java_mem="-Xmx30g"
GATK="/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/GenomeAnalysisTK-3.3-0/GenomeAnalysisTK.jar"
picard="/ifs4/BC_PUB/biosoft/pipeline/DNA/DNA_HiSeqWGS/DNA_HiSeqWGS_2015a/bin/picard"

echo ==========start at : `date` ========== && \
#---------------------------bwa------------------------------
bwa mem -t $t -x pacbio -B2 -w200 -D200 $ref $fasta | samtools sort - ${prefix} && \

#---------------------add read group------------------------
$java_path $java_mem -jar $picard/AddOrReplaceReadGroups.jar VALIDATION_STRINGENCY=LENIENT I=${prefix}.bam O=$prefix.rg.bam LB=BGI PL=Pacbio PU=NA SM=$prefix && \
samtools index $prefix.rg.bam && \

#---------------------MarkDuplicates------------------------
$java_path $java_mem -jar $picard/MarkDuplicates.jar REMOVE_DUPLICATES=false MAX_FILE_HANDLES_FOR_READ_ENDS_MAP=5000 INPUT=$prefix.rg.bam O=${prefix}.rg.dup.bam METRICS_FILE=${prefix}.rg.dup.bam.mat && \
samtools index ${prefix}.rg.dup.bam && \

#---------------------realign indel------------------------
python left_align.py -r $ref -m $prefix.rg.dup.bam $prefix.left_align.bam && \
samtools index $prefix.left_align.bam && \

#---------------------IndelRealigner------------------------
$java_path $java_mem -jar $GATK -T RealignerTargetCreator -R $ref -I $prefix.left_align.bam -o $prefix.realign.intervals && \
$java_path $java_mem -jar $GATK -T IndelRealigner -R $ref -I $prefix.left_align.bam -targetIntervals $prefix.realign.intervals -o $prefix.realigned.bam && \

#------------------base quality recalibration---------------
#----------denovo_ref_don't_use_this_module-----------------
# $java_path $java_mem -jar $GATK -nct 3 --lowMemoryMode -T BaseRecalibrator  --maximum_cycle_value 100000 -R $ref -I $prefix.realigned.bam -o $prefix.BQSR.table && \
# $java_path $java_mem -jar $GATK -T PrintReads -R $ref -I $prefix.realigned.bam -BQSR $prefix.BQSR.table -o $prefix.BQSR.bam && \

#------------------base quality recalibration---------------
$java_path $java_mem -jar $GATK -nct 20 -T UnifiedGenotyper --genotype_likelihoods_model BOTH --min_base_quality_score 0 --allSitePLs --output_mode EMIT_ALL_SITES -ploidy 2 -R $ref -I $prefix.realigned.bam -o $prefix.unified_GATK3_3.g.vcf && \

bgzip $prefix.unified_GATK3_3.g.vcf && \
tabix $prefix.unified_GATK3_3.g.vcf.gz && \
bcftools index $prefix.unified_GATK3_3.g.vcf.gz && \

# $java_path $java_mem -jar $GATK -nct 5 -T UnifiedGenotyper --genotype_likelihoods_model BOTH --min_base_quality_score 0 --allSitePLs --output_mode EMIT_ALL_SITES -ploidy 2 -R $ref -I $prefix.realigned.bam -o $prefix.unified.g.vcf.gz && \
# $java_path $java_mem -jar $GATK -nct 5 -T HaplotypeCaller -R $ref -ploidy 2 -I $prefix.realigned.bam --emitRefConfidence BP_RESOLUTION --variant_index_type LINEAR --variant_index_parameter 128000 -o $prefix.haplo.g.vcf.gz && \

echo ==========end at : `date` ==========

