#!/usr/bin/env python
# Author: LI ZHIXIN
""" 
Usage: python <script> <merge_4_line.txt>
"""

import sys

if len(sys.argv) - 1 != 1:
	sys.exit(__doc__)

in_file = sys.argv[1]
out_file = "bais_stat.txt" # out_file.split('/')[1]

inf = open(in_file, 'r')
outf = open(out_file, 'w')

stat_dic = {"mutation":{"ref":0,"mutation":0,"insertion":0,"deletion":0},\
			"insertion":{"ref":0,"mutation":0,"insertion":0,"deletion":0},\
			"deletion":{"ref":0,"mutation":0,"insertion":0,"deletion":0}\
}

line_count = 0

for line in inf:
	line_count += 1
	pos, obs, real_g, ref = line.strip().split()
	if obs == 'D' or len(obs) < len(ref):
		if real_g == ref:
			stat_dic["deletion"]["ref"] += 1
		elif real_g != ref and len(real_g) == len(ref):
			stat_dic["deletion"]["mutation"] += 1
		elif len(real_g) < len(ref):
			stat_dic["deletion"]["deletion"] += 1
		elif len(real_g) > len(ref):
			stat_dic["deletion"]["insertion"] += 1
	elif len(obs) == len(ref):
		if real_g == ref:
			stat_dic["mutation"]["ref"] += 1
		elif real_g != ref and len(real_g) == len(ref):
			stat_dic["mutation"]["mutation"] += 1
		elif len(real_g) < len(ref):
			stat_dic["mutation"]["deletion"] += 1
		elif len(real_g) > len(ref):
			stat_dic["mutation"]["insertion"] += 1
	elif len(obs) > len(ref):
		if real_g == ref:
			stat_dic["insertion"]["ref"] += 1
		elif real_g != ref and len(real_g) == len(ref):
			stat_dic["insertion"]["mutation"] += 1
		elif len(real_g) < len(ref):
			stat_dic["insertion"]["deletion"] += 1
		elif len(real_g) > len(ref):
			stat_dic["insertion"]["insertion"] += 1

print('          ', 'ref', "mutation","insertion","deletion", file=outf, sep='\t', end='\n')
for (key, value) in stat_dic.items():
	print(key, value['ref']/line_count, value["mutation"]/line_count, value["insertion"]/line_count, value["deletion"]/line_count, file=outf, sep='\t', end='\n')

inf.close()
outf.close()