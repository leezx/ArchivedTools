#!/bin/bash
echo ==========start at : `date` ==========

ref=/ifs4/BC_RD/USER/lizhixin/database/hg19_nohap_ref/split_chr/chr22.fasta
fasta=../merge_corrected.fastq

blasr $fasta $ref -sam -nproc 15 | samtools view -bS -F 4 - > corrected_fastq_for_stat.bam

echo ==========end  at : `date` ==========

