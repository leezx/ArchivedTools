echo ==========start at : `date` ==========

#### set SMRT ####
source /ifs4/BC_RD/USER/shizhuoxing/PacBio/pipeline/example7/RNA_module/Alignment_gmap/bin/smrtanalysis/etc/setup.sh

#### formatfa ####
# awk '!/^>/ {printf "%s",$0;n="\n"}/^>/{print n $0;n=""}END{printf "%s",n}'  isoseq_flnc.fasta > fl.fa;
# awk '!/^>/ {printf "%s",$0;n="\n"}/^>/{print n $0;n=""}END{printf "%s",n}'  isoseq_nfl.fasta > nfl.fa;

#### gmap ####
gmap -D /ifs4/BC_RD/USER/yuanyongxian/PacBio/GMAP/index/hg19/ -d hg19 -f samse -t 48 -n 0 183_CCS.fa > gmap.sam 2> gmap.log

#### grouping ####
# perl sam2gff.pl sim.sam
# perl grouping.pl sim.clean.gff sim.mutil.gff

#### pbdagcon ####
# perl pbdagcon.pl fl.fa sim.group

#### quiver ####
# perl ../quiver.pl

echo ==========end at : `date` ==========

