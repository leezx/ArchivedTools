import gzip

file_list = open("file.list","r")
outf = open("Camellia.est.fasta","w")
#inf = gzip.open("dbEST.reports.000000.49.gz","rb")
raw_id = ""
seq = ""
organism = ""

for one_file in file_list:
	one_file = one_file.strip()
	inf = gzip.open(one_file, "rb")
	for line in inf:
		line = line.decode()
		if line.startswith("GenBank Acc"):
			id = line.split(":")[1].strip()
		if line.startswith("SEQUENCE"):
			seq = ""
			while True:
				rline = inf.readline().decode()
				seq+=rline.strip()
				if not rline.startswith(" "):
					break
		if line.startswith("Organism"):
			organism = line.split(":")[1].strip()
			if organism.startswith("Camellia"):
				print(">"+id+"   "+organism, seq, sep="\n",file=outf)
				#break
	inf.close()
file_list.close()
outf.close()

