#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=8G
#PBS -l walltime=48:00:00
#PBS -q medium_48hr
#PBS -N run.44
#cd $PBS_O_WORKDIR
sh /home/lizhixin/databases/ncbi/dbEST/script/run.44.sh && echo job-done
