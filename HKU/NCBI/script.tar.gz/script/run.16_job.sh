#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=4G
#PBS -l walltime=06:00:00
#PBS -q small
#PBS -N run.16
#cd $PBS_O_WORKDIR
sh /home/lizhixin/databases/ncbi/dbEST/script/run.16.sh && echo job-done
