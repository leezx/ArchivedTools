curl -Ls "ftp://ftp.ncbi.nlm.nih.gov/genbank/gbenv80.seq.gz" | gunzip -c |\
awk '/^ACCESSION   / {printf(">%s\n",$2);next;} /^ORIGIN/ {inseq=1;next;} /^\/\// {inseq=0;} {if(inseq==0) next; gsub(/[0-9 ]/,"",$0); printf("%s\n",$0);}' |\
head -n 30
