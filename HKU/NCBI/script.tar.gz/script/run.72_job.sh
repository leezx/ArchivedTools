#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=8G
#PBS -l walltime=18:00:00
#PBS -q medium
#PBS -N run.72
cd $PBS_O_WORKDIR
sh /home/lizhixin/databases/ncbi/dbEST/script/run.72.sh && echo job-done
