# crontab can't work
#dir=/home2/groups/paultam/Zeki/tea/basic/scripts
dir=/home/lizhixin/databases/ncbi/dbEST/script
while (true) 
do
 cd $dir  && sh $dir/monitor.update.sh
 #date
 sleep 600
done
# nohup sh old_nohup_update.sh >out.log 2>&1 &
