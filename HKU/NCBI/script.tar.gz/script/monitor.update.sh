# monitor update >monitor.log 2>&1
echo "
======>">>monitor.log
date >>monitor.log
/home/lizhixin/softwares/miniconda2/envs/py3/bin/python /home/lizhixin/project/monitor/monitor.old.py update >>monitor.log 2>&1
