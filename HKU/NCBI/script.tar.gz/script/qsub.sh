python ./monitor.old.py qsub -f file.list
