#!/bin/bash

count=1
for line in $(cat est.list)
do
count=$[ $count + 1 ]
#echo $line
#echo $count
echo "file_name=\$0
/home/lizhixin/softwares/miniconda2/envs/py3/bin/python /home/lizhixin/databases/ncbi/dbEST/script/genebankToFastA_single.py $line &&\\
echo ==========end at: \`date\` ========== && \\
echo Still_waters_run_deep 1>&2 && \\
echo Still_waters_run_deep > \${file_name}.sign
" > run.${count}.sh
done
