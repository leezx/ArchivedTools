#!/bin/bash
#PBS -l nodes=1:ppn=1
#PBS -l mem=25G
#PBS -l walltime=72:00:00
#PBS -q large
#PBS -N run.49
#cd $PBS_O_WORKDIR
sh /home/lizhixin/databases/ncbi/dbEST/script/run.49.sh && echo job-done
