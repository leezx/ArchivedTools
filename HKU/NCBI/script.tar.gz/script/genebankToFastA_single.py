import gzip
import sys
import os

if len(sys.argv) - 1 != 1:
	print("ERROR!!!")
	sys.exit(__doc__)

#file_list = open("file.list","r")
work_dir = os.path.abspath('.') + "/"
one_file = sys.argv[1].strip()
sample_name = one_file.split("/")[-1]
outf = open(work_dir+sample_name+".fasta","w")
#inf = gzip.open("dbEST.reports.000000.49.gz","rb")
raw_id = ""
seq = ""
organism = ""

#for one_file in file_list:
#	one_file = one_file.strip()
inf = gzip.open(one_file, "rb")
print("Filtering:",one_file,"...")
for line in inf:
	line = line.decode(encoding='utf-8', errors='ignore')
	#line = unicode(line, errors='ignore')
	if line.startswith("GenBank Acc"):
		id = line.split(":")[1].strip()
	if line.startswith("SEQUENCE"):
		seq = ""
		while True:
			rline = inf.readline().decode(encoding='utf-8', errors='ignore')
			#rline = unicode(inf.readline(), errors='ignore')
			seq+=rline.strip()
			if not rline.startswith(" "):
				break
	if line.startswith("Organism"):
		organism = line.split(":")[1].strip()
		if organism.startswith("Camellia"):
			print(">"+id+"   "+organism, seq, sep="\n",file=outf)
			#break
inf.close()
#file_list.close()
outf.close()

