file_name=$0
/home/lizhixin/softwares/miniconda2/envs/py3/bin/python /home/lizhixin/databases/ncbi/dbEST/script/genebankToFastA_single.py /home/lizhixin/databases/ncbi/dbEST/dbEST.reports.000000.15.gz
echo ==========end at: `date` ========== && \
echo Still_waters_run_deep 1>&2 && \
echo Still_waters_run_deep > ${file_name}.sign

