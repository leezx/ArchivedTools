#!/bin/bash

echo ==========start at : `date` ========== && \

python ./split_fastq/generate_qsub_sh.py ./split_bam && \

echo ==========end at : `date` ==========
