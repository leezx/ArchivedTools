#!/bin/bash
# Program: Hybrid_error_correction (via bayesian model)
# Version: 0.1
# Contact: Zhixin Li <lizhixin@genomics.cn>

#---------------------step_1: set PATH---------------------------
prefix=arabidopsis
# hiseq reads and PB reads
fq1=/opt/lustresz/BC_PMO_P0/BC_RD/dengtq/01.Pacbio/00.data/arabidopsis/Illumina_2x300_R1.fastq.gz
fq2=/opt/lustresz/BC_PMO_P0/BC_RD/dengtq/01.Pacbio/00.data/arabidopsis/Illumina_2x300_R2.fastq.gz
PB_reads=/opt/lustresz/BC_PMO_P0/BC_RD/dengtq/01.Pacbio/00.data/arabidopsis/Pacbio.fasta.gz
# ref.fasta must create bwa index, samtools faidx and picard dict!!!
ref=/ifs4/BC_RD/USER/lizhixin/database/arabidopsis_TAIR9/TAIR9_chr_all.fasta
t=32
java_mem=30g

#---------------------step_2: set DIR and FILE--------------------
mkdir hiseq_gvcf && \
mkdir PB_gvcf && \
mkdir correction && \
cp hiseq_call_gvcf.sh hiseq_gvcf && \
cp PB_call_gvcf.sh PB_gvcf && \
cp cigar.py left_align.py PB_gvcf && \
cp run_correct.sh correction && \
hiseq_cmd="sh hiseq_call_gvcf.sh $prefix $fq1 $fq2 $ref $t $java_mem"
PB_cmd="sh PB_call_gvcf.sh $prefix $PB_reads $ref $t $java_mem"
echo '#!/bin/bash' > ./hiseq_gvcf/run_hiseq_call_gvcf.sh && \
echo "$hiseq_cmd" >> ./hiseq_gvcf/run_hiseq_call_gvcf.sh && \
echo '#!/bin/bash' > ./PB_gvcf/run_PB_call_gvcf.sh && \
echo "$PB_cmd" >> ./PB_gvcf/run_PB_call_gvcf.sh && \

#---------------------step_3: call hiseq and PB GVCF----------------
echo "please qsub ./hiseq_gvcf/run_hiseq_call_gvcf.sh and ./PB_gvcf/run_PB_call_gvcf.sh" && \

#---------------------step_4: correct-------------------------------
echo "If gvcf calling finished, qsub ./correction/run_correct.sh, don't need to set mem"

